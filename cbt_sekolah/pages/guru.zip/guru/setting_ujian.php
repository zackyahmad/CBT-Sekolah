<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../../index.php");
    exit;
}

require_once '../../config/koneksi.php';

// Menggunakan variabel pdo dari koneksi.php
$guru_id = $_SESSION['id_user'] ?? $_SESSION['user_id'];

// =============================================
// FUNCTION FORMAT TANGGAL
// =============================================
function formatTanggal($tanggal)
{
    if (!$tanggal) return '-';
    return date('d M Y H:i', strtotime($tanggal));
}

// =============================================
// HAPUS UJIAN
// =============================================
if (isset($_GET['hapus']) && is_numeric($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    
    // Cek kepemilikan menggunakan PDO
    $stmt_cek = $pdo->prepare("SELECT id FROM ujian WHERE id = ? AND guru_id = ?");
    $stmt_cek->execute([$id, $guru_id]);

    if ($stmt_cek->rowCount() > 0) {
        $stmt_hapus = $pdo->prepare("DELETE FROM ujian WHERE id = ?");
        $stmt_hapus->execute([$id]);

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Ujian berhasil dihapus.'
        ];
    }
    header("Location: setting_ujian.php");
    exit;
}

// Pagination & Query Data
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$stmt_list = $pdo->prepare("SELECT * FROM ujian WHERE guru_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?");
$stmt_list->bindValue(1, $guru_id, PDO::PARAM_INT);
$stmt_list->bindValue(2, $limit, PDO::PARAM_INT);
$stmt_list->bindValue(3, $offset, PDO::PARAM_INT);
$stmt_list->execute();
$ujian_list = $stmt_list->fetchAll(PDO::FETCH_ASSOC);

$total_ujian = $pdo->prepare("SELECT COUNT(*) FROM ujian WHERE guru_id = ?");
$total_ujian->execute([$guru_id]);
$total_rows = $total_ujian->fetchColumn();
$total_page = ceil($total_rows / $limit);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Setting Ujian - Guru</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-50 min-h-screen">

<div class="flex">
    <div class="flex-1 p-8">
        <div class="max-w-6xl mx-auto">
            
            <div class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="text-3xl font-bold text-slate-800">Daftar Ujian</h1>
                    <p class="text-slate-500">Kelola jadwal dan soal ujian Anda</p>
                </div>
                <a href="tambah_ujian.php" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-semibold transition flex items-center gap-2">
                    <i class="fas fa-plus"></i> Tambah Ujian
                </a>
            </div>

            <?php if (isset($_SESSION['flash'])): ?>
                <div class="mb-6 p-4 rounded-xl bg-green-100 text-green-700 border border-green-200">
                    <?= $_SESSION['flash']['msg']; unset($_SESSION['flash']); ?>
                </div>
            <?php endif; ?>

            <?php if (count($ujian_list) > 0): ?>
                <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-slate-50 border-b border-slate-200">
                                <th class="p-4 font-bold text-slate-700 uppercase text-xs">Nama Ujian</th>
                                <th class="p-4 font-bold text-slate-700 uppercase text-xs">Waktu Mulai</th>
                                <th class="p-4 font-bold text-slate-700 uppercase text-xs text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ujian_list as $u): ?>
                                <?php 
                                    // Deteksi nama kolom yang mungkin berbeda di database kamu
                                    // Jika 'nama_ujian' tidak ada, coba cari 'judul'
                                    $nama_ujian = $u['nama_ujian'] ?? $u['judul'] ?? 'Ujian Tanpa Nama';
                                    
                                    // Jika 'durasi' tidak ada, coba cari 'waktu_ujian' atau 'waktu'
                                    $durasi = $u['durasi'] ?? $u['waktu_ujian'] ?? $u['waktu'] ?? '-';
                                    
                                    // Jika 'waktu_mulai' tidak ada, coba 'tanggal_ujian', 'tgl_ujian', atau 'created_at'
                                    $waktu_mulai = $u['waktu_mulai'] ?? $u['tanggal_ujian'] ?? $u['tgl_ujian'] ?? $u['created_at'] ?? null;
                                ?>
                                <tr class="border-b border-slate-100 hover:bg-slate-50 transition">
                                    <td class="p-4">
                                        <div class="font-bold text-slate-800"><?= htmlspecialchars($nama_ujian) ?></div>
                                        <div class="text-xs text-slate-500">Durasi: <?= htmlspecialchars($durasi) ?> Menit</div>
                                    </td>
                                    <td class="p-4 text-sm text-slate-600">
                                        <?= formatTanggal($waktu_mulai) ?>
                                    </td>
                                    <td class="p-4 text-center">
                                        <div class="flex justify-center gap-2">
                                            <a href="kelola_soal_ujian.php?id=<?= $u['id'] ?? $u['id_ujian'] ?>" 
                                               class="bg-indigo-500 hover:bg-indigo-600 text-white px-3 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1">
                                                <i class="fas fa-tasks"></i> Atur Soal
                                            </a>
                                            
                                            <a href="edit_ujian.php?id=<?= $u['id'] ?? $u['id_ujian'] ?>" 
                                               class="bg-amber-400 hover:bg-amber-500 text-white px-3 py-2 rounded-lg text-xs font-bold transition">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            
                                            <a href="?hapus=<?= $u['id'] ?? $u['id_ujian'] ?>" 
                                               onclick="return confirm('Yakin ingin menghapus ujian ini?')"
                                               class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg text-xs font-bold transition">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_page > 1): ?>
                    <div class="mt-6 flex gap-2 justify-center">
                        <?php for ($i = 1; $i <= $total_page; $i++): ?>
                            <a href="?page=<?= $i ?>" class="<?= $i === $page ? 'bg-blue-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-100' ?> w-10 h-10 rounded-xl flex items-center justify-center font-bold shadow-sm border border-slate-200 transition">
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>
                    </div>
                <?php endif; ?>

            <?php else: ?>
                <div class="py-20 text-center bg-white rounded-2xl border border-dashed border-slate-300">
                    <div class="text-6xl mb-4">📅</div>
                    <h3 class="text-xl font-bold text-slate-700 mb-2">Belum ada ujian</h3>
                    <p class="text-slate-500 mb-6">Mulai buat jadwal ujian pertama Anda</p>
                    <a href="tambah_ujian.php" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-semibold transition">➕ Buat Ujian</a>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

</body>
</html>