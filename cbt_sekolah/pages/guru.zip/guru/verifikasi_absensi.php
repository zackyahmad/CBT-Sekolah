<?php
// =============================================
// FILE: pages/guru/verifikasi_absensi.php
// Verifikasi dan kelola kehadiran siswa pada ujian
// =============================================
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../../index.php"); exit;
}
require_once '../../config/koneksi.php'; // pakai PDO punya admin

$nama_guru = $_SESSION['nama_lengkap'] ?? $_SESSION['nama'] ?? 'Guru';
$search    = isset($_GET['search']) ? $_GET['search'] : '';

// PERBAIKAN 1: Gunakan id_user sesuai nama sesi login yang benar
$guru_id  = $_SESSION['id_user'] ?? 0;
$ujian_id = isset($_GET['ujian_id']) ? (int)$_GET['ujian_id'] : 0;

// PERBAIKAN 2: Menggunakan PDO untuk mengambil daftar ujian
$stmt_ujian = $pdo->prepare("SELECT id, nama_ujian FROM ujian WHERE guru_id = ? ORDER BY created_at DESC");
$stmt_ujian->execute([$guru_id]);
$ujian_list = $stmt_ujian->fetchAll(PDO::FETCH_ASSOC);

// PROSES: verifikasi / tolak
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    $a_id  = (int)$_POST['absensi_id'];
    $aksi  = $_POST['aksi']; // hadir / tidak_hadir / izin
    
    // PERBAIKAN 3: PDO otomatis mengamankan query, jadi tidak butuh real_escape_string lagi
    $catatan = trim($_POST['catatan_guru'] ?? '');
    $allowed = ['hadir','tidak_hadir','izin'];
    
    if (in_array($aksi, $allowed)) {
        // PERBAIKAN 4: Query UPDATE menggunakan PDO
        $stmt_update = $pdo->prepare("UPDATE absensi SET status = ?, catatan_guru = ?, verified_at = NOW(), verified_by = ? WHERE id = ?");
        $stmt_update->execute([$aksi, $catatan, $guru_id, $a_id]);
        
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Status absensi berhasil diperbarui.'];
    }
    header("Location: verifikasi_absensi.php?ujian_id=$ujian_id"); exit();
}

$absensi_list = null;
$detail_ujian = null;

if ($ujian_id) {
    // PERBAIKAN 5: Ubah num_rows dan fetch_assoc menjadi gaya PDO
    $stmt_detail = $pdo->prepare("SELECT * FROM ujian WHERE id = ? AND guru_id = ?");
    $stmt_detail->execute([$ujian_id, $guru_id]);
    $detail_ujian = $stmt_detail->fetch(PDO::FETCH_ASSOC); // Ambil 1 baris data
    
    if ($detail_ujian) { // Pengganti dari if ($q->num_rows > 0)
        $stmt_absensi = $pdo->prepare("
            SELECT a.id, a.status, a.keterangan, a.catatan_guru, a.verified_at,
                   s.nama, s.nis, s.kelas
            FROM absensi a
            JOIN siswa s ON s.id = a.siswa_id
            WHERE a.ujian_id = ?
            ORDER BY s.nama
        ");
        $stmt_absensi->execute([$ujian_id]);
        $absensi_list = $stmt_absensi->fetchAll(PDO::FETCH_ASSOC); // Ambil semua baris data menjadi array
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Verifikasi Absensi – CBT Sekolah</title>
    <link rel="stylesheet" href="../assets/css/guru.css">
</head>
<body>
<?php include '../includes/sidebar_guru.php'; ?>
<div class="main-wrapper">
    <header class="topbar">
        <div class="topbar-left"><h1>Verifikasi Absensi</h1><p>Konfirmasi kehadiran siswa pada ujian</p></div>
    </header>
    <main class="page-content">
        <?php if (isset($_SESSION['flash'])): ?>
        <div class="alert alert-<?= $_SESSION['flash']['type'] ?>"><?= $_SESSION['flash']['type']==='success'?'✅':'⚠️' ?> <?= htmlspecialchars($_SESSION['flash']['msg']) ?></div>
        <?php unset($_SESSION['flash']); endif; ?>

        <!-- Pilih Ujian -->
        <div class="card" style="margin-bottom:20px">
            <div class="card-body" style="padding:16px">
                <form method="GET" style="display:flex;gap:12px;align-items:flex-end">
                    <div class="form-group" style="margin:0;flex:1">
                        <label>Pilih Ujian</label>
                        <select name="ujian_id" class="form-control" onchange="this.form.submit()">
                            <option value="">-- Pilih ujian --</option>
                            <?php foreach ($u=$ujian_list as $row): ?>
                            <option value="<?= $u['id'] ?>" <?= $u['id']===$ujian_id?'selected':'' ?>><?= htmlspecialchars($u['nama_ujian']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
            </div>
        </div>

        <?php if ($absensi_list): ?>
        <div class="card">
            <div class="card-header">
                <span class="card-title">✅ Absensi – <?= htmlspecialchars($detail_ujian['nama_ujian']) ?></span>
            </div>
            <div class="card-body" style="padding:0">
                <?php if ($absensi_list->num_rows > 0): ?>
                <div class="table-wrapper">
                    <table>
                        <thead><tr><th>No</th><th>NIS</th><th>Nama</th><th>Kelas</th><th>Status</th><th>Keterangan Siswa</th><th>Catatan Guru</th><th>Diverifikasi</th><th>Aksi</th></tr></thead>
                        <tbody>
                        <?php $no=1; foreach ($a=$absensi_list as $row): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($a['nis']??'-') ?></td>
                            <td style="font-weight:600"><?= htmlspecialchars($a['nama']) ?></td>
                            <td><?= htmlspecialchars($a['kelas']??'-') ?></td>
                            <td>
                                <?php
                                $st=$a['status'];
                                $sc=$st==='hadir'?'success':($st==='tidak_hadir'?'danger':($st==='izin'?'warning':'gray'));
                                $lbl=$st==='hadir'?'Hadir':($st==='tidak_hadir'?'Tidak Hadir':($st==='izin'?'Izin':'Belum'));
                                ?>
                                <span class="badge badge-<?= $sc ?>"><?= $lbl ?></span>
                            </td>
                            <td style="font-size:12px"><?= htmlspecialchars($a['keterangan']??'-') ?></td>
                            <td style="font-size:12px"><?= htmlspecialchars($a['catatan_guru']??'-') ?></td>
                            <td style="font-size:12px"><?= $a['verified_at'] ? date('d/m H:i', strtotime($a['verified_at'])) : '-' ?></td>
                            <td>
                                <div style="display:flex;gap:4px">
                                    <form method="POST" style="display:inline">
                                        <input type="hidden" name="absensi_id" value="<?= $a['id'] ?>">
                                        <input type="hidden" name="catatan_guru" value="<?= htmlspecialchars($a['catatan_guru']??'') ?>">
                                        <button type="submit" name="aksi" value="hadir" class="btn btn-sm" style="background:var(--success-soft);color:var(--success)">✓ Hadir</button>
                                    </form>
                                    <form method="POST" style="display:inline">
                                        <input type="hidden" name="absensi_id" value="<?= $a['id'] ?>">
                                        <input type="hidden" name="catatan_guru" value="">
                                        <button type="submit" name="aksi" value="tidak_hadir" class="btn btn-sm" style="background:var(--danger-soft);color:var(--danger)">✗ Absen</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="card-empty"><div class="empty-icon">✅</div><p>Belum ada data absensi untuk ujian ini.</p></div>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="card"><div class="card-empty"><div class="empty-icon">✅</div><p>Pilih ujian untuk melihat absensi.</p></div></div>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
