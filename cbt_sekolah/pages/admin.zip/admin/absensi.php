<?php
session_start();
// Cek sesi admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit;
}
require_once '../../config/koneksi.php';

// Set timezone
date_default_timezone_set('Asia/Jakarta');

// Ambil parameter filter
$filter_tanggal = $_GET['tanggal'] ?? date('Y-m-d');
$filter_tanggal_akhir = $_GET['tanggal_akhir'] ?? date('Y-m-d');
$filter_status = $_GET['status'] ?? '';
$filter_kelas = $_GET['kelas'] ?? '';
$filter_role = $_GET['role'] ?? 'semua';
$filter_cari = $_GET['cari'] ?? '';
$filter_bulan = $_GET['bulan'] ?? date('m');
$filter_tahun = $_GET['tahun'] ?? date('Y');
$filter_tipe = $_GET['tipe'] ?? 'harian'; // harian, bulanan, rentang

// Ambil data kelas untuk filter
$kelas_list = $pdo->query("SELECT * FROM tb_kelas ORDER BY nama_kelas ASC")->fetchAll();

// Ambil data pengawas/guru - PERBAIKAN: hapus kolom nip
$pengawas_list = $pdo->query("SELECT id_user, nama_lengkap FROM tb_users WHERE role IN ('guru', 'admin') ORDER BY nama_lengkap ASC")->fetchAll();

// Ambil data siswa per kelas untuk ringkasan
$siswa_per_kelas = [];
try {
    $query_kelas = "SELECT k.id_kelas, k.nama_kelas, COUNT(u.id_user) as jumlah_siswa 
                    FROM tb_kelas k 
                    LEFT JOIN tb_users u ON k.id_kelas = u.id_kelas AND u.role = 'siswa'
                    GROUP BY k.id_kelas 
                    ORDER BY k.nama_kelas";
    $siswa_per_kelas = $pdo->query($query_kelas)->fetchAll();
} catch (PDOException $e) {
    $siswa_per_kelas = [];
}

// Ambil data absensi berdasarkan filter
$data_absensi = [];
$ringkasan_kelas = [];
$total_hadir = 0;
$total_sakit = 0;
$total_izin = 0;
$total_alpha = 0;
$total_terlambat = 0;

try {
    // Base query untuk absensi - PERBAIKAN: hapus referensi ke nip, nuptk
    if ($filter_tipe == 'harian') {
        // Absensi per hari
        $query = "SELECT a.*, u.nama_lengkap, u.username, u.role, u.id_kelas,
                         k.nama_kelas,
                         DATE_FORMAT(a.tanggal, '%d/%m/%Y') as tgl_format,
                         TIME_FORMAT(a.waktu_datang, '%H:%i') as jam_datang,
                         TIME_FORMAT(a.waktu_pulang, '%H:%i') as jam_pulang
                  FROM tb_absensi a
                  JOIN tb_users u ON a.id_user = u.id_user
                  LEFT JOIN tb_kelas k ON u.id_kelas = k.id_kelas
                  WHERE DATE(a.tanggal) = :tanggal";
        
        $params = [':tanggal' => $filter_tanggal];
        
    } elseif ($filter_tipe == 'rentang') {
        // Absensi rentang tanggal
        $query = "SELECT a.*, u.nama_lengkap, u.username, u.role, u.id_kelas,
                         k.nama_kelas,
                         DATE_FORMAT(a.tanggal, '%d/%m/%Y') as tgl_format,
                         TIME_FORMAT(a.waktu_datang, '%H:%i') as jam_datang,
                         TIME_FORMAT(a.waktu_pulang, '%H:%i') as jam_pulang
                  FROM tb_absensi a
                  JOIN tb_users u ON a.id_user = u.id_user
                  LEFT JOIN tb_kelas k ON u.id_kelas = k.id_kelas
                  WHERE DATE(a.tanggal) BETWEEN :tanggal_awal AND :tanggal_akhir";
        
        $params = [
            ':tanggal_awal' => $filter_tanggal,
            ':tanggal_akhir' => $filter_tanggal_akhir
        ];
        
    } else {
        // Absensi bulanan
        $query = "SELECT a.*, u.nama_lengkap, u.username, u.role, u.id_kelas,
                         k.nama_kelas,
                         DATE_FORMAT(a.tanggal, '%d/%m/%Y') as tgl_format,
                         TIME_FORMAT(a.waktu_datang, '%H:%i') as jam_datang,
                         TIME_FORMAT(a.waktu_pulang, '%H:%i') as jam_pulang
                  FROM tb_absensi a
                  JOIN tb_users u ON a.id_user = u.id_user
                  LEFT JOIN tb_kelas k ON u.id_kelas = k.id_kelas
                  WHERE MONTH(a.tanggal) = :bulan AND YEAR(a.tanggal) = :tahun";
        
        $params = [
            ':bulan' => $filter_bulan,
            ':tahun' => $filter_tahun
        ];
    }
    
    // Filter berdasarkan role
    if ($filter_role == 'siswa') {
        $query .= " AND u.role = 'siswa'";
    } elseif ($filter_role == 'pengawas') {
        $query .= " AND u.role IN ('guru', 'admin')";
    }
    
    // Filter berdasarkan kelas
    if (!empty($filter_kelas) && $filter_role != 'pengawas') {
        $query .= " AND u.id_kelas = :kelas";
        $params[':kelas'] = $filter_kelas;
    }
    
    // Filter berdasarkan status
    if (!empty($filter_status)) {
        $query .= " AND a.status = :status";
        $params[':status'] = $filter_status;
    }
    
    // Filter pencarian - PERBAIKAN: hapus referensi ke nip, nis, nisn
    if (!empty($filter_cari)) {
        $query .= " AND u.nama_lengkap LIKE :cari";
        $params[':cari'] = "%$filter_cari%";
    }
    
    // Order by
    if ($filter_tipe == 'harian') {
        $query .= " ORDER BY 
                    CASE u.role 
                        WHEN 'guru' THEN 1 
                        WHEN 'admin' THEN 2 
                        ELSE 3 
                    END,
                    k.nama_kelas, u.nama_lengkap ASC";
    } elseif ($filter_tipe == 'rentang') {
        $query .= " ORDER BY a.tanggal DESC, k.nama_kelas, u.nama_lengkap ASC";
    } else {
        $query .= " ORDER BY a.tanggal DESC, k.nama_kelas, u.nama_lengkap ASC";
    }
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $data_absensi = $stmt->fetchAll();
    
    // Hitung total berdasarkan status
    foreach ($data_absensi as $d) {
        switch($d['status']) {
            case 'hadir': $total_hadir++; break;
            case 'sakit': $total_sakit++; break;
            case 'izin': $total_izin++; break;
            case 'alpha': $total_alpha++; break;
            case 'terlambat': $total_terlambat++; break;
        }
    }
    
    // Buat ringkasan per kelas (khusus siswa)
    if ($filter_role != 'pengawas') {
        $ringkasan_kelas = [];
        foreach ($data_absensi as $d) {
            if ($d['role'] == 'siswa') {
                $kelas = $d['nama_kelas'] ?? 'Tanpa Kelas';
                if (!isset($ringkasan_kelas[$kelas])) {
                    $ringkasan_kelas[$kelas] = [
                        'total' => 0,
                        'hadir' => 0,
                        'sakit' => 0,
                        'izin' => 0,
                        'alpha' => 0,
                        'terlambat' => 0
                    ];
                }
                $ringkasan_kelas[$kelas]['total']++;
                $ringkasan_kelas[$kelas][$d['status']]++;
            }
        }
    }
    
} catch (PDOException $e) {
    $error = "Error: " . $e->getMessage();
}

// Fungsi untuk mendapatkan nama bulan
function getNamaBulan($bulan) {
    $nama_bulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    return $nama_bulan[(int)$bulan] ?? '';
}

// Untuk menu active
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Absensi - ADMINSKAPAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>
    <style>
        /* Palet Warna */
        :root {
            --primary-1: #2B3A67;
            --primary-2: #496A81;
            --secondary-1: #66999B;
            --secondary-2: #B3AF8F;
            --accent-1: #FFC482;
            --accent-2: #DDB7AB;
            --neutral-1: #F8F4E9;
            --neutral-2: #E8E1D3;
            --success: #77BFA3;
            --warning: #FFB347;
            --danger: #E58C7C;
        }

        body {
            background: linear-gradient(135deg, var(--neutral-1) 0%, var(--neutral-2) 100%);
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }

        .sidebar {
            background: linear-gradient(180deg, var(--primary-1) 0%, var(--primary-2) 100%);
            box-shadow: 4px 0 20px rgba(43, 58, 103, 0.2);
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 16rem;
            z-index: 50;
            overflow-y: auto;
        }

        .sidebar-item {
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            color: white;
        }

        .sidebar-item:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--accent-1);
            transform: translateX(5px);
        }

        .sidebar-item.active {
            background: linear-gradient(90deg, var(--accent-1) 0%, var(--accent-2) 100%);
            color: var(--primary-1);
            font-weight: 600;
        }

        .dropdown-menu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
            background: rgba(43, 58, 103, 0.3);
        }
        
        .dropdown-menu.open {
            max-height: 500px;
        }
        
        .dropdown-toggle .fa-chevron-down {
            transition: transform 0.3s;
        }
        
        .dropdown-toggle.open .fa-chevron-down {
            transform: rotate(180deg);
        }
        
        .dropdown-item {
            padding-left: 3rem !important;
        }

        /* Main Content */
        .main-content {
            margin-left: 16rem;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        /* Header */
        .header-gradient {
            background: linear-gradient(135deg, #ffffff 0%, var(--neutral-1) 100%);
            border-bottom: 3px solid var(--secondary-1);
        }

        /* Card dan Filter */
        .filter-card {
            background: white;
            border-radius: 20px;
            border: 1px solid var(--neutral-2);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 1rem;
            border: 1px solid var(--neutral-2);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(43, 58, 103, 0.1);
        }

        /* Tabel */
        .table-container {
            background: white;
            border-radius: 20px;
            border: 1px solid var(--neutral-2);
            overflow: auto;
            max-height: 600px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: linear-gradient(135deg, var(--primary-1), var(--primary-2));
            color: white;
            font-weight: 600;
            font-size: 0.75rem;
            padding: 12px 8px;
            text-align: left;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        td {
            padding: 10px 8px;
            font-size: 0.8rem;
            border-bottom: 1px solid var(--neutral-2);
        }

        tr:hover {
            background: var(--neutral-1);
        }

        /* Badge Status */
        .badge-status {
            padding: 4px 8px;
            border-radius: 50px;
            font-size: 0.65rem;
            font-weight: 600;
            display: inline-block;
            min-width: 70px;
            text-align: center;
        }

        .badge-hadir { background: #77BFA3; color: white; }
        .badge-sakit { background: #FFB347; color: white; }
        .badge-izin { background: #66999B; color: white; }
        .badge-alpha { background: #E58C7C; color: white; }
        .badge-terlambat { background: #DDB7AB; color: white; }

        /* Tombol */
        .btn-primary {
            background: linear-gradient(135deg, var(--secondary-1), var(--primary-2));
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(102, 153, 155, 0.4);
        }

        .btn-excel {
            background: #217346;
            color: white;
        }
        .btn-excel:hover {
            background: #1a5e38;
        }

        .btn-pdf {
            background: #d32f2f;
            color: white;
        }
        .btn-pdf:hover {
            background: #b71c1c;
        }

        .btn-print {
            background: var(--primary-2);
            color: white;
        }

        /* Ringkasan Kelas */
        .ringkasan-card {
            background: linear-gradient(135deg, white, var(--neutral-1));
            border-radius: 16px;
            padding: 1rem;
            border: 1px solid var(--neutral-2);
        }

        /* Print */
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                background: white;
            }
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            th {
                background: #f0f0f0 !important;
                color: black !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .badge-status {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>

<body>

    <!-- SIDEBAR -->
    <div class="sidebar no-print">
        <div class="p-4 border-b border-white/10">
            <div class="flex items-center gap-3">
                <img src="../../assets/img/logo_sekolah.png" alt="Logo" class="h-12 w-12 rounded-xl bg-white/10 p-1 border-2 border-white/20">
                <div>
                    <h2 class="font-bold text-sm text-white">ADMINSKAPAN</h2>
                    <p class="text-[0.6rem] text-white/60">SMK N 8 Bandar Lampung</p>
                </div>
            </div>
        </div>
        
        <div class="py-4">
            <a href="dashboard.php" class="flex items-center px-6 py-3 sidebar-item <?= $current_page == 'dashboard.php' ? 'active' : '' ?>">
                <i class="fas fa-home w-6"></i>
                <span class="text-sm font-medium">Dashboard</span>
            </a>

            <!-- LAPORAN (dengan ABSENSI aktif) -->
            <div class="dropdown-container mt-2">
                <div class="flex items-center justify-between px-6 py-3 sidebar-item cursor-pointer dropdown-toggle <?= in_array($current_page, ['absensi.php', 'laporan_absensi.php']) ? 'active' : '' ?>" onclick="toggleDropdown('laporanDropdown')">
                    <div class="flex items-center">
                        <i class="fas fa-file-alt w-6"></i>
                        <span class="text-sm font-medium">Laporan</span>
                    </div>
                    <i class="fas fa-chevron-down text-xs text-white/60"></i>
                </div>
                <div id="laporanDropdown" class="dropdown-menu <?= in_array($current_page, ['absensi.php', 'laporan_absensi.php']) ? 'open' : '' ?>">
                    <a href="data_kelas.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item">Data Kelas</a>
                    <a href="data_guru.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item">Data Guru</a>
                    <a href="data_siswa.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item">Data Siswa</a>
                    <a href="data_pengawas.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item">Data Pengawas</a>
                    <a href="absensi.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item <?= $current_page == 'absensi.php' ? 'active' : '' ?>">Absensi</a>
                    <a href="laporan_absensi.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item <?= $current_page == 'laporan_absensi.php' ? 'active' : '' ?>">Rekap Absensi</a>
                </div>
            </div>

            <!-- Menu Lainnya -->
            <div class="mt-4 pt-4 border-t border-white/10">
                <div class="px-6 py-2">
                    <p class="text-xs font-semibold text-white/40 uppercase">Master Data</p>
                </div>
                <a href="data_kelas.php" class="flex items-center px-6 py-3 sidebar-item">Data Kelas</a>
                <a href="data_mapel.php" class="flex items-center px-6 py-3 sidebar-item">Mata Pelajaran</a>
                <a href="data_siswa.php" class="flex items-center px-6 py-3 sidebar-item">Data Siswa</a>
                <a href="data_guru.php" class="flex items-center px-6 py-3 sidebar-item">Data Guru</a>
            </div>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">

        <!-- HEADER -->
        <header class="header-gradient py-3 px-6 flex justify-between items-center sticky top-0 z-40 shadow-sm no-print">
            <div class="flex items-center gap-3">
                <h1 class="text-xl font-bold" style="color: var(--primary-1);">
                    <i class="fas fa-calendar-check mr-2" style="color: var(--secondary-1);"></i>
                    Manajemen Absensi
                </h1>
            </div>
            <div class="flex items-center space-x-4">
                <div class="text-right">
                    <p class="text-xs font-bold" style="color: var(--primary-1);"><?= $_SESSION['nama'] ?? 'Admin'; ?></p>
                    <p class="text-[0.6rem] font-medium" style="color: var(--secondary-1);">Admin</p>
                </div>
                <img src="../../assets/img/logo_sekolah.png" class="h-10 w-10 rounded-2xl border-4 border-white shadow-lg">
            </div>
        </header>

        <main class="p-6">

            <!-- FILTER SECTION -->
            <div class="filter-card p-6 mb-6 no-print">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-lg font-bold" style="color: var(--primary-1);">
                        <i class="fas fa-filter mr-2" style="color: var(--secondary-1);"></i>
                        Filter Data Absensi
                    </h2>
                    <div class="flex gap-2">
                        <button onclick="exportToExcel()" class="btn-excel px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
                            <i class="fas fa-file-excel"></i> Export Excel
                        </button>
                        <button onclick="exportToPDF()" class="btn-pdf px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
                            <i class="fas fa-file-pdf"></i> Export PDF
                        </button>
                        <button onclick="window.print()" class="btn-print px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
                            <i class="fas fa-print"></i> Print
                        </button>
                    </div>
                </div>

                <form method="GET" action="" class="space-y-4">
                    <!-- Baris 1: Tipe dan Role -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Tipe Laporan</label>
                            <select name="tipe" id="tipe" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:border-blue-500 outline-none" onchange="toggleTipe()">
                                <option value="harian" <?= $filter_tipe == 'harian' ? 'selected' : '' ?>>Harian</option>
                                <option value="rentang" <?= $filter_tipe == 'rentang' ? 'selected' : '' ?>>Rentang Tanggal</option>
                                <option value="bulanan" <?= $filter_tipe == 'bulanan' ? 'selected' : '' ?>>Bulanan</option>
                            </select>
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Role</label>
                            <select name="role" id="role" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:border-blue-500 outline-none" onchange="toggleRole()">
                                <option value="semua" <?= $filter_role == 'semua' ? 'selected' : '' ?>>Semua</option>
                                <option value="siswa" <?= $filter_role == 'siswa' ? 'selected' : '' ?>>Siswa</option>
                                <option value="pengawas" <?= $filter_role == 'pengawas' ? 'selected' : '' ?>>Pengawas/Guru</option>
                            </select>
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Status</label>
                            <select name="status" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:border-blue-500 outline-none">
                                <option value="">Semua Status</option>
                                <option value="hadir" <?= $filter_status == 'hadir' ? 'selected' : '' ?>>Hadir</option>
                                <option value="sakit" <?= $filter_status == 'sakit' ? 'selected' : '' ?>>Sakit</option>
                                <option value="izin" <?= $filter_status == 'izin' ? 'selected' : '' ?>>Izin</option>
                                <option value="alpha" <?= $filter_status == 'alpha' ? 'selected' : '' ?>>Alpha</option>
                                <option value="terlambat" <?= $filter_status == 'terlambat' ? 'selected' : '' ?>>Terlambat</option>
                            </select>
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Pencarian</label>
                            <input type="text" name="cari" value="<?= htmlspecialchars($filter_cari) ?>" placeholder="Nama..." class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:border-blue-500 outline-none">
                        </div>
                    </div>

                    <!-- Baris 2: Tanggal (berubah sesuai tipe) -->
                    <div id="filter-harian" class="grid grid-cols-1 md:grid-cols-3 gap-4" style="<?= $filter_tipe != 'harian' ? 'display: none;' : '' ?>">
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Tanggal</label>
                            <input type="date" name="tanggal" value="<?= $filter_tanggal ?>" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                        </div>
                    </div>

                    <div id="filter-rentang" class="grid grid-cols-1 md:grid-cols-3 gap-4" style="<?= $filter_tipe != 'rentang' ? 'display: none;' : '' ?>">
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Tanggal Awal</label>
                            <input type="date" name="tanggal" value="<?= $filter_tanggal ?>" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Tanggal Akhir</label>
                            <input type="date" name="tanggal_akhir" value="<?= $filter_tanggal_akhir ?>" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                        </div>
                    </div>

                    <div id="filter-bulanan" class="grid grid-cols-1 md:grid-cols-3 gap-4" style="<?= $filter_tipe != 'bulanan' ? 'display: none;' : '' ?>">
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Bulan</label>
                            <select name="bulan" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= $filter_bulan == $i ? 'selected' : '' ?>><?= getNamaBulan($i) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Tahun</label>
                            <select name="tahun" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                                <?php for($i = date('Y'); $i >= date('Y')-5; $i--): ?>
                                <option value="<?= $i ?>" <?= $filter_tahun == $i ? 'selected' : '' ?>><?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Baris 3: Filter Kelas (khusus siswa) -->
                    <div id="filter-siswa" class="grid grid-cols-1 md:grid-cols-1 gap-4" style="<?= $filter_role == 'pengawas' ? 'display: none;' : '' ?>">
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Kelas</label>
                            <select name="kelas" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                                <option value="">Semua Kelas</option>
                                <?php foreach ($kelas_list as $k): ?>
                                <option value="<?= $k['id_kelas'] ?>" <?= $filter_kelas == $k['id_kelas'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($k['nama_kelas']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Tombol Submit -->
                    <div class="flex justify-end gap-2">
                        <a href="absensi.php" class="px-4 py-2 border border-gray-300 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100">
                            Reset Filter
                        </a>
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-search mr-2"></i> Tampilkan Data
                        </button>
                    </div>
                </form>
            </div>

            <!-- STATISTIK CARD -->
            <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6 no-print">
                <div class="stat-card">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background: #77BFA3;">
                            <i class="fas fa-user-check text-white"></i>
                        </div>
                        <span class="text-2xl font-bold" style="color: #77BFA3;"><?= $total_hadir ?></span>
                    </div>
                    <p class="text-xs text-gray-500">Hadir</p>
                </div>
                <div class="stat-card">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background: #FFB347;">
                            <i class="fas fa-thermometer-half text-white"></i>
                        </div>
                        <span class="text-2xl font-bold" style="color: #FFB347;"><?= $total_sakit ?></span>
                    </div>
                    <p class="text-xs text-gray-500">Sakit</p>
                </div>
                <div class="stat-card">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background: #66999B;">
                            <i class="fas fa-pen text-white"></i>
                        </div>
                        <span class="text-2xl font-bold" style="color: #66999B;"><?= $total_izin ?></span>
                    </div>
                    <p class="text-xs text-gray-500">Izin</p>
                </div>
                <div class="stat-card">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background: #E58C7C;">
                            <i class="fas fa-user-slash text-white"></i>
                        </div>
                        <span class="text-2xl font-bold" style="color: #E58C7C;"><?= $total_alpha ?></span>
                    </div>
                    <p class="text-xs text-gray-500">Alpha</p>
                </div>
                <div class="stat-card">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background: #DDB7AB;">
                            <i class="fas fa-clock text-white"></i>
                        </div>
                        <span class="text-2xl font-bold" style="color: #DDB7AB;"><?= $total_terlambat ?></span>
                    </div>
                    <p class="text-xs text-gray-500">Terlambat</p>
                </div>
            </div>

            <!-- RINGKASAN PER KELAS (khusus siswa) -->
            <?php if ($filter_role != 'pengawas' && !empty($ringkasan_kelas)): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6 no-print">
                <?php foreach ($ringkasan_kelas as $kelas => $data): ?>
                <div class="ringkasan-card">
                    <div class="flex justify-between items-center mb-3">
                        <h4 class="font-bold text-sm" style="color: var(--primary-1);"><?= htmlspecialchars($kelas) ?></h4>
                    </div>
                    <div class="grid grid-cols-3 gap-2 text-center">
                        <div>
                            <p class="text-lg font-bold" style="color: #77BFA3;"><?= $data['hadir'] ?></p>
                            <p class="text-[0.6rem] text-gray-500">Hadir</p>
                        </div>
                        <div>
                            <p class="text-lg font-bold" style="color: #FFB347;"><?= $data['sakit'] ?></p>
                            <p class="text-[0.6rem] text-gray-500">Sakit</p>
                        </div>
                        <div>
                            <p class="text-lg font-bold" style="color: #66999B;"><?= $data['izin'] ?></p>
                            <p class="text-[0.6rem] text-gray-500">Izin</p>
                        </div>
                        <div>
                            <p class="text-lg font-bold" style="color: #E58C7C;"><?= $data['alpha'] ?></p>
                            <p class="text-[0.6rem] text-gray-500">Alpha</p>
                        </div>
                        <div>
                            <p class="text-lg font-bold" style="color: #DDB7AB;"><?= $data['terlambat'] ?></p>
                            <p class="text-[0.6rem] text-gray-500">Telat</p>
                        </div>
                        <div>
                            <p class="text-lg font-bold" style="color: var(--primary-1);"><?= $data['total'] ?></p>
                            <p class="text-[0.6rem] text-gray-500">Total</p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- TABEL DATA ABSENSI -->
            <div class="table-container print-area">
                <div class="p-4 border-b border-gray-200 bg-gray-50 print:bg-white no-print">
                    <h3 class="font-bold text-sm" style="color: var(--primary-1);">
                        <i class="fas fa-list mr-2"></i>
                        Data Absensi 
                        <?php if($filter_tipe == 'harian'): ?>
                            (<?= date('d/m/Y', strtotime($filter_tanggal)) ?>)
                        <?php elseif($filter_tipe == 'rentang'): ?>
                            (<?= date('d/m/Y', strtotime($filter_tanggal)) ?> - <?= date('d/m/Y', strtotime($filter_tanggal_akhir)) ?>)
                        <?php else: ?>
                            (<?= getNamaBulan($filter_bulan) ?> <?= $filter_tahun ?>)
                        <?php endif; ?>
                    </h3>
                </div>

                <!-- Header untuk Print -->
                <div class="hidden print:block p-4 text-center">
                    <h2 class="text-xl font-bold">LAPORAN ABSENSI</h2>
                    <h3 class="text-lg">SMK NEGERI 8 BANDAR LAMPUNG</h3>
                    <p class="text-sm">
                        <?php if($filter_tipe == 'harian'): ?>
                            Tanggal: <?= date('d/m/Y', strtotime($filter_tanggal)) ?>
                        <?php elseif($filter_tipe == 'rentang'): ?>
                            Periode: <?= date('d/m/Y', strtotime($filter_tanggal)) ?> - <?= date('d/m/Y', strtotime($filter_tanggal_akhir)) ?>
                        <?php else: ?>
                            Bulan: <?= getNamaBulan($filter_bulan) ?> <?= $filter_tahun ?>
                        <?php endif; ?>
                        | Role: <?= ucfirst($filter_role) ?>
                    </p>
                    <hr class="my-2">
                </div>

                <table id="tabel-absensi">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Role</th>
                            <?php if($filter_role != 'pengawas'): ?>
                            <th>Kelas</th>
                            <?php endif; ?>
                            <th>Jam Datang</th>
                            <th>Jam Pulang</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($data_absensi)): ?>
                        <tr>
                            <td colspan="10" class="text-center py-8 text-gray-400">
                                <i class="fas fa-folder-open text-4xl mb-2 block"></i>
                                Tidak ada data absensi
                            </td>
                        </tr>
                        <?php else: ?>
                            <?php $no = 1; ?>
                            <?php foreach ($data_absensi as $d): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $d['tgl_format'] ?? date('d/m/Y', strtotime($d['tanggal'])) ?></td>
                                <td class="font-semibold"><?= htmlspecialchars($d['nama_lengkap']) ?></td>
                                <td><?= htmlspecialchars($d['username'] ?? '-') ?></td>
                                <td>
                                    <span class="px-2 py-1 text-xs rounded-full <?= $d['role'] == 'siswa' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800' ?>">
                                        <?= ucfirst($d['role']) ?>
                                    </span>
                                </td>
                                <?php if($filter_role != 'pengawas'): ?>
                                <td><?= htmlspecialchars($d['nama_kelas'] ?? '-') ?></td>
                                <?php endif; ?>
                                <td><?= $d['jam_datang'] ?? '-' ?></td>
                                <td><?= $d['jam_pulang'] ?? '-' ?></td>
                                <td>
                                    <span class="badge-status badge-<?= $d['status'] ?>">
                                        <?= ucfirst($d['status']) ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($d['keterangan'] ?? '-') ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Footer Total -->
                <div class="p-4 border-t border-gray-200 bg-gray-50 print:bg-white">
                    <div class="flex justify-between items-center">
                        <p class="text-sm font-semibold">Total Data: <?= count($data_absensi) ?></p>
                        <p class="text-xs text-gray-500 print:hidden">
                            <i class="fas fa-info-circle mr-1"></i>
                            Klik tombol Export untuk mengunduh data
                        </p>
                    </div>
                </div>
            </div>

            <!-- FOOTER -->
            <div class="mt-6 text-center text-xs text-gray-500 no-print">
                <p>© 2026 SMK Negeri 8 Bandar Lampung. All rights reserved.</p>
            </div>
        </main>
    </div>

    <script>
        // Fungsi toggle dropdown
        function toggleDropdown(id) {
            const dropdown = document.getElementById(id);
            const toggle = event.currentTarget;
            dropdown.classList.toggle('open');
            toggle.classList.toggle('open');
        }

        // Fungsi toggle tipe filter
        function toggleTipe() {
            const tipe = document.getElementById('tipe').value;
            document.getElementById('filter-harian').style.display = tipe == 'harian' ? 'grid' : 'none';
            document.getElementById('filter-rentang').style.display = tipe == 'rentang' ? 'grid' : 'none';
            document.getElementById('filter-bulanan').style.display = tipe == 'bulanan' ? 'grid' : 'none';
        }

        // Fungsi toggle role
        function toggleRole() {
            const role = document.getElementById('role').value;
            document.getElementById('filter-siswa').style.display = role == 'pengawas' ? 'none' : 'grid';
        }

        // Export ke Excel
        function exportToExcel() {
            const table = document.getElementById('tabel-absensi');
            const wb = XLSX.utils.table_to_book(table, {sheet: "Absensi"});
            const filename = `Absensi_<?= date('Ymd') ?>_${new Date().getTime()}.xlsx`;
            XLSX.writeFile(wb, filename);
            
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data berhasil diexport ke Excel',
                timer: 1500,
                showConfirmButton: false
            });
        }

        // Export ke PDF
        function exportToPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('landscape');
            
            doc.setFontSize(16);
            doc.text('LAPORAN ABSENSI', 14, 20);
            doc.setFontSize(12);
            doc.text('SMK NEGERI 8 BANDAR LAMPUNG', 14, 28);
            doc.setFontSize(10);
            
            let title = '';
            <?php if($filter_tipe == 'harian'): ?>
                title = 'Tanggal: <?= date('d/m/Y', strtotime($filter_tanggal)) ?>';
            <?php elseif($filter_tipe == 'rentang'): ?>
                title = 'Periode: <?= date('d/m/Y', strtotime($filter_tanggal)) ?> - <?= date('d/m/Y', strtotime($filter_tanggal_akhir)) ?>';
            <?php else: ?>
                title = 'Bulan: <?= getNamaBulan($filter_bulan) ?> <?= $filter_tahun ?>';
            <?php endif; ?>
            
            doc.text(title, 14, 36);
            doc.text('Role: <?= ucfirst($filter_role) ?>', 14, 42);
            
            // Ambil data dari tabel
            const table = document.getElementById('tabel-absensi');
            const headers = [];
            const data = [];
            
            // Ambil header
            const headerCells = table.querySelectorAll('thead th');
            headerCells.forEach(cell => {
                headers.push(cell.innerText);
            });
            
            // Ambil data
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const rowData = [];
                const cells = row.querySelectorAll('td');
                cells.forEach(cell => {
                    rowData.push(cell.innerText);
                });
                data.push(rowData);
            });
            
            doc.autoTable({
                head: [headers],
                body: data,
                startY: 50,
                styles: { fontSize: 8 },
                headStyles: { fillColor: [43, 58, 103] }
            });
            
            doc.save(`Absensi_<?= date('Ymd') ?>.pdf`);
            
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data berhasil diexport ke PDF',
                timer: 1500,
                showConfirmButton: false
            });
        }

        // Inisialisasi flatpickr untuk tanggal
        flatpickr("input[type=date]", {
            dateFormat: "Y-m-d"
        });

        // SweetAlert untuk notifikasi
        <?php if(isset($_GET['success'])): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: 'Data absensi berhasil disimpan',
            timer: 2000,
            showConfirmButton: false
        });
        <?php endif; ?>
    </script>
</body>

</html>