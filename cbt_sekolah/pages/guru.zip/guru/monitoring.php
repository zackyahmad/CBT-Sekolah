<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../../index.php"); exit;
}
 
$conn = new mysqli('localhost', 'root', '', 'db_ujian_sekolah');
if ($conn->connect_error) die("Koneksi gagal: " . $conn->connect_error);
$conn->set_charset("utf8");
 
$guru_id  = $_SESSION['id_user'] ?? 0;
$nama_guru = $_SESSION['nama_lengkap'] ?? $_SESSION['nama'] ?? 'Guru';
$ujian_id = isset($_GET['ujian_id']) ? (int)$_GET['ujian_id'] : 0;
 
// Daftar ujian milik guru
$ujian_list = $conn->query("SELECT * FROM ujian WHERE guru_id=$guru_id ORDER BY created_at DESC");
 
// Default ke ujian pertama
if (!$ujian_id && $ujian_list && $ujian_list->num_rows > 0) {
    $first    = $ujian_list->fetch_assoc();
    $ujian_id = $first['id'];
    $ujian_list->data_seek(0);
}
 
$detail_ujian = null;
$rows         = [];
$cnt          = ['total'=>0,'belum'=>0,'sedang'=>0,'selesai'=>0];
 
if ($ujian_id) {
    $q = $conn->query("SELECT * FROM ujian WHERE id=$ujian_id AND guru_id=$guru_id");
    if ($q && $q->num_rows > 0) {
        $detail_ujian = $q->fetch_assoc();
 
        // Ambil nama kelas dari ujian
        // Cek kolom mana yang ada: kelas / nama_kelas / id_kelas
        $nama_kelas = '';
        if (!empty($detail_ujian['kelas']))       $nama_kelas = $detail_ujian['kelas'];
        elseif (!empty($detail_ujian['nama_kelas'])) $nama_kelas = $detail_ujian['nama_kelas'];
 
        $nama_kelas_esc = $conn->real_escape_string($nama_kelas);
 
        if ($nama_kelas) {
            $res = $conn->query("
                SELECT u.id_user AS id, u.nama_lengkap AS nama, u.nis,
                       k.nama_kelas AS kelas,
                       n.status_pengerjaan AS status_ujian
                FROM tb_users u
                LEFT JOIN tb_kelas k ON k.id_kelas = u.id_kelas
                LEFT JOIN tb_nilai n ON n.id_siswa  = u.id_user
                                    AND n.id_ujian  = $ujian_id
                WHERE u.role = 'siswa'
                  AND k.nama_kelas = '$nama_kelas_esc'
                ORDER BY u.nama_lengkap ASC
            ");
        } else {
            // Kalau kelas kosong, tampilkan semua siswa yang pernah ikut ujian ini
            $res = $conn->query("
                SELECT u.id_user AS id, u.nama_lengkap AS nama, u.nis,
                       k.nama_kelas AS kelas,
                       n.status_pengerjaan AS status_ujian
                FROM tb_nilai n
                JOIN tb_users u ON u.id_user = n.id_siswa
                LEFT JOIN tb_kelas k ON k.id_kelas = u.id_kelas
                WHERE n.id_ujian = $ujian_id
                ORDER BY u.nama_lengkap ASC
            ");
        }
 
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = $r;
                $cnt['total']++;
                $s = $r['status_ujian'];
                if (!$s)              $cnt['belum']++;
                elseif($s==='selesai')$cnt['selesai']++;
                else                  $cnt['sedang']++;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Monitoring Ujian – CBT Sekolah</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <meta http-equiv="refresh" content="30">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
        * { font-family:'Inter',sans-serif; }
        .gradient-bg { background:linear-gradient(135deg,#0A192F 0%,#1E3A5F 30%,#F4A261 60%,#90BE6D 100%); background-size:200% 200%; animation:gm 10s ease infinite; }
        @keyframes gm { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        .btn-gradient { background:linear-gradient(135deg,#0A192F,#1E3A5F,#F4A261,#90BE6D); background-size:300% 300%; animation:bg 5s ease infinite; }
        @keyframes bg { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        tr:hover td { background:#f9fafb; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
 
<!-- HEADER -->
<header class="gradient-bg shadow-lg py-4 px-6 flex justify-between items-center sticky top-0 z-40">
    <div class="flex items-center space-x-3">
        <a href="dashboard.php" class="text-white/70 hover:text-white mr-1 transition">
            <i class="fas fa-arrow-left"></i>
        </a>
        <i class="fas fa-eye text-white text-xl"></i>
        <div>
            <h1 class="text-xl font-bold text-white">Monitoring Ujian</h1>
            <p class="text-white/60 text-xs">Auto-refresh setiap 30 detik</p>
        </div>
    </div>
    <div class="flex items-center gap-3">
        <a href="dashboard.php" class="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-xl text-sm font-semibold transition border border-white/30">
            <i class="fas fa-home mr-1"></i> Dashboard
        </a>
        <div class="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center border-2 border-white/50">
            <span class="text-white font-bold"><?= strtoupper(substr($nama_guru,0,1)) ?></span>
        </div>
    </div>
</header>
 
<main class="p-6 max-w-7xl mx-auto">
 
    <!-- Pilih ujian -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 mb-6">
        <form method="GET" class="flex gap-3 items-end flex-wrap">
            <div class="flex-1 min-w-[220px]">
                <label class="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-wide">Pilih Ujian</label>
                <select name="ujian_id" onchange="this.form.submit()"
                        class="w-full py-2.5 px-3 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#0A192F] outline-none">
                    <?php if ($ujian_list && $ujian_list->num_rows > 0):
                          while ($u = $ujian_list->fetch_assoc()): ?>
                    <option value="<?= $u['id'] ?>" <?= $u['id']==$ujian_id?'selected':'' ?>>
                        <?= htmlspecialchars($u['nama_ujian']) ?> [<?= ucfirst($u['status']??'draft') ?>]
                    </option>
                    <?php endwhile;
                    else: ?>
                    <option>Belum ada ujian</option>
                    <?php endif; ?>
                </select>
            </div>
            <button type="submit" class="btn-gradient text-white px-5 py-2.5 rounded-xl text-sm font-semibold">
                <i class="fas fa-sync mr-1"></i> Refresh
            </button>
        </form>
    </div>
 
    <?php if ($detail_ujian): ?>
 
    <!-- Info ujian -->
    <div class="bg-gradient-to-r from-[#0A192F] to-[#1E3A5F] rounded-2xl p-6 mb-6 text-white">
        <div class="flex justify-between items-start flex-wrap gap-4">
            <div>
                <h2 class="text-xl font-bold mb-2"><?= htmlspecialchars($detail_ujian['nama_ujian']) ?></h2>
                <div class="flex flex-wrap gap-4 text-sm text-white/80">
                    <span><i class="fas fa-book mr-1"></i><?= htmlspecialchars($detail_ujian['mata_pelajaran']??'-') ?></span>
                    <span><i class="fas fa-users mr-1"></i>Kelas: <?= htmlspecialchars(!empty($detail_ujian['kelas']) ? $detail_ujian['kelas'] : '-') ?></span>
                    <span><i class="fas fa-clock mr-1"></i>Durasi: <?= htmlspecialchars($detail_ujian['durasi']??'-') ?> menit</span>
                </div>
            </div>
            <?php $st=$detail_ujian['status']??'draft';
            $sc=$st==='aktif'?'bg-green-500':($st==='selesai'?'bg-gray-500':'bg-yellow-500'); ?>
            <span class="<?= $sc ?> px-4 py-1.5 rounded-full text-sm font-bold"><?= ucfirst($st) ?></span>
        </div>
    </div>
 
    <!-- Stat cards -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <?php
        $stats = [
            ['label'=>'Total Siswa',  'val'=>$cnt['total'],   'icon'=>'fa-users',       'color'=>'from-[#0A192F] to-[#1E3A5F]'],
            ['label'=>'Belum Mulai',  'val'=>$cnt['belum'],   'icon'=>'fa-hourglass',   'color'=>'from-yellow-400 to-yellow-500'],
            ['label'=>'Sedang Ujian', 'val'=>$cnt['sedang'],  'icon'=>'fa-pen',         'color'=>'from-blue-400 to-blue-500'],
            ['label'=>'Selesai',      'val'=>$cnt['selesai'], 'icon'=>'fa-check-circle','color'=>'from-green-400 to-green-500'],
        ];
        foreach ($stats as $stat): ?>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl bg-gradient-to-br <?= $stat['color'] ?> flex items-center justify-center flex-shrink-0">
                <i class="fas <?= $stat['icon'] ?> text-white text-lg"></i>
            </div>
            <div>
                <div class="text-2xl font-black text-gray-800"><?= $stat['val'] ?></div>
                <div class="text-xs text-gray-500 font-medium"><?= $stat['label'] ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
 
    <!-- Tabel siswa -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center gap-3">
            <i class="fas fa-list text-[#0A192F]"></i>
            <h3 class="font-bold text-gray-800">Status Pengerjaan Siswa</h3>
            <span class="bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded-full font-semibold"><?= $cnt['total'] ?> siswa</span>
        </div>
 
        <?php if (!empty($rows)): ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wide">
                    <tr>
                        <th class="px-4 py-3 text-left font-semibold w-10">No</th>
                        <th class="px-4 py-3 text-left font-semibold">NIS</th>
                        <th class="px-4 py-3 text-left font-semibold">Nama Siswa</th>
                        <th class="px-4 py-3 text-left font-semibold">Kelas</th>
                        <th class="px-4 py-3 text-left font-semibold">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                <?php $no=1; foreach ($rows as $r): ?>
                <tr>
                    <td class="px-4 py-3 text-gray-400"><?= $no++ ?></td>
                    <td class="px-4 py-3 text-gray-600"><?= htmlspecialchars($r['nis']??'-') ?></td>
                    <td class="px-4 py-3 font-semibold text-gray-800"><?= htmlspecialchars($r['nama']) ?></td>
                    <td class="px-4 py-3 text-gray-600"><?= htmlspecialchars($r['kelas']??'-') ?></td>
                    <td class="px-4 py-3">
                        <?php
                        $s = $r['status_ujian'];
                        if (!$s)              { $lbl='Belum Mulai'; $cls='bg-yellow-100 text-yellow-700'; }
                        elseif($s==='selesai'){ $lbl='Selesai';     $cls='bg-green-100 text-green-700'; }
                        else                  { $lbl='Sedang Ujian';$cls='bg-blue-100 text-blue-700'; }
                        ?>
                        <span class="<?= $cls ?> px-3 py-1 rounded-full text-xs font-bold"><?= $lbl ?></span>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
 
        <?php else: ?>
        <div class="py-16 text-center">
            <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-users text-gray-400 text-3xl"></i>
            </div>
            <h3 class="text-gray-600 font-semibold mb-2">Belum ada data siswa</h3>
            <p class="text-gray-400 text-sm">
                <?php if (empty($detail_ujian['kelas'])): ?>
                    Kolom kelas pada ujian ini belum diisi.
                <?php else: ?>
                    Tidak ada siswa di kelas <strong><?= htmlspecialchars($detail_ujian['kelas']) ?></strong>
                    atau siswa belum mulai mengerjakan.
                <?php endif; ?>
            </p>
        </div>
        <?php endif; ?>
    </div>
 
    <?php else: ?>
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 py-16 text-center">
        <i class="fas fa-clipboard-list text-gray-300 text-5xl mb-4"></i>
        <p class="text-gray-500">Pilih ujian untuk melihat monitoring.</p>
    </div>
    <?php endif; ?>
 
</main>
</body>
</html>
