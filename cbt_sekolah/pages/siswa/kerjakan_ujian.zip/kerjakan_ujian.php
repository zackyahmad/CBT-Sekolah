<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'siswa') {
    header("Location: ../../index.php"); exit;
}
require_once '../../config/koneksi.php';

$id_user = $_SESSION['id_user'];
$id_ujian = isset($_GET['id_ujian']) ? (int)$_GET['id_ujian'] : 0;

// 1. Ambil detail ujian
$stmt = $pdo->prepare("SELECT * FROM tb_ujian WHERE id_ujian = ?");
$stmt->execute([$id_ujian]);
$ujian = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$ujian) {
    die("<div style='text-align:center; padding:50px; font-family:sans-serif;'><h2>Ujian tidak ditemukan.</h2><a href='ujian.php'>Kembali</a></div>");
}

// ==========================================
// FUNGSI PINTAR DETEKSI JENIS SOAL
// ==========================================
function isPG($jenis) {
    if ($jenis === null || $jenis === '') return true; 
    $j = strtolower(trim((string)$jenis));
    return in_array($j, ['1', 'pg', 'pilihan ganda', 'pilihan_ganda']);
}

// 2. Ambil LANGSUNG semua soal beserta jenisnya
// PERBAIKAN: Menambahkan s.jenis_soal ke dalam query SELECT
$stmt_soal = $pdo->prepare("
    SELECT s.id_soal, s.pertanyaan, s.jenis_soal, s.opsi_a, s.opsi_b, s.opsi_c, s.opsi_d, s.opsi_e 
    FROM tb_ujian_soal us 
    JOIN tb_soal s ON us.id_soal = s.id_soal 
    WHERE us.id_ujian = ? 
    ORDER BY us.ditambahkan_pada ASC
");
$stmt_soal->execute([$id_ujian]);
$list_soal = $stmt_soal->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kerjakan Ujian - <?= htmlspecialchars($ujian['judul_ujian']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-slate-50 text-slate-700 font-sans p-4 md:p-8">
    <div class="max-w-4xl mx-auto">
        
        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-6 flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-black text-slate-800"><?= htmlspecialchars($ujian['judul_ujian']) ?></h1>
                <p class="text-slate-500 mt-1"><i class="fas fa-clock mr-1 text-blue-500"></i> Durasi: <?= $ujian['durasi_menit'] ?> Menit</p>
            </div>
            <div class="text-right">
                <p class="text-sm text-slate-500 font-bold uppercase tracking-wider">Total Soal</p>
                <p class="text-xl font-black text-blue-600"><?= count($list_soal) ?> Soal</p>
            </div>
        </div>

        <form action="proses_ujian.php" method="POST" id="formUjian">
            <input type="hidden" name="id_ujian" value="<?= $id_ujian ?>">

            <div class="space-y-6">
                <?php $no = 1; foreach ($list_soal as $soal): ?>
                    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                        <div class="flex gap-4">
                            <div class="w-10 h-10 flex-shrink-0 bg-blue-100 text-blue-600 font-bold rounded-xl flex items-center justify-center">
                                <?= $no++ ?>
                            </div>
                            
                            <div class="flex-1 w-full overflow-hidden">
                                <div class="text-slate-800 font-medium mb-4 leading-relaxed break-words prose max-w-none">
                                    <?= $soal['pertanyaan'] ?>
                                </div>

                                <div class="space-y-3">
                                    <?php if (isPG($soal['jenis_soal'])): ?>
                                        
                                        <?php
                                        $opsi = ['A' => $soal['opsi_a'], 'B' => $soal['opsi_b'], 'C' => $soal['opsi_c'], 'D' => $soal['opsi_d'], 'E' => $soal['opsi_e']];
                                        foreach ($opsi as $huruf => $teks_opsi): 
                                            // Validasi ekstra agar opsi yang benar-benar kosong tidak muncul bulatan radionya
                                            if (trim((string)$teks_opsi) !== ''): 
                                        ?>
                                            <label class="flex items-start p-3 border border-slate-200 rounded-xl cursor-pointer hover:bg-blue-50 hover:border-blue-200 transition group">
                                                <input type="radio" name="jawaban[<?= $soal['id_soal'] ?>]" value="<?= $huruf ?>" class="w-4 h-4 mt-1 text-blue-600 focus:ring-blue-500 border-gray-300">
                                                <span class="ml-3 text-slate-700 font-medium group-hover:text-blue-700 break-words">
                                                    <strong><?= $huruf ?>.</strong> <?= htmlspecialchars($teks_opsi) ?>
                                                </span>
                                            </label>
                                        <?php endif; endforeach; ?>

                                    <?php else: ?>
                                    
                                        <div class="bg-yellow-50 p-3 rounded-lg mb-2 text-xs text-yellow-800 border border-yellow-200">
                                            <i class="fas fa-pen mr-1"></i> Soal Uraian: Silakan ketik jawaban Anda secara lengkap.
                                        </div>
                                        <textarea name="jawaban[<?= $soal['id_soal'] ?>]" rows="6" placeholder="Ketik jawaban Anda di sini..."
                                                  class="w-full p-4 border border-slate-300 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-100 outline-none transition bg-slate-50 text-slate-800"></textarea>
                                                  
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-8 flex justify-end pb-10">
                <button type="button" onclick="konfirmasiSelesai()" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg shadow-blue-200 transition transform hover:-translate-y-1 flex items-center gap-2">
                    <i class="fas fa-paper-plane"></i> Selesaikan Ujian & Kumpulkan
                </button>
            </div>
        </form>
    </div>

    <script>
        function konfirmasiSelesai() {
            Swal.fire({
                title: 'Sudah Yakin Selesai?',
                text: "Pastikan semua soal pilihan ganda dan essay telah dijawab. Anda tidak bisa kembali setelah mengumpulkan ujian!",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#2563eb',
                cancelButtonColor: '#94a3b8',
                confirmButtonText: 'Ya, Kumpulkan Sekarang!',
                cancelButtonText: 'Cek Kembali'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('formUjian').submit();
                }
            })
        }
    </script>
</body>
</html>