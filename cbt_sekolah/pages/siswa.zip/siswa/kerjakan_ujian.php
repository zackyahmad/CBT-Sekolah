<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'siswa') {
    header("Location: ../../index.php"); exit;
}
require_once '../../config/koneksi.php';

$id_user = $_SESSION['id_user'];
$id_ujian = isset($_GET['id_ujian']) ? (int)$_GET['id_ujian'] : 0;

// 1. Ambil detail ujian (PERBAIKAN: Menggunakan tabel tb_ujian dan kolom id_ujian)
$stmt = $pdo->prepare("SELECT * FROM tb_ujian WHERE id_ujian = ?");
$stmt->execute([$id_ujian]);
$ujian = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$ujian) {
    die("<div style='text-align:center; padding:50px; font-family:sans-serif;'><h2>Ujian tidak ditemukan.</h2><a href='ujian.php'>Kembali</a></div>");
}

// 2. Ambil LANGSUNG semua soal yang ada di ujian ini menggunakan PHP
$stmt_soal = $pdo->prepare("
    SELECT s.id_soal, s.pertanyaan, s.opsi_a, s.opsi_b, s.opsi_c, s.opsi_d, s.opsi_e 
    FROM tb_ujian_soal us 
    JOIN tb_soal s ON us.id_soal = s.id_soal 
    WHERE us.id_ujian = ? 
    ORDER BY us.ditambahkan_pada ASC
");
$stmt_soal->execute([$id_ujian]);
$daftar_soal = $stmt_soal->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mengerjakan Ujian - <?= htmlspecialchars($ujian['judul_ujian'] ?? 'Ujian') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-100 min-h-screen">

    <div class="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-50">
        <div class="max-w-4xl mx-auto px-6 py-4 flex justify-between items-center">
            <div>
                <h1 class="text-xl font-bold text-slate-800"><?= htmlspecialchars($ujian['judul_ujian'] ?? 'Ujian') ?></h1>
                <p class="text-sm text-slate-500">
                    <i class="fas fa-user-graduate mr-1"></i> <?= htmlspecialchars($_SESSION['nama_lengkap'] ?? 'Siswa') ?>
                </p>
            </div>
            <div class="flex items-center gap-4">
                <a href="ujian.php" onclick="return confirm('Yakin ingin keluar? Jawaban Anda belum tersimpan.')" class="bg-red-100 text-red-600 hover:bg-red-200 px-4 py-2 rounded-lg transition text-sm font-semibold flex items-center gap-2">
                    <i class="fas fa-times"></i> Batal Ujian
                </a>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto px-6 py-8">
        
        <?php if (empty($daftar_soal)): ?>
            <div class="text-center py-20 bg-white rounded-2xl shadow-sm border border-slate-200">
                <i class="fas fa-file-excel text-6xl text-slate-300 mb-4 block"></i>
                <h3 class="font-bold text-slate-700 text-xl">Soal Belum Diberikan</h3>
                <p class="text-slate-500 mt-2">Guru belum memasukkan soal untuk ujian ini. Silakan kembali lagi nanti.</p>
                <a href="ujian.php" class="inline-block mt-6 bg-blue-600 text-white px-6 py-2 rounded-xl">Kembali</a>
            </div>
        <?php else: ?>
            <form action="proses_ujian.php" method="POST" id="form-ujian" onsubmit="return confirm('Yakin ingin mengumpulkan ujian ini? Pastikan semua terjawab.')">
                <input type="hidden" name="id_ujian" value="<?= $id_ujian ?>">
                
                <div class="space-y-6 mb-8">
                    <?php $no = 1; foreach ($daftar_soal as $soal): ?>
                        <div class="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200">
                            <div class="flex gap-4">
                                <div class="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold">
                                    <?= $no++ ?>
                                </div>
                                
                                <div class="flex-1">
                                    <p class="font-semibold text-slate-800 text-lg mb-4 leading-relaxed"><?= strip_tags($soal['pertanyaan']) ?></p>
                                    
                                    <div class="space-y-3">
    <?php if (($soal['jenis_soal'] ?? '1') == '1'): // JIKA SOAL PILIHAN GANDA ?>
        <?php 
        $opsi = ['A' => $soal['opsi_a'], 'B' => $soal['opsi_b'], 'C' => $soal['opsi_c'], 'D' => $soal['opsi_d'], 'E' => $soal['opsi_e']];
        foreach ($opsi as $huruf => $teks_opsi): 
            if (!empty($teks_opsi)): 
        ?>
            <label class="flex items-center p-3 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-50 transition">
                <input type="radio" name="jawaban[<?= $soal['id_soal'] ?>]" value="<?= $huruf ?>" class="w-4 h-4 text-blue-600 mr-3" required>
                <span class="text-slate-700 font-medium"><?= $huruf ?>. <?= htmlspecialchars($teks_opsi) ?></span>
            </label>
        <?php endif; endforeach; ?>

    <?php else: // JIKA SOAL ESSAY ?>
        <textarea name="jawaban[<?= $soal['id_soal'] ?>]" rows="5" placeholder="Ketik jawaban Anda di sini..." required
                  class="w-full p-4 border border-slate-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition bg-slate-50"></textarea>
    <?php endif; ?>
</div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg hover:shadow-xl transition flex items-center justify-center gap-2">
                    <i class="fas fa-paper-plane"></i> Selesai & Kumpulkan Ujian
                </button>
            </form>
        <?php endif; ?>

    </div>
</body>
</html>