<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'siswa') {
    header("Location: ../../index.php");
    exit;
}
require_once '../../config/koneksi.php';

// Ambil data siswa dari session dengan pengecekan key yang ada
$siswa_id = $_SESSION['user_id'] ?? $_SESSION['id_user'] ?? $_SESSION['id'] ?? 0;
$siswa_nis = $_SESSION['nis'] ?? $_SESSION['nis_siswa'] ?? '';
$siswa_nama = $_SESSION['nama'] ?? $_SESSION['nama_lengkap'] ?? 'Siswa';
$siswa_email = $_SESSION['email'] ?? $_SESSION['username'] ?? '';

// Jika session tidak lengkap, ambil dari database berdasarkan email/username
if (empty($siswa_nis) && !empty($siswa_email)) {
    $query_user = "SELECT * FROM tb_users WHERE (username = ? OR email = ?) AND role = 'siswa'";
    $stmt_user = $pdo->prepare($query_user);
    $stmt_user->execute([$siswa_email, $siswa_email]);
    $user_data = $stmt_user->fetch(PDO::FETCH_ASSOC);
    
    if ($user_data) {
        $siswa_id = $user_data['id_user'];
        $siswa_nis = $user_data['nis'] ?? '';
        $siswa_nama = $user_data['nama_lengkap'] ?? '';
        
        // Update session dengan data yang benar
        $_SESSION['user_id'] = $siswa_id;
        $_SESSION['nis'] = $siswa_nis;
        $_SESSION['nama'] = $siswa_nama;
    }
}

// Query untuk mengambil data kartu ujian dari database
$kartu = null;
$data_tersedia = false;

// Coba cari berdasarkan NIS terlebih dahulu
if (!empty($siswa_nis)) {
    try {
        $query = "SELECT * FROM tb_kartu_ujian WHERE nis = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$siswa_nis]);
        $kartu = $stmt->fetch(PDO::FETCH_ASSOC);
        $data_tersedia = ($kartu !== false);
    } catch (PDOException $e) {
        // Error jika kolom tidak ada
    }
}

// Jika tidak ditemukan, coba cari berdasarkan nama (fallback)
if (!$data_tersedia && !empty($siswa_nama)) {
    try {
        $query = "SELECT * FROM tb_kartu_ujian WHERE nama_siswa = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$siswa_nama]);
        $kartu = $stmt->fetch(PDO::FETCH_ASSOC);
        $data_tersedia = ($kartu !== false);
    } catch (PDOException $e) {
        // Error jika kolom tidak ada
    }
}

// Jika masih tidak ditemukan, coba cari semua kartu untuk siswa (berdasarkan NIS yang mirip atau nama)
if (!$data_tersedia) {
    try {
        // Coba cari dengan LIKE untuk NIS
        if (!empty($siswa_nis)) {
            $query = "SELECT * FROM tb_kartu_ujian WHERE nis LIKE ? LIMIT 1";
            $stmt = $pdo->prepare($query);
            $stmt->execute(["%{$siswa_nis}%"]);
            $kartu = $stmt->fetch(PDO::FETCH_ASSOC);
            $data_tersedia = ($kartu !== false);
        }
    } catch (PDOException $e) {
        // Error handling
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Ujian - <?= htmlspecialchars($siswa_nama) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: #f0f2f5;
            font-family: 'Segoe UI', 'Roboto', system-ui, sans-serif;
            min-height: 100vh;
            padding: 30px 20px;
        }

        .container {
            max-width: 550px;
            width: 100%;
            margin: 0 auto;
        }

        /* Kartu Ujian */
        .kartu-ujian {
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 25px;
            transition: transform 0.3s ease;
        }

        .kartu-ujian:hover {
            transform: translateY(-3px);
        }

        /* Header Sekolah */
        .header-sekolah {
            background: linear-gradient(135deg, #1a3c5e 0%, #2d5a8c 100%);
            color: white;
            padding: 20px;
            text-align: center;
        }

        .header-sekolah h3 {
            font-size: 16px;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }

        .header-sekolah p {
            font-size: 11px;
            opacity: 0.9;
        }

        /* Kop Surat */
        .kop-surat {
            background: #fef9e6;
            padding: 15px;
            text-align: center;
            border-bottom: 3px solid #ffc107;
        }

        .kop-surat .provinsi {
            font-size: 13px;
            font-weight: bold;
            color: #1a3c5e;
        }

        .kop-surat .dinas {
            font-size: 11px;
            font-weight: bold;
            color: #856404;
        }

        .kop-surat .alamat {
            font-size: 9px;
            color: #6c757d;
            margin-top: 5px;
        }

        /* Body Kartu */
        .body-kartu {
            padding: 20px;
            display: flex;
            gap: 20px;
            background: white;
        }

        /* Foto Section */
        .foto-area {
            width: 110px;
            text-align: center;
            flex-shrink: 0;
        }

        .foto-box {
            width: 100px;
            height: 120px;
            background: #f8f9fa;
            border: 2px solid #ffc107;
            border-radius: 10px;
            overflow: hidden;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .foto-box i {
            font-size: 50px;
            color: #adb5bd;
        }

        .foto-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .nis-badge {
            background: #ffc107;
            color: #1a3c5e;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: bold;
            display: inline-block;
        }

        /* Data Area */
        .data-area {
            flex: 1;
        }

        .info-row {
            display: flex;
            margin-bottom: 12px;
            font-size: 12px;
            border-bottom: 1px dashed #e9ecef;
            padding-bottom: 6px;
        }

        .info-label {
            width: 85px;
            font-weight: bold;
            color: #856404;
        }

        .info-value {
            flex: 1;
            color: #212529;
        }

        .info-value.bold {
            font-weight: bold;
            color: #1a3c5e;
        }

        /* Login Box */
        .login-box {
            background: #fef9e6;
            border-radius: 10px;
            padding: 12px;
            margin-top: 15px;
            border-left: 4px solid #ffc107;
        }

        .login-title {
            font-size: 10px;
            font-weight: bold;
            color: #ffc107;
            margin-bottom: 8px;
            text-transform: uppercase;
        }

        .login-info {
            display: flex;
            gap: 15px;
        }

        .login-item {
            flex: 1;
        }

        .login-label {
            font-size: 9px;
            color: #6c757d;
            display: block;
            margin-bottom: 5px;
        }

        .login-value {
            background: #1a3c5e;
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-family: monospace;
            display: inline-block;
        }

        .login-value.user {
            background: #28a745;
        }

        /* Footer */
        .footer-kartu {
            background: #fef9e6;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 10px;
            border-top: 1px solid #ffc107;
        }

        .ttd-area {
            text-align: center;
        }

        .ttd-line {
            width: 80px;
            height: 1px;
            background: #000;
            margin: 5px auto;
        }

        /* Tombol */
        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 10px;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .btn-cetak {
            background: #1a3c5e;
            color: white;
        }

        .btn-back {
            background: #e67e22;
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            opacity: 0.9;
        }

        /* Alert */
        .alert {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 10px;
            color: #856404;
            font-size: 14px;
            text-align: center;
        }

        .alert i {
            margin-right: 10px;
            font-size: 20px;
        }

        /* Print Style */
        @media print {
            body {
                background: white;
                padding: 0;
                margin: 0;
            }
            
            .action-buttons, .alert {
                display: none;
            }
            
            .kartu-ujian {
                box-shadow: none;
                margin: 0;
            }
            
            .kartu-ujian:hover {
                transform: none;
            }
            
            @page {
                size: A4;
                margin: 1cm;
            }
        }
    </style>
</head>
<body>
<div class="container">
    
    <!-- Header Selamat Datang -->
    <div style="background: white; border-radius: 12px; padding: 20px; text-align: center; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
        <i class="fas fa-id-card" style="font-size: 40px; color: #ffc107; margin-bottom: 10px;"></i>
        <h2 style="color: #1a3c5e; margin-bottom: 5px;">Kartu Ujian Digital</h2>
        <p>Halo, <strong><?= htmlspecialchars($siswa_nama) ?></strong> | NIS: <?= htmlspecialchars($siswa_nis ?: '-') ?></p>
    </div>

    <?php if (!$data_tersedia): ?>
        <!-- Data tidak ditemukan -->
        <div class="alert">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>Perhatian!</strong> Kartu ujian Anda belum tersedia.<br>
            Silahkan hubungi administrator untuk membuat kartu ujian.
        </div>
        
        <!-- Tombol Kembali -->
        <div class="action-buttons">
            <a href="dashboard.php" class="btn btn-back">
                <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
            </a>
        </div>
        
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'info',
                    title: 'Kartu Ujian Belum Tersedia',
                    text: 'Silahkan hubungi administrator untuk membuat kartu ujian Anda.',
                    confirmButtonColor: '#1a3c5e',
                    confirmButtonText: 'OK'
                });
            });
        </script>
        
    <?php else: ?>
        <!-- Kartu Ujian dari Database -->
        <div class="kartu-ujian" id="kartuUjian">
            <!-- Header Sekolah -->
            <div class="header-sekolah">
                <h3><i class="fas fa-school"></i> PEMERINTAH PROVINSI LAMPUNG</h3>
                <p>DINAS PENDIDIKAN DAN KEBUDAYAAN</p>
            </div>
            
            <!-- Kop Surat -->
            <div class="kop-surat">
                <div class="provinsi">SUMATIF TENGAH SEMESTER GENAP</div>
                <div class="dinas">TAHUN PELAJARAN 2024/2025</div>
                <div class="alamat">Jl. Imam Bonjol No. 52, Kemiling, Bandar Lampung 35153</div>
            </div>
            
            <!-- Body -->
            <div class="body-kartu">
                <!-- Foto -->
                <div class="foto-area">
                    <div class="foto-box">
                        <?php 
                        $foto_path = "../../uploads/" . ($kartu['foto_siswa'] ?? '');
                        if (!empty($kartu['foto_siswa']) && file_exists($foto_path)): 
                        ?>
                            <img src="<?= $foto_path ?>" alt="Foto Siswa">
                        <?php else: ?>
                            <i class="fas fa-user-graduate"></i>
                        <?php endif; ?>
                    </div>
                    <div class="nis-badge">
                        <i class="fas fa-qrcode"></i> NIS: <?= htmlspecialchars($kartu['nis'] ?? $siswa_nis) ?>
                    </div>
                </div>
                
                <!-- Data Siswa -->
                <div class="data-area">
                    <div class="info-row">
                        <div class="info-label">Nama Lengkap</div>
                        <div class="info-value bold">: <?= htmlspecialchars($kartu['nama_siswa'] ?? $siswa_nama) ?></div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">Kelas</div>
                        <div class="info-value">: <?= htmlspecialchars($kartu['kelas'] ?? '-') ?></div>
                    </div>
                    <?php if (!empty($kartu['jurusan']) && $kartu['jurusan'] != '-'): ?>
                    <div class="info-row">
                        <div class="info-label">Jurusan</div>
                        <div class="info-value">: <?= htmlspecialchars($kartu['jurusan']) ?></div>
                    </div>
                    <?php endif; ?>
                    <div class="info-row">
                        <div class="info-label">NISN</div>
                        <div class="info-value bold">: <?= htmlspecialchars($kartu['nisn'] ?? $kartu['sid'] ?? '-') ?></div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">Tempat, Tgl Lahir</div>
                        <div class="info-value">: <?= htmlspecialchars($kartu['tempat_lahir'] ?? '-') ?>, <?= !empty($kartu['tanggal_lahir']) ? date('d/m/Y', strtotime($kartu['tanggal_lahir'])) : '-' ?></div>
                    </div>
                    
                    <!-- Login Credentials -->
                    <div class="login-box">
                        <div class="login-title">
                            <i class="fas fa-key"></i> LOGIN UJIAN ONLINE
                        </div>
                        <div class="login-info">
                            <div class="login-item">
                                <span class="login-label">USERNAME</span>
                                <span class="login-value user">
                                    <i class="fas fa-user"></i> <?= htmlspecialchars($kartu['username_ujian'] ?? $kartu['nis'] ?? $siswa_nis) ?>
                                </span>
                            </div>
                            <div class="login-item">
                                <span class="login-label">PASSWORD</span>
                                <span class="login-value">
                                    <i class="fas fa-lock"></i> <?= htmlspecialchars($kartu['password_ujian'] ?? '123456') ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Footer -->
            <div class="footer-kartu">
                <div><i class="fas fa-calendar-alt"></i> Bandar Lampung, <?= date('d F Y') ?></div>
                <div class="ttd-area">
                    <div class="ttd-line"></div>
                    <span>Kepala Sekolah</span>
                </div>
                <div><i class="fas fa-stamp"></i> NIP. 19841121 200903 2 003</div>
            </div>
        </div>
        
        <!-- Tombol Aksi -->
        <div class="action-buttons">
            <button onclick="cetakKartu()" class="btn btn-cetak">
                <i class="fas fa-print"></i> Cetak / Unduh PDF
            </button>
            <a href="dashboard.php" class="btn btn-back">
                <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
            </a>
        </div>
        
        <script>
            function cetakKartu() {
                window.print();
            }
        </script>
        
    <?php endif; ?>
    
</div>
</body>
</html>