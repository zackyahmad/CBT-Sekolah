<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../../index.php"); exit;
}
require_once '../../config/koneksi.php';

$id_ujian = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$id_guru = $_SESSION['id_user'];

// Cek data ujian
$stmt = $pdo->prepare("SELECT * FROM ujian WHERE id = ? AND guru_id = ?");
$stmt->execute([$id_ujian, $id_guru]);
$ujian = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$ujian) { die("Ujian tidak ditemukan."); }

// PROSES TAMBAH DARI BANK SOAL
if (isset($_POST['tambah_dari_bank'])) {
    $id_soal = (int)$_POST['id_soal_bank'];
    // Cek apakah sudah ada
    $cek = $pdo->prepare("SELECT id_mapping FROM tb_ujian_soal WHERE id_ujian=? AND id_soal=?");
    $cek->execute([$id_ujian, $id_soal]);
    if ($cek->rowCount() == 0) {
        $pdo->prepare("INSERT INTO tb_ujian_soal (id_ujian, id_soal) VALUES (?, ?)")->execute([$id_ujian, $id_soal]);
    }
    header("Location: kelola_soal_ujian.php?id=$id_ujian"); exit;
}

// PROSES BUAT SOAL MANUAL & LANGSUNG MASUK UJIAN
if (isset($_POST['buat_soal_manual'])) {
    $pertanyaan = $_POST['pertanyaan'];
    $kunci = $_POST['kunci_jawaban'];
    $opsi_a = $_POST['opsi_a']; $opsi_b = $_POST['opsi_b']; $opsi_c = $_POST['opsi_c']; $opsi_d = $_POST['opsi_d']; $opsi_e = $_POST['opsi_e'];
    $id_mapel = $ujian['id_mapel'] ?? 1; // Sesuaikan jika ada id_mapel di tb_ujian

    // 1. Simpan ke Bank Soal (tb_soal)
    $stmt_soal = $pdo->prepare("INSERT INTO tb_soal (id_mapel, pertanyaan, jenis_soal, kunci_jawaban, opsi_a, opsi_b, opsi_c, opsi_d, opsi_e) VALUES (?, ?, 'pg', ?, ?, ?, ?, ?, ?)");
    $stmt_soal->execute([$id_mapel, $pertanyaan, $kunci, $opsi_a, $opsi_b, $opsi_c, $opsi_d, $opsi_e]);
    $id_soal_baru = $pdo->lastInsertId();

    // 2. Hubungkan ke Ujian (tb_ujian_soal)
    $pdo->prepare("INSERT INTO tb_ujian_soal (id_ujian, id_soal) VALUES (?, ?)")->execute([$id_ujian, $id_soal_baru]);
    
    header("Location: kelola_soal_ujian.php?id=$id_ujian"); exit;
}

// Ambil soal yang SUDAH masuk di ujian ini
$stmt_soal_ujian = $pdo->prepare("SELECT s.* FROM tb_ujian_soal us JOIN tb_soal s ON us.id_soal = s.id_soal WHERE us.id_ujian = ? ORDER BY us.ditambahkan_pada ASC");
$stmt_soal_ujian->execute([$id_ujian]);
$soal_ujian = $stmt_soal_ujian->fetchAll(PDO::FETCH_ASSOC);

// Ambil daftar bank soal yang BELUM ada di ujian ini
$stmt_bank = $pdo->prepare("SELECT id_soal, pertanyaan FROM tb_soal WHERE id_soal NOT IN (SELECT id_soal FROM tb_ujian_soal WHERE id_ujian = ?)");
$stmt_bank->execute([$id_ujian]);
$bank_soal = $stmt_bank->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Kelola Soal Ujian</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-5xl mx-auto bg-white p-6 rounded-lg shadow">
        <h1 class="text-2xl font-bold mb-2">Setting Soal Ujian: <?= htmlspecialchars($ujian['nama_ujian']) ?></h1>
        <p class="text-gray-500 mb-6">Soal yang Anda masukkan di sini akan langsung muncul di layar siswa secara realtime.</p>

        <div class="grid grid-cols-2 gap-8 mb-8">
            <div class="border p-4 rounded bg-blue-50">
                <h3 class="font-bold mb-3">1. Ambil dari Bank Soal</h3>
                <form method="POST">
                    <select name="id_soal_bank" class="w-full p-2 border rounded mb-3" required>
                        <option value="">-- Pilih Soal --</option>
                        <?php foreach($bank_soal as $b): ?>
                            <option value="<?= $b['id_soal'] ?>"><?= substr(strip_tags($b['pertanyaan']), 0, 50) ?>...</option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="tambah_dari_bank" class="bg-blue-600 text-white px-4 py-2 rounded">Tambahkan ke Ujian</button>
                </form>
            </div>

            <div class="border p-4 rounded bg-green-50">
                <h3 class="font-bold mb-3">2. Buat Soal Baru (Manual)</h3>
                <form method="POST" class="space-y-2">
                    <textarea name="pertanyaan" placeholder="Ketik pertanyaan di sini..." class="w-full p-2 border rounded" required></textarea>
                    <div class="grid grid-cols-2 gap-2">
                        <input type="text" name="opsi_a" placeholder="Opsi A" class="border p-2 rounded" required>
                        <input type="text" name="opsi_b" placeholder="Opsi B" class="border p-2 rounded" required>
                        <input type="text" name="opsi_c" placeholder="Opsi C" class="border p-2 rounded">
                        <input type="text" name="opsi_d" placeholder="Opsi D" class="border p-2 rounded">
                        <input type="text" name="opsi_e" placeholder="Opsi E" class="border p-2 rounded">
                        <select name="kunci_jawaban" class="border p-2 rounded" required>
                            <option value="">-- Kunci --</option>
                            <option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option><option value="E">E</option>
                        </select>
                    </div>
                    <button type="submit" name="buat_soal_manual" class="bg-green-600 text-white px-4 py-2 rounded mt-2">Buat & Masukkan ke Ujian</button>
                </form>
            </div>
        </div>

        <h3 class="font-bold text-lg border-b pb-2 mb-4">Daftar Soal di Ujian Ini (<?= count($soal_ujian) ?> Soal)</h3>
        <ol class="list-decimal pl-5 space-y-4">
            <?php foreach($soal_ujian as $s): ?>
                <li class="p-3 border rounded bg-gray-50">
                    <p class="font-semibold"><?= htmlspecialchars($s['pertanyaan']) ?></p>
                    <p class="text-sm text-gray-600">A. <?= $s['opsi_a'] ?> | B. <?= $s['opsi_b'] ?> (Kunci: <?= $s['kunci_jawaban'] ?>)</p>
                </li>
            <?php endforeach; ?>
        </ol>
    </div>
</body>
</html>