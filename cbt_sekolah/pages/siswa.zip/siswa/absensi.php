<?php
// =============================================
// FILE: pages/siswa/absensi.php
// Siswa input absensi → masuk ke verifikasi pengawas
// =============================================
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'siswa') {
    header("Location: ../../index.php"); exit;
}

$conn = new mysqli('localhost', 'root', '', 'db_ujian_sekolah');
if ($conn->connect_error) die("Koneksi gagal: " . $conn->connect_error);
$conn->set_charset("utf8");

$id_siswa  = $_SESSION['id_user'] ?? 0;
$nama_siswa = $_SESSION['nama_lengkap'] ?? '';

// Ambil data kelas siswa
$q = $conn->query("
    SELECT u.*, k.nama_kelas 
    FROM tb_users u 
    LEFT JOIN tb_kelas k ON k.id_kelas = u.id_kelas 
    WHERE u.id_user = $id_siswa LIMIT 1
");
$siswa     = $q ? $q->fetch_assoc() : [];
$nama_kelas = $siswa['nama_kelas'] ?? '-';
$nis        = $siswa['nis'] ?? '-';

$pesan = '';
$error = '';
$tanggal_hari_ini = date('Y-m-d');
$jam_sekarang     = date('H:i:s');

// ── Cek apakah sudah absen hari ini ──
$cek = $conn->query("
    SELECT * FROM absensi_siswa 
    WHERE nama_siswa = '" . $conn->real_escape_string($nama_siswa) . "'
      AND tanggal = '$tanggal_hari_ini'
    ORDER BY id DESC LIMIT 1
");
$sudah_absen  = ($cek && $cek->num_rows > 0);
$data_absen   = $sudah_absen ? $cek->fetch_assoc() : null;

// ── PROSES SUBMIT ABSENSI ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kirim_absensi'])) {
    if ($sudah_absen) {
        $error = 'Anda sudah melakukan absensi hari ini.';
    } else {
        $keterangan  = $_POST['keterangan'] ?? 'Hadir';
        $ket_allowed = ['Hadir', 'Sakit', 'Izin'];
        
        if (!in_array($keterangan, $ket_allowed)) {
            $error = 'Keterangan tidak valid.';
        } else {
            $nm  = $conn->real_escape_string($nama_siswa);
            $kls = $conn->real_escape_string($nama_kelas);
            $ket = $conn->real_escape_string($keterangan);

            $insert = $conn->query("
    INSERT INTO absensi_siswa 
        (id_user, nama_siswa, kelas, tanggal, jam, keterangan, status_verifikasi, created_at)
    VALUES 
        ($id_siswa, '$nm', '$kls', '$tanggal_hari_ini', '$jam_sekarang', '$ket', 'menunggu', NOW())
");

            if ($insert) {
                $pesan = 'Absensi berhasil dikirim! Menunggu verifikasi pengawas.';
                // Refresh data
                $cek2 = $conn->query("SELECT * FROM absensi_siswa WHERE id = " . $conn->insert_id);
                $data_absen  = $cek2 ? $cek2->fetch_assoc() : null;
                $sudah_absen = true;
            } else {
                $error = 'Gagal menyimpan absensi: ' . $conn->error;
            }
        }
    }
}

// ── Riwayat absensi 30 hari terakhir ──
$nm_esc   = $conn->real_escape_string($nama_siswa);
$riwayat  = $conn->query("
    SELECT * FROM absensi_siswa 
    WHERE nama_siswa = '$nm_esc'
    ORDER BY tanggal DESC, id DESC
    LIMIT 30
");
$data_riwayat = [];
if ($riwayat) while ($r = $riwayat->fetch_assoc()) $data_riwayat[] = $r;

// Hitung statistik
$stat = ['hadir'=>0,'sakit'=>0,'izin'=>0,'menunggu'=>0];
foreach ($data_riwayat as $r) {
    if ($r['status_verifikasi'] === 'menunggu') $stat['menunggu']++;
    elseif ($r['keterangan'] === 'Hadir')       $stat['hadir']++;
    elseif ($r['keterangan'] === 'Sakit')        $stat['sakit']++;
    elseif ($r['keterangan'] === 'Izin')         $stat['izin']++;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Absensi Siswa – CBT Sekolah</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --primary-1:#2B3A67; --primary-2:#496A81;
            --secondary-1:#66999B; --secondary-2:#B3AF8F;
            --accent-1:#FFC482; --accent-2:#DDB7AB;
            --neutral-1:#F8F4E9; --neutral-2:#E8E1D3;
            --dark:#2E3B4E; --success:#77BFA3;
            --warning:#FFB347; --danger:#E58C7C;
        }
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Poppins',sans-serif; }
        body { background:linear-gradient(135deg,var(--neutral-1) 0%,var(--neutral-2) 100%); display:flex; min-height:100vh; }

        /* SIDEBAR — sama dengan dashboard siswa */
        .sidebar { width:280px; background:linear-gradient(135deg,var(--primary-1) 0%,var(--primary-2) 100%); color:white; padding:25px 20px; position:fixed; height:100vh; top:0; left:0; overflow-y:auto; z-index:100; box-shadow:4px 0 20px rgba(0,0,0,.1); }
        .logo { text-align:center; margin-bottom:30px; padding-bottom:20px; border-bottom:2px solid rgba(255,255,255,.2); }
        .logo h2 { font-size:24px; font-weight:700; background:linear-gradient(135deg,var(--accent-1),var(--accent-2)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .logo h4 { font-size:14px; margin-top:5px; opacity:.9; }
        .logo p { font-size:12px; color:rgba(255,255,255,.7); }
        .user-profile { text-align:center; margin-bottom:30px; padding-bottom:20px; border-bottom:2px solid rgba(255,255,255,.2); }
        .user-profile h5 { font-size:15px; font-weight:600; margin-bottom:4px; }
        .user-profile p { font-size:12px; color:rgba(255,255,255,.8); }
        .sidebar a { display:flex; align-items:center; gap:12px; text-decoration:none; color:rgba(255,255,255,.8); padding:12px 15px; border-radius:12px; margin-bottom:8px; transition:all .3s; font-size:14px; font-weight:500; }
        .sidebar a:hover, .sidebar a.active { background:rgba(255,255,255,.15); color:white; transform:translateX(5px); }
        .sidebar a i { width:22px; text-align:center; font-size:16px; }

        /* MAIN */
        .main { margin-left:280px; width:calc(100% - 280px); padding:28px; min-height:100vh; }

        /* TOPBAR */
        .topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:28px; }
        .topbar h1 { font-size:26px; font-weight:700; background:linear-gradient(135deg,var(--primary-1),var(--primary-2)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .topbar p { font-size:12px; color:var(--secondary-2); margin-top:3px; }
        .time-box { background:white; padding:12px 22px; border-radius:30px; box-shadow:0 4px 15px rgba(0,0,0,.08); font-size:14px; font-weight:600; color:var(--primary-1); }

        /* ALERT */
        .alert { padding:14px 18px; border-radius:14px; margin-bottom:20px; display:flex; align-items:center; gap:10px; font-size:14px; font-weight:500; }
        .alert-success { background:#d1fae5; color:#065f46; border-left:4px solid var(--success); }
        .alert-danger  { background:#fee2e2; color:#991b1b; border-left:4px solid var(--danger); }

        /* CARD */
        .card { background:white; border-radius:20px; padding:24px; margin-bottom:24px; box-shadow:0 5px 20px rgba(0,0,0,.05); border:1px solid rgba(0,0,0,.05); }
        .card-title { font-size:17px; font-weight:700; color:var(--primary-1); margin-bottom:20px; display:flex; align-items:center; gap:10px; }
        .card-title i { color:var(--accent-1); }

        /* STATUS HARI INI */
        .status-card { border-radius:16px; padding:20px 24px; display:flex; align-items:center; gap:16px; }
        .status-menunggu { background:linear-gradient(135deg,#fef3c7,#fde68a); }
        .status-disetujui { background:linear-gradient(135deg,#d1fae5,#a7f3d0); }
        .status-ditolak   { background:linear-gradient(135deg,#fee2e2,#fecaca); }
        .status-belum     { background:linear-gradient(135deg,#eff6ff,#dbeafe); }
        .status-icon { width:52px; height:52px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0; }

        /* FORM ABSENSI */
        .absen-options { display:grid; grid-template-columns:repeat(3,1fr); gap:14px; margin-bottom:20px; }
        .absen-option input[type="radio"] { display:none; }
        .absen-option label { display:flex; flex-direction:column; align-items:center; gap:10px; padding:20px 14px; border-radius:16px; border:2px solid var(--neutral-2); cursor:pointer; transition:all .3s; text-align:center; font-size:13px; font-weight:600; color:var(--dark); }
        .absen-option label i { font-size:28px; }
        .absen-option input:checked + label { border-color:var(--primary-1); background:rgba(43,58,103,.06); }
        .hadir-opt:checked + label  { border-color:var(--success)!important; background:#f0fdf4!important; color:var(--success)!important; }
        .sakit-opt:checked + label  { border-color:var(--warning)!important; background:#fffbeb!important; color:var(--warning)!important; }
        .izin-opt:checked + label   { border-color:var(--primary-2)!important; background:#eff6ff!important; color:var(--primary-2)!important; }

        .btn-submit { background:linear-gradient(135deg,var(--primary-1),var(--primary-2)); color:white; padding:14px 32px; border-radius:30px; border:none; font-family:inherit; font-size:15px; font-weight:700; cursor:pointer; transition:all .3s; display:inline-flex; align-items:center; gap:10px; }
        .btn-submit:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(43,58,103,.3); }

        /* STATS */
        .stats-row { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:24px; }
        .stat { background:white; border-radius:16px; padding:16px; text-align:center; box-shadow:0 3px 12px rgba(0,0,0,.05); }
        .stat .val { font-size:26px; font-weight:800; }
        .stat .lbl { font-size:11px; color:var(--secondary-2); font-weight:500; margin-top:3px; }
        .val-hadir   { color:var(--success); }
        .val-sakit   { color:var(--warning); }
        .val-izin    { color:var(--primary-2); }
        .val-menunggu{ color:var(--danger); }

        /* TABLE */
        table { width:100%; border-collapse:collapse; font-size:13px; }
        th { padding:11px 14px; text-align:left; font-size:11px; font-weight:700; color:var(--secondary-2); background:var(--neutral-1); border-bottom:1px solid var(--neutral-2); text-transform:uppercase; letter-spacing:.5px; }
        td { padding:12px 14px; border-bottom:1px solid var(--neutral-2); color:var(--dark); vertical-align:middle; }
        tr:last-child td { border-bottom:none; }
        tr:hover td { background:var(--neutral-1); }
        .badge { display:inline-flex; align-items:center; gap:5px; padding:4px 12px; border-radius:20px; font-size:11px; font-weight:700; }
        .badge-menunggu  { background:#fef3c7; color:#92400e; }
        .badge-disetujui { background:#d1fae5; color:#065f46; }
        .badge-ditolak   { background:#fee2e2; color:#991b1b; }
        .badge-hadir  { background:#d1fae5; color:#065f46; }
        .badge-sakit  { background:#fef3c7; color:#92400e; }
        .badge-izin   { background:#dbeafe; color:#1e40af; }

        @media(max-width:768px) {
            .sidebar { transform:translateX(-280px); }
            .main { margin-left:0; width:100%; padding:16px; }
            .stats-row { grid-template-columns:repeat(2,1fr); }
            .absen-options { grid-template-columns:repeat(3,1fr); }
        }
    </style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="logo">
        <h2>CBT</h2>
        <h4>SMK N 8 BANDAR LAMPUNG</h4>
        <p>Sistem Ujian Online</p>
    </div>
    <div class="user-profile">
        <h5><?= htmlspecialchars($nama_siswa) ?></h5>
        <p>NIS: <?= htmlspecialchars($nis) ?> | <?= htmlspecialchars($nama_kelas) ?></p>
    </div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="tatatertib.php"><i class="fas fa-gavel"></i> Tata Tertib</a>
    <a href="kartu_ujian.php"><i class="fas fa-id-card"></i> Kartu Ujian</a>
    <a href="absensi.php" class="active"><i class="fas fa-check-circle"></i> Absensi</a>
    <a href="ujian.php"><i class="fas fa-pen"></i> Ujian</a>
    <a href="javascript:void(0)" onclick="if(confirm('Yakin ingin logout?')) window.location.href='../../logout.php'" style="color:#E58C7C;margin-top:auto">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
</div>

<!-- MAIN -->
<div class="main">
    <div class="topbar">
        <div>
            <h1>Absensi</h1>
            <p>Catat kehadiran Anda hari ini</p>
        </div>
        <div class="time-box" id="jam"></div>
    </div>

    <?php if ($pesan): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($pesan) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Status hari ini -->
    <div class="card">
        <div class="card-title"><i class="fas fa-calendar-day"></i> Status Absensi Hari Ini — <?= date('d/m/Y') ?></div>

        <?php if ($sudah_absen && $data_absen): ?>
        <?php
            $st  = $data_absen['status_verifikasi'];
            $ket = $data_absen['keterangan'];
            $cls = $st === 'disetujui' ? 'status-disetujui' : ($st === 'ditolak' ? 'status-ditolak' : 'status-menunggu');
            $ico = $st === 'disetujui' ? '✅' : ($st === 'ditolak' ? '❌' : '⏳');
            $lbl = $st === 'disetujui' ? 'Disetujui Pengawas' : ($st === 'ditolak' ? 'Ditolak Pengawas' : 'Menunggu Verifikasi');
        ?>
        <div class="status-card <?= $cls ?>">
            <div class="status-icon"><?= $ico ?></div>
            <div>
                <div style="font-weight:700;font-size:16px;color:var(--dark)"><?= $lbl ?></div>
                <div style="font-size:13px;color:var(--secondary-1);margin-top:4px">
                    Keterangan: <strong><?= $ket ?></strong> |
                    Jam: <strong><?= substr($data_absen['jam'],0,5) ?> WIB</strong>
                </div>
                <?php if ($st === 'ditolak' && $data_absen['catatan_verifikasi']): ?>
                <div style="font-size:12px;color:#991b1b;margin-top:6px">
                    Catatan: <?= htmlspecialchars($data_absen['catatan_verifikasi']) ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <?php else: ?>
        <!-- Form absensi -->
        <form method="POST">
            <p style="font-size:14px;color:var(--secondary-1);margin-bottom:16px">Pilih keterangan kehadiran Anda hari ini:</p>
            <div class="absen-options">
                <div class="absen-option">
                    <input type="radio" name="keterangan" value="Hadir" id="hadir" class="hadir-opt" checked>
                    <label for="hadir">
                        <i class="fas fa-check-circle" style="color:var(--success)"></i>
                        Hadir
                    </label>
                </div>
                <div class="absen-option">
                    <input type="radio" name="keterangan" value="Sakit" id="sakit" class="sakit-opt">
                    <label for="sakit">
                        <i class="fas fa-thermometer-half" style="color:var(--warning)"></i>
                        Sakit
                    </label>
                </div>
                <div class="absen-option">
                    <input type="radio" name="keterangan" value="Izin" id="izin" class="izin-opt">
                    <label for="izin">
                        <i class="fas fa-envelope" style="color:var(--primary-2)"></i>
                        Izin
                    </label>
                </div>
            </div>
            <button type="submit" name="kirim_absensi" class="btn-submit">
                <i class="fas fa-paper-plane"></i> Kirim Absensi
            </button>
        </form>
        <?php endif; ?>
    </div>

    <!-- Statistik -->
    <div class="stats-row">
        <div class="stat">
            <div class="val val-hadir"><?= $stat['hadir'] ?></div>
            <div class="lbl">Hadir</div>
        </div>
        <div class="stat">
            <div class="val val-sakit"><?= $stat['sakit'] ?></div>
            <div class="lbl">Sakit</div>
        </div>
        <div class="stat">
            <div class="val val-izin"><?= $stat['izin'] ?></div>
            <div class="lbl">Izin</div>
        </div>
        <div class="stat">
            <div class="val val-menunggu"><?= $stat['menunggu'] ?></div>
            <div class="lbl">Menunggu</div>
        </div>
    </div>

    <!-- Riwayat -->
    <div class="card">
        <div class="card-title"><i class="fas fa-history"></i> Riwayat Absensi (30 Hari Terakhir)</div>
        <?php if (!empty($data_riwayat)): ?>
        <div style="overflow-x:auto">
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                        <th>Keterangan</th>
                        <th>Status Verifikasi</th>
                        <th>Catatan Pengawas</th>
                    </tr>
                </thead>
                <tbody>
                <?php $no=1; foreach ($data_riwayat as $r): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= date('d/m/Y', strtotime($r['tanggal'])) ?></td>
                    <td><?= substr($r['jam'],0,5) ?> WIB</td>
                    <td>
                        <?php
                        $kls_ket = $r['keterangan']==='Hadir'?'badge-hadir':($r['keterangan']==='Sakit'?'badge-sakit':'badge-izin');
                        $ico_ket = $r['keterangan']==='Hadir'?'✅':($r['keterangan']==='Sakit'?'🤒':'📝');
                        ?>
                        <span class="badge <?= $kls_ket ?>"><?= $ico_ket ?> <?= $r['keterangan'] ?></span>
                    </td>
                    <td>
                        <?php
                        $sv = $r['status_verifikasi'];
                        $sc = $sv==='disetujui'?'badge-disetujui':($sv==='ditolak'?'badge-ditolak':'badge-menunggu');
                        $si = $sv==='disetujui'?'✅':($sv==='ditolak'?'❌':'⏳');
                        $sl = $sv==='disetujui'?'Disetujui':($sv==='ditolak'?'Ditolak':'Menunggu');
                        ?>
                        <span class="badge <?= $sc ?>"><?= $si ?> <?= $sl ?></span>
                    </td>
                    <td style="font-size:12px;color:var(--secondary-2)">
                        <?= htmlspecialchars($r['catatan_verifikasi'] ?: '-') ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div style="text-align:center;padding:40px;color:var(--secondary-2)">
            <i class="fas fa-calendar-times" style="font-size:40px;opacity:.3;margin-bottom:10px;display:block"></i>
            <p>Belum ada riwayat absensi.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function updateClock() {
    const now = new Date();
    const h = String(now.getHours()).padStart(2,'0');
    const m = String(now.getMinutes()).padStart(2,'0');
    const s = String(now.getSeconds()).padStart(2,'0');
    document.getElementById('jam').textContent = h+':'+m+':'+s+' WIB';
}
setInterval(updateClock,1000);
updateClock();
</script>
</body>
</html>