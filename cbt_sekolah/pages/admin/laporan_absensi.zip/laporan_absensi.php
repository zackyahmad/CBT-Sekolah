<?php
session_start();
// Cek sesi admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit;
}
require_once '../../config/koneksi.php';

// Set timezone
date_default_timezone_set('Asia/Jakarta');

// Ambil parameter filter
$filter_bulan = $_GET['bulan'] ?? date('m');
$filter_tahun = $_GET['tahun'] ?? date('Y');
$filter_kelas = $_GET['kelas'] ?? '';
$filter_status = $_GET['status'] ?? '';
$filter_tipe = $_GET['tipe'] ?? 'siswa'; // siswa atau guru

// Ambil data kelas untuk filter
$kelas_list = $pdo->query("SELECT * FROM tb_kelas ORDER BY nama_kelas ASC")->fetchAll();

// Ambil data rekap absensi siswa
$rekap_siswa = [];
$total_siswa = 0;
$total_hadir = 0;
$total_sakit = 0;
$total_izin = 0;
$total_alpha = 0;
$total_terlambat = 0;

try {
    // Query rekap siswa per bulan
    $query_siswa = "SELECT 
        u.id_user,
        u.nama_lengkap,
        u.username,
        k.nama_kelas,
        COUNT(CASE WHEN a.status = 'hadir' THEN 1 END) as hadir,
        COUNT(CASE WHEN a.status = 'sakit' THEN 1 END) as sakit,
        COUNT(CASE WHEN a.status = 'izin' THEN 1 END) as izin,
        COUNT(CASE WHEN a.status = 'alpha' THEN 1 END) as alpha,
        COUNT(CASE WHEN a.status = 'terlambat' THEN 1 END) as terlambat,
        COUNT(a.id_absensi) as total_absensi,
        ROUND((COUNT(CASE WHEN a.status IN ('hadir', 'terlambat') THEN 1 END) / 25) * 100, 2) as persentase
    FROM tb_users u
    LEFT JOIN tb_kelas k ON u.id_kelas = k.id_kelas
    LEFT JOIN tb_absensi a ON u.id_user = a.id_user 
        AND MONTH(a.tanggal) = :bulan 
        AND YEAR(a.tanggal) = :tahun
    WHERE u.role = 'siswa'";
    
    $params = [
        ':bulan' => $filter_bulan,
        ':tahun' => $filter_tahun
    ];
    
    if (!empty($filter_kelas)) {
        $query_siswa .= " AND u.id_kelas = :kelas";
        $params[':kelas'] = $filter_kelas;
    }
    
    $query_siswa .= " GROUP BY u.id_user ORDER BY k.nama_kelas, u.nama_lengkap ASC";
    
    $stmt = $pdo->prepare($query_siswa);
    $stmt->execute($params);
    $rekap_siswa = $stmt->fetchAll();
    
    // Hitung total
    foreach ($rekap_siswa as $r) {
        $total_siswa++;
        $total_hadir += $r['hadir'];
        $total_sakit += $r['sakit'];
        $total_izin += $r['izin'];
        $total_alpha += $r['alpha'];
        $total_terlambat += $r['terlambat'];
    }
    
} catch (PDOException $e) {
    $error_siswa = "Error: " . $e->getMessage();
}

// Ambil data rekap absensi guru
$rekap_guru = [];
$total_guru = 0;
$total_guru_hadir = 0;
$total_guru_sakit = 0;
$total_guru_izin = 0;
$total_guru_alpha = 0;
$total_guru_terlambat = 0;

try {
    // Query rekap guru per bulan
    $query_guru = "SELECT 
        u.id_user,
        u.nama_lengkap,
        u.username,
        u.role,
        COUNT(CASE WHEN a.status = 'hadir' THEN 1 END) as hadir,
        COUNT(CASE WHEN a.status = 'sakit' THEN 1 END) as sakit,
        COUNT(CASE WHEN a.status = 'izin' THEN 1 END) as izin,
        COUNT(CASE WHEN a.status = 'alpha' THEN 1 END) as alpha,
        COUNT(CASE WHEN a.status = 'terlambat' THEN 1 END) as terlambat,
        COUNT(a.id_absensi) as total_absensi,
        ROUND((COUNT(CASE WHEN a.status IN ('hadir', 'terlambat') THEN 1 END) / 25) * 100, 2) as persentase
    FROM tb_users u
    LEFT JOIN tb_absensi a ON u.id_user = a.id_user 
        AND MONTH(a.tanggal) = :bulan 
        AND YEAR(a.tanggal) = :tahun
    WHERE u.role IN ('guru', 'admin')
    GROUP BY u.id_user 
    ORDER BY u.role, u.nama_lengkap ASC";
    
    $stmt = $pdo->prepare($query_guru);
    $stmt->execute([
        ':bulan' => $filter_bulan,
        ':tahun' => $filter_tahun
    ]);
    $rekap_guru = $stmt->fetchAll();
    
    // Hitung total guru
    foreach ($rekap_guru as $r) {
        $total_guru++;
        $total_guru_hadir += $r['hadir'];
        $total_guru_sakit += $r['sakit'];
        $total_guru_izin += $r['izin'];
        $total_guru_alpha += $r['alpha'];
        $total_guru_terlambat += $r['terlambat'];
    }
    
} catch (PDOException $e) {
    $error_guru = "Error: " . $e->getMessage();
}

// Ambil data untuk grafik per kelas
$grafik_kelas = [];
try {
    $query_grafik = "SELECT 
        k.nama_kelas,
        COUNT(CASE WHEN a.status = 'hadir' THEN 1 END) as hadir,
        COUNT(CASE WHEN a.status = 'sakit' THEN 1 END) as sakit,
        COUNT(CASE WHEN a.status = 'izin' THEN 1 END) as izin,
        COUNT(CASE WHEN a.status = 'alpha' THEN 1 END) as alpha,
        COUNT(CASE WHEN a.status = 'terlambat' THEN 1 END) as terlambat,
        COUNT(a.id_absensi) as total
    FROM tb_kelas k
    LEFT JOIN tb_users u ON k.id_kelas = u.id_kelas AND u.role = 'siswa'
    LEFT JOIN tb_absensi a ON u.id_user = a.id_user 
        AND MONTH(a.tanggal) = :bulan 
        AND YEAR(a.tanggal) = :tahun
    GROUP BY k.id_kelas
    ORDER BY k.nama_kelas";
    
    $stmt = $pdo->prepare($query_grafik);
    $stmt->execute([
        ':bulan' => $filter_bulan,
        ':tahun' => $filter_tahun
    ]);
    $grafik_kelas = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error_grafik = "Error: " . $e->getMessage();
}

// Fungsi untuk mendapatkan nama bulan
function getNamaBulan($bulan) {
    $nama_bulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    return $nama_bulan[(int)$bulan] ?? '';
}

// Fungsi untuk menentukan warna badge persentase
function getPersentaseColor($persen) {
    if ($persen >= 90) return 'text-green-600 bg-green-100';
    if ($persen >= 75) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
}

// Untuk menu active
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Absensi - ADMINSKAPAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>
    <style>
        /* Palet Warna */
        :root {
            --primary-1: #2B3A67;
            --primary-2: #496A81;
            --secondary-1: #66999B;
            --secondary-2: #B3AF8F;
            --accent-1: #FFC482;
            --accent-2: #DDB7AB;
            --neutral-1: #F8F4E9;
            --neutral-2: #E8E1D3;
            --success: #77BFA3;
            --warning: #FFB347;
            --danger: #E58C7C;
        }

        body {
            background: linear-gradient(135deg, var(--neutral-1) 0%, var(--neutral-2) 100%);
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }

        .sidebar {
            background: linear-gradient(180deg, var(--primary-1) 0%, var(--primary-2) 100%);
            box-shadow: 4px 0 20px rgba(43, 58, 103, 0.2);
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 16rem;
            z-index: 50;
            overflow-y: auto;
        }

        .sidebar-item {
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            color: white;
        }

        .sidebar-item:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--accent-1);
            transform: translateX(5px);
        }

        .sidebar-item.active {
            background: linear-gradient(90deg, var(--accent-1) 0%, var(--accent-2) 100%);
            color: var(--primary-1);
            font-weight: 600;
        }

        .dropdown-menu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
            background: rgba(43, 58, 103, 0.3);
        }
        
        .dropdown-menu.open {
            max-height: 500px;
        }
        
        .dropdown-toggle .fa-chevron-down {
            transition: transform 0.3s;
        }
        
        .dropdown-toggle.open .fa-chevron-down {
            transform: rotate(180deg);
        }
        
        .dropdown-item {
            padding-left: 3rem !important;
        }

        /* Main Content */
        .main-content {
            margin-left: 16rem;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        /* Header */
        .header-gradient {
            background: linear-gradient(135deg, #ffffff 0%, var(--neutral-1) 100%);
            border-bottom: 3px solid var(--secondary-1);
        }

        /* Card */
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 1rem;
            border: 1px solid var(--neutral-2);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(43, 58, 103, 0.1);
        }

        .filter-card {
            background: white;
            border-radius: 20px;
            border: 1px solid var(--neutral-2);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        /* Tabel */
        .table-container {
            background: white;
            border-radius: 20px;
            border: 1px solid var(--neutral-2);
            overflow: auto;
            max-height: 500px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: linear-gradient(135deg, var(--primary-1), var(--primary-2));
            color: white;
            font-weight: 600;
            font-size: 0.75rem;
            padding: 12px 8px;
            text-align: left;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        td {
            padding: 10px 8px;
            font-size: 0.8rem;
            border-bottom: 1px solid var(--neutral-2);
        }

        tr:hover {
            background: var(--neutral-1);
        }

        /* Badge */
        .badge-status {
            padding: 4px 8px;
            border-radius: 50px;
            font-size: 0.65rem;
            font-weight: 600;
            display: inline-block;
            min-width: 70px;
            text-align: center;
        }

        .badge-hadir { background: #77BFA3; color: white; }
        .badge-sakit { background: #FFB347; color: white; }
        .badge-izin { background: #66999B; color: white; }
        .badge-alpha { background: #E58C7C; color: white; }
        .badge-terlambat { background: #DDB7AB; color: white; }

        /* Tombol */
        .btn-primary {
            background: linear-gradient(135deg, var(--secondary-1), var(--primary-2));
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-excel {
            background: #217346;
            color: white;
        }
        .btn-pdf {
            background: #d32f2f;
            color: white;
        }
        .btn-print {
            background: var(--primary-2);
            color: white;
        }

        /* Chart Container */
        .chart-container {
            background: white;
            border-radius: 20px;
            padding: 1rem;
            border: 1px solid var(--neutral-2);
            height: 300px;
        }

        /* Print */
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                background: white;
            }
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
    </style>
</head>

<body>

    <!-- SIDEBAR -->
    <div class="sidebar no-print">
        <div class="p-4 border-b border-white/10">
            <div class="flex items-center gap-3">
                <img src="../../assets/img/logo_sekolah.png" alt="Logo" class="h-12 w-12 rounded-xl bg-white/10 p-1 border-2 border-white/20">
                <div>
                    <h2 class="font-bold text-sm text-white">ADMINSKAPAN</h2>
                    <p class="text-[0.6rem] text-white/60">SMK N 8 Bandar Lampung</p>
                </div>
            </div>
        </div>
        
        <div class="py-4">
            <a href="dashboard.php" class="flex items-center px-6 py-3 sidebar-item <?= $current_page == 'dashboard.php' ? 'active' : '' ?>">
                <i class="fas fa-home w-6"></i>
                <span class="text-sm font-medium">Dashboard</span>
            </a>

            <!-- LAPORAN -->
            <div class="dropdown-container mt-2">
                <div class="flex items-center justify-between px-6 py-3 sidebar-item cursor-pointer dropdown-toggle <?= in_array($current_page, ['absensi.php', 'laporan_absensi.php']) ? 'active' : '' ?>" onclick="toggleDropdown('laporanDropdown')">
                    <div class="flex items-center">
                        <i class="fas fa-file-alt w-6"></i>
                        <span class="text-sm font-medium">Laporan</span>
                    </div>
                    <i class="fas fa-chevron-down text-xs text-white/60"></i>
                </div>
                <div id="laporanDropdown" class="dropdown-menu <?= in_array($current_page, ['absensi.php', 'laporan_absensi.php']) ? 'open' : '' ?>">
                    <a href="data_kelas.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item">Data Kelas</a>
                    <a href="data_guru.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item">Data Guru</a>
                    <a href="data_siswa.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item">Data Siswa</a>
                    <a href="data_pengawas.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item">Data Pengawas</a>
                    <a href="absensi.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item">Absensi</a>
                    <a href="laporan_absensi.php" class="flex items-center px-6 py-2 sidebar-item dropdown-item <?= $current_page == 'laporan_absensi.php' ? 'active' : '' ?>">Rekap Absensi</a>
                </div>
            </div>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">

        <!-- HEADER -->
        <header class="header-gradient py-3 px-6 flex justify-between items-center sticky top-0 z-40 shadow-sm no-print">
            <div class="flex items-center gap-3">
                <h1 class="text-xl font-bold" style="color: var(--primary-1);">
                    <i class="fas fa-chart-pie mr-2" style="color: var(--secondary-1);"></i>
                    Rekap Absensi
                </h1>
            </div>
            <div class="flex items-center space-x-4">
                <div class="text-right">
                    <p class="text-xs font-bold" style="color: var(--primary-1);"><?= $_SESSION['nama'] ?? 'Admin'; ?></p>
                    <p class="text-[0.6rem] font-medium" style="color: var(--secondary-1);">Admin</p>
                </div>
                <img src="../../assets/img/logo_sekolah.png" class="h-10 w-10 rounded-2xl border-4 border-white shadow-lg">
            </div>
        </header>

        <main class="p-6">

            <!-- FILTER SECTION -->
            <div class="filter-card p-6 mb-6 no-print">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-lg font-bold" style="color: var(--primary-1);">
                        <i class="fas fa-filter mr-2" style="color: var(--secondary-1);"></i>
                        Filter Rekap Absensi
                    </h2>
                    <div class="flex gap-2">
                        <button onclick="exportToExcel()" class="btn-excel px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
                            <i class="fas fa-file-excel"></i> Export Excel
                        </button>
                        <button onclick="exportToPDF()" class="btn-pdf px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
                            <i class="fas fa-file-pdf"></i> Export PDF
                        </button>
                        <button onclick="window.print()" class="btn-print px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
                            <i class="fas fa-print"></i> Print
                        </button>
                    </div>
                </div>

                <form method="GET" action="" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Tipe</label>
                            <select name="tipe" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                                <option value="siswa" <?= $filter_tipe == 'siswa' ? 'selected' : '' ?>>Rekap Siswa</option>
                                <option value="guru" <?= $filter_tipe == 'guru' ? 'selected' : '' ?>>Rekap Guru</option>
                            </select>
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Bulan</label>
                            <select name="bulan" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= $filter_bulan == $i ? 'selected' : '' ?>><?= getNamaBulan($i) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Tahun</label>
                            <select name="tahun" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                                <?php for($i = date('Y'); $i >= date('Y')-5; $i--): ?>
                                <option value="<?= $i ?>" <?= $filter_tahun == $i ? 'selected' : '' ?>><?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 block mb-1">Kelas</label>
                            <select name="kelas" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm">
                                <option value="">Semua Kelas</option>
                                <?php foreach ($kelas_list as $k): ?>
                                <option value="<?= $k['id_kelas'] ?>" <?= $filter_kelas == $k['id_kelas'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($k['nama_kelas']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="flex items-end">
                            <button type="submit" class="btn-primary w-full">
                                <i class="fas fa-search mr-2"></i> Tampilkan
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- STATISTIK CARD -->
            <?php if ($filter_tipe == 'siswa'): ?>
            <!-- Statistik Siswa -->
            <div class="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6 no-print">
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Siswa</p>
                    <p class="text-2xl font-bold" style="color: var(--primary-1);"><?= $total_siswa ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Hadir</p>
                    <p class="text-2xl font-bold" style="color: #77BFA3;"><?= $total_hadir ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Sakit</p>
                    <p class="text-2xl font-bold" style="color: #FFB347;"><?= $total_sakit ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Izin</p>
                    <p class="text-2xl font-bold" style="color: #66999B;"><?= $total_izin ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Alpha</p>
                    <p class="text-2xl font-bold" style="color: #E58C7C;"><?= $total_alpha ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Terlambat</p>
                    <p class="text-2xl font-bold" style="color: #DDB7AB;"><?= $total_terlambat ?></p>
                </div>
            </div>
            <?php else: ?>
            <!-- Statistik Guru -->
            <div class="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6 no-print">
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Guru</p>
                    <p class="text-2xl font-bold" style="color: var(--primary-1);"><?= $total_guru ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Hadir</p>
                    <p class="text-2xl font-bold" style="color: #77BFA3;"><?= $total_guru_hadir ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Sakit</p>
                    <p class="text-2xl font-bold" style="color: #FFB347;"><?= $total_guru_sakit ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Izin</p>
                    <p class="text-2xl font-bold" style="color: #66999B;"><?= $total_guru_izin ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Alpha</p>
                    <p class="text-2xl font-bold" style="color: #E58C7C;"><?= $total_guru_alpha ?></p>
                </div>
                <div class="stat-card">
                    <p class="text-xs text-gray-500">Total Terlambat</p>
                    <p class="text-2xl font-bold" style="color: #DDB7AB;"><?= $total_guru_terlambat ?></p>
                </div>
            </div>
            <?php endif; ?>

            <!-- GRAFIK PER KELAS (hanya untuk rekap siswa) -->
            <?php if ($filter_tipe == 'siswa' && !empty($grafik_kelas)): ?>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6 no-print">
                <!-- Grafik Batang -->
                <div class="chart-container">
                    <h3 class="font-bold text-sm mb-4" style="color: var(--primary-1);">Grafik Kehadiran per Kelas</h3>
                    <canvas id="chartKelas"></canvas>
                </div>
                
                <!-- Grafik Pie -->
                <div class="chart-container">
                    <h3 class="font-bold text-sm mb-4" style="color: var(--primary-1);">Komposisi Kehadiran <?= getNamaBulan($filter_bulan) ?> <?= $filter_tahun ?></h3>
                    <canvas id="chartPie"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- TABEL REKAP -->
            <div class="table-container print-area">
                <div class="p-4 border-b border-gray-200 bg-gray-50 print:bg-white no-print">
                    <h3 class="font-bold text-sm" style="color: var(--primary-1);">
                        <i class="fas fa-list mr-2"></i>
                        Rekap Absensi <?= $filter_tipe == 'siswa' ? 'Siswa' : 'Guru' ?>
                        (<?= getNamaBulan($filter_bulan) ?> <?= $filter_tahun ?>)
                    </h3>
                </div>

                <!-- Header Print -->
                <div class="hidden print:block p-4 text-center">
                    <h2 class="text-xl font-bold">REKAP ABSENSI <?= strtoupper($filter_tipe == 'siswa' ? 'SISWA' : 'GURU') ?></h2>
                    <h3 class="text-lg">SMK NEGERI 8 BANDAR LAMPUNG</h3>
                    <p class="text-sm">Bulan: <?= getNamaBulan($filter_bulan) ?> <?= $filter_tahun ?></p>
                    <?php if(!empty($filter_kelas)): ?>
                    <p class="text-sm">Kelas: <?= htmlspecialchars($filter_kelas) ?></p>
                    <?php endif; ?>
                    <hr class="my-2">
                </div>

                <table id="tabel-rekap">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <?php if ($filter_tipe == 'siswa'): ?>
                            <th>Kelas</th>
                            <?php else: ?>
                            <th>Role</th>
                            <?php endif; ?>
                            <th>Hadir</th>
                            <th>Sakit</th>
                            <th>Izin</th>
                            <th>Alpha</th>
                            <th>Terlambat</th>
                            <th>Total</th>
                            <th>Persentase</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($filter_tipe == 'siswa'): ?>
                            <?php if (empty($rekap_siswa)): ?>
                            <tr>
                                <td colspan="12" class="text-center py-8 text-gray-400">
                                    <i class="fas fa-folder-open text-4xl mb-2 block"></i>
                                    Tidak ada data rekap
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php $no = 1; ?>
                                <?php foreach ($rekap_siswa as $r): ?>
                                <?php 
                                    $total = $r['hadir'] + $r['sakit'] + $r['izin'] + $r['alpha'] + $r['terlambat'];
                                    $persen = $total > 0 ? round(($r['hadir'] + $r['terlambat']) / $total * 100, 2) : 0;
                                    $warna = getPersentaseColor($persen);
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td class="font-semibold"><?= htmlspecialchars($r['nama_lengkap']) ?></td>
                                    <td><?= htmlspecialchars($r['username'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($r['nama_kelas'] ?? '-') ?></td>
                                    <td class="text-green-600 font-semibold"><?= $r['hadir'] ?></td>
                                    <td class="text-yellow-600"><?= $r['sakit'] ?></td>
                                    <td class="text-blue-600"><?= $r['izin'] ?></td>
                                    <td class="text-red-600"><?= $r['alpha'] ?></td>
                                    <td class="text-orange-600"><?= $r['terlambat'] ?></td>
                                    <td class="font-bold"><?= $total ?></td>
                                    <td>
                                        <span class="px-2 py-1 rounded-full text-xs font-bold <?= $warna ?>">
                                            <?= $persen ?>%
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($persen >= 90): ?>
                                            <span class="text-green-600"><i class="fas fa-check-circle"></i> Baik</span>
                                        <?php elseif ($persen >= 75): ?>
                                            <span class="text-yellow-600"><i class="fas fa-exclamation-circle"></i> Cukup</span>
                                        <?php else: ?>
                                            <span class="text-red-600"><i class="fas fa-times-circle"></i> Kurang</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if (empty($rekap_guru)): ?>
                            <tr>
                                <td colspan="11" class="text-center py-8 text-gray-400">
                                    <i class="fas fa-folder-open text-4xl mb-2 block"></i>
                                    Tidak ada data rekap
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php $no = 1; ?>
                                <?php foreach ($rekap_guru as $r): ?>
                                <?php 
                                    $total = $r['hadir'] + $r['sakit'] + $r['izin'] + $r['alpha'] + $r['terlambat'];
                                    $persen = $total > 0 ? round(($r['hadir'] + $r['terlambat']) / $total * 100, 2) : 0;
                                    $warna = getPersentaseColor($persen);
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td class="font-semibold"><?= htmlspecialchars($r['nama_lengkap']) ?></td>
                                    <td><?= htmlspecialchars($r['username'] ?? '-') ?></td>
                                    <td>
                                        <span class="px-2 py-1 text-xs rounded-full <?= $r['role'] == 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800' ?>">
                                            <?= ucfirst($r['role']) ?>
                                        </span>
                                    </td>
                                    <td class="text-green-600 font-semibold"><?= $r['hadir'] ?></td>
                                    <td class="text-yellow-600"><?= $r['sakit'] ?></td>
                                    <td class="text-blue-600"><?= $r['izin'] ?></td>
                                    <td class="text-red-600"><?= $r['alpha'] ?></td>
                                    <td class="text-orange-600"><?= $r['terlambat'] ?></td>
                                    <td class="font-bold"><?= $total ?></td>
                                    <td>
                                        <span class="px-2 py-1 rounded-full text-xs font-bold <?= $warna ?>">
                                            <?= $persen ?>%
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($persen >= 90): ?>
                                            <span class="text-green-600"><i class="fas fa-check-circle"></i> Baik</span>
                                        <?php elseif ($persen >= 75): ?>
                                            <span class="text-yellow-600"><i class="fas fa-exclamation-circle"></i> Cukup</span>
                                        <?php else: ?>
                                            <span class="text-red-600"><i class="fas fa-times-circle"></i> Kurang</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Footer -->
                <div class="p-4 border-t border-gray-200 bg-gray-50 print:bg-white">
                    <div class="flex justify-between items-center">
                        <p class="text-sm font-semibold">Total Data: <?= $filter_tipe == 'siswa' ? count($rekap_siswa) : count($rekap_guru) ?></p>
                        <p class="text-xs text-gray-500">*Persentase dihitung dari total hari efektif</p>
                    </div>
                </div>
            </div>

            <!-- SISWA BERMASALAH (Alpha Tinggi) -->
            <?php if ($filter_tipe == 'siswa' && !empty($rekap_siswa)): ?>
            <?php 
                $siswa_bermasalah = array_filter($rekap_siswa, function($r) {
                    $total = $r['hadir'] + $r['sakit'] + $r['izin'] + $r['alpha'] + $r['terlambat'];
                    $persen = $total > 0 ? ($r['hadir'] + $r['terlambat']) / $total * 100 : 0;
                    return $persen < 75 || $r['alpha'] > 3;
                });
            ?>
            <?php if (!empty($siswa_bermasalah)): ?>
            <div class="mt-6 p-4 bg-red-50 border border-red-200 rounded-xl no-print">
                <h3 class="font-bold text-sm text-red-800 mb-3">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    Peringatan! Siswa dengan Kehadiran Rendah
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    <?php foreach (array_slice($siswa_bermasalah, 0, 6) as $s): ?>
                    <?php 
                        $total = $s['hadir'] + $s['sakit'] + $s['izin'] + $s['alpha'] + $s['terlambat'];
                        $persen = $total > 0 ? round(($s['hadir'] + $s['terlambat']) / $total * 100, 2) : 0;
                    ?>
                    <div class="bg-white p-3 rounded-lg border border-red-200">
                        <p class="font-semibold text-sm"><?= htmlspecialchars($s['nama_lengkap']) ?></p>
                        <p class="text-xs text-gray-500">Kelas: <?= htmlspecialchars($s['nama_kelas'] ?? '-') ?></p>
                        <div class="flex justify-between mt-2">
                            <span class="text-xs">Alpha: <span class="font-bold text-red-600"><?= $s['alpha'] ?>x</span></span>
                            <span class="text-xs">Kehadiran: <span class="font-bold <?= $persen < 75 ? 'text-red-600' : 'text-yellow-600' ?>"><?= $persen ?>%</span></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>

        </main>
    </div>

    <script>
        // Fungsi toggle dropdown
        function toggleDropdown(id) {
            const dropdown = document.getElementById(id);
            const toggle = event.currentTarget;
            dropdown.classList.toggle('open');
            toggle.classList.toggle('open');
        }

        // Export ke Excel
        function exportToExcel() {
            const table = document.getElementById('tabel-rekap');
            const wb = XLSX.utils.table_to_book(table, {sheet: "Rekap Absensi"});
            const filename = `Rekap_Absensi_<?= $filter_tipe ?>_<?= $filter_bulan ?>_<?= $filter_tahun ?>.xlsx`;
            XLSX.writeFile(wb, filename);
            
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data berhasil diexport ke Excel',
                timer: 1500,
                showConfirmButton: false
            });
        }

        // Export ke PDF
        function exportToPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('landscape');
            
            doc.setFontSize(16);
            doc.text('REKAP ABSENSI', 14, 20);
            doc.setFontSize(12);
            doc.text('SMK NEGERI 8 BANDAR LAMPUNG', 14, 28);
            doc.setFontSize(10);
            doc.text('Bulan: <?= getNamaBulan($filter_bulan) ?> <?= $filter_tahun ?>', 14, 36);
            doc.text('Tipe: <?= ucfirst($filter_tipe) ?>', 14, 42);
            
            // Ambil data dari tabel
            const table = document.getElementById('tabel-rekap');
            const headers = [];
            const data = [];
            
            const headerCells = table.querySelectorAll('thead th');
            headerCells.forEach(cell => {
                headers.push(cell.innerText);
            });
            
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const rowData = [];
                const cells = row.querySelectorAll('td');
                cells.forEach(cell => {
                    rowData.push(cell.innerText);
                });
                data.push(rowData);
            });
            
            doc.autoTable({
                head: [headers],
                body: data,
                startY: 50,
                styles: { fontSize: 8 },
                headStyles: { fillColor: [43, 58, 103] }
            });
            
            doc.save(`Rekap_Absensi_<?= $filter_tipe ?>_<?= $filter_bulan ?>_<?= $filter_tahun ?>.pdf`);
            
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data berhasil diexport ke PDF',
                timer: 1500,
                showConfirmButton: false
            });
        }

        // Inisialisasi Chart
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($filter_tipe == 'siswa' && !empty($grafik_kelas)): ?>
            // Grafik Batang per Kelas
            const ctxKelas = document.getElementById('chartKelas').getContext('2d');
            const kelasLabels = <?= json_encode(array_column($grafik_kelas, 'nama_kelas')) ?>;
            const hadirData = <?= json_encode(array_column($grafik_kelas, 'hadir')) ?>;
            const sakitData = <?= json_encode(array_column($grafik_kelas, 'sakit')) ?>;
            const izinData = <?= json_encode(array_column($grafik_kelas, 'izin')) ?>;
            const alphaData = <?= json_encode(array_column($grafik_kelas, 'alpha')) ?>;
            
            new Chart(ctxKelas, {
                type: 'bar',
                data: {
                    labels: kelasLabels,
                    datasets: [
                        {
                            label: 'Hadir',
                            data: hadirData,
                            backgroundColor: '#77BFA3'
                        },
                        {
                            label: 'Sakit',
                            data: sakitData,
                            backgroundColor: '#FFB347'
                        },
                        {
                            label: 'Izin',
                            data: izinData,
                            backgroundColor: '#66999B'
                        },
                        {
                            label: 'Alpha',
                            data: alphaData,
                            backgroundColor: '#E58C7C'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Grafik Pie Komposisi
            const ctxPie = document.getElementById('chartPie').getContext('2d');
            new Chart(ctxPie, {
                type: 'pie',
                data: {
                    labels: ['Hadir', 'Sakit', 'Izin', 'Alpha', 'Terlambat'],
                    datasets: [{
                        data: [
                            <?= $total_hadir ?>,
                            <?= $total_sakit ?>,
                            <?= $total_izin ?>,
                            <?= $total_alpha ?>,
                            <?= $total_terlambat ?>
                        ],
                        backgroundColor: ['#77BFA3', '#FFB347', '#66999B', '#E58C7C', '#DDB7AB']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
            <?php endif; ?>
        });
    </script>
</body>

</html>