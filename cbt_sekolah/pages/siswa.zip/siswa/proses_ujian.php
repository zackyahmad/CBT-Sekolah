<?php
session_start();
require_once '../../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_user = $_SESSION['id_user'];
    $id_ujian = (int)$_POST['id_ujian'];
    $jawaban_siswa = $_POST['jawaban'] ?? []; 

    // 1. Ambil data soal
    $stmt = $pdo->prepare("SELECT s.id_soal, s.kunci_jawaban, s.jenis_soal FROM tb_ujian_soal us JOIN tb_soal s ON us.id_soal = s.id_soal WHERE us.id_ujian = ?");
    $stmt->execute([$id_ujian]);
    $kunci_soal = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $benar = 0; $salah = 0; $total_soal = count($kunci_soal);
    $total_pg = 0;

    // 2. Buat ID Hasil Ujian Dulu (Nilai awal 0)
    $insert_hasil = $pdo->prepare("INSERT INTO tb_hasil_ujian (id_user, id_ujian, nilai) VALUES (?, ?, 0)");
    $insert_hasil->execute([$id_user, $id_ujian]);
    $id_hasil = $pdo->lastInsertId();

    // 3. Cek Jawaban & Simpan ke tb_jawaban
    $insert_jwb = $pdo->prepare("INSERT INTO tb_jawaban (id_hasil, id_user, id_ujian, id_soal, jawaban) VALUES (?, ?, ?, ?, ?)");
    
    foreach ($kunci_soal as $item) {
        $id_s = $item['id_soal'];
        $jwb = $jawaban_siswa[$id_s] ?? '';
        $jenis = $item['jenis_soal'] ?? '1';

        if ($jenis == '1') { // Jika Pilihan Ganda
            $total_pg++;
            if (strtoupper($jwb) === strtoupper($item['kunci_jawaban'])) { $benar++; } 
            else { $salah++; }
        }

        $insert_jwb->execute([$id_hasil, $id_user, $id_ujian, $id_s, $jwb]);
    }

    // 4. Hitung Nilai Sementara (Dari Pilihan Ganda Saja)
    $nilai_sementara = ($total_pg > 0) ? ($benar / $total_pg) * 100 : 0;
    $pdo->prepare("UPDATE tb_hasil_ujian SET jml_benar=?, jml_salah=?, nilai=? WHERE id_hasil=?")->execute([$benar, $salah, $nilai_sementara, $id_hasil]);

    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Ujian berhasil diselesaikan!'];
    header("Location: ujian.php");
    exit;
}