<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit;
}
require_once '../../config/koneksi.php';

// TAMBAH UJIAN BARU
if (isset($_POST['tambah_ujian'])) {
    $judul_ujian = $_POST['judul_ujian'];
    $id_mapel = $_POST['id_mapel'];
    $id_guru = $_POST['id_guru'];
    $tanggal_ujian = $_POST['tanggal_ujian'];
    $jam_mulai = $_POST['jam_mulai'];
    $durasi_menit = $_POST['durasi_menit'];
    $status_ujian = $_POST['status_ujian'] ?? 'tidak_aktif';
    
    // Generate token random
    $token = strtoupper(substr(md5(uniqid()), 0, 6));
    
    try {
        $query = "INSERT INTO tb_ujian (judul_ujian, id_mapel, id_guru, tanggal_ujian, jam_mulai, durasi_menit, status_ujian, token, tampil_nilai, acak_soal, anti_tab) 
                  VALUES (:judul_ujian, :id_mapel, :id_guru, :tanggal_ujian, :jam_mulai, :durasi_menit, :status_ujian, :token, 1, 1, 1)";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            'judul_ujian' => $judul_ujian,
            'id_mapel' => $id_mapel,
            'id_guru' => $id_guru,
            'tanggal_ujian' => $tanggal_ujian,
            'jam_mulai' => $jam_mulai,
            'durasi_menit' => $durasi_menit,
            'status_ujian' => $status_ujian,
            'token' => $token
        ]);
        
        $_SESSION['notif'] = [
            'type' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Jadwal ujian berhasil ditambahkan'
        ];
    } catch (PDOException $e) {
        $_SESSION['notif'] = [
            'type' => 'error',
            'title' => 'Gagal!',
            'text' => 'Error: ' . $e->getMessage()
        ];
    }
    
    header("Location: rencana_ujian.php");
    exit;
}

// UBAH STATUS UJIAN
if (isset($_GET['ubah_status'])) {
    $id_ujian = $_GET['ubah_status'];
    $status_baru = $_GET['status'];
    
    try {
        $query = "UPDATE tb_ujian SET status_ujian = :status WHERE id_ujian = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            'status' => $status_baru,
            'id' => $id_ujian
        ]);
        
        $_SESSION['notif'] = [
            'type' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Status ujian berhasil diubah'
        ];
    } catch (PDOException $e) {
        $_SESSION['notif'] = [
            'type' => 'error',
            'title' => 'Gagal!',
            'text' => 'Error: ' . $e->getMessage()
        ];
    }
    
    header("Location: rencana_ujian.php");
    exit;
}

// HAPUS UJIAN
if (isset($_GET['hapus_ujian'])) {
    $id_ujian = $_GET['hapus_ujian'];
    
    try {
        $query = "DELETE FROM tb_ujian WHERE id_ujian = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['id' => $id_ujian]);
        
        $_SESSION['notif'] = [
            'type' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Jadwal ujian berhasil dihapus'
        ];
    } catch (PDOException $e) {
        $_SESSION['notif'] = [
            'type' => 'error',
            'title' => 'Gagal!',
            'text' => 'Error: ' . $e->getMessage()
        ];
    }
    
    header("Location: rencana_ujian.php");
    exit;
}

// EDIT UJIAN
if (isset($_POST['update_ujian'])) {
    $id_ujian = $_POST['id_ujian'];
    $judul_ujian = $_POST['judul_ujian'];
    $id_mapel = $_POST['id_mapel'];
    $id_guru = $_POST['id_guru'];
    $tanggal_ujian = $_POST['tanggal_ujian'];
    $jam_mulai = $_POST['jam_mulai'];
    $durasi_menit = $_POST['durasi_menit'];
    $status_ujian = $_POST['status_ujian'];
    
    try {
        $query = "UPDATE tb_ujian SET 
                  judul_ujian = :judul_ujian,
                  id_mapel = :id_mapel,
                  id_guru = :id_guru,
                  tanggal_ujian = :tanggal_ujian,
                  jam_mulai = :jam_mulai,
                  durasi_menit = :durasi_menit,
                  status_ujian = :status_ujian
                  WHERE id_ujian = :id_ujian";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            'judul_ujian' => $judul_ujian,
            'id_mapel' => $id_mapel,
            'id_guru' => $id_guru,
            'tanggal_ujian' => $tanggal_ujian,
            'jam_mulai' => $jam_mulai,
            'durasi_menit' => $durasi_menit,
            'status_ujian' => $status_ujian,
            'id_ujian' => $id_ujian
        ]);
        
        $_SESSION['notif'] = [
            'type' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Jadwal ujian berhasil diperbarui'
        ];
    } catch (PDOException $e) {
        $_SESSION['notif'] = [
            'type' => 'error',
            'title' => 'Gagal!',
            'text' => 'Error: ' . $e->getMessage()
        ];
    }
    
    header("Location: rencana_ujian.php");
    exit;
}

// Jika tidak ada aksi, redirect
header("Location: rencana_ujian.php");
exit;
?>