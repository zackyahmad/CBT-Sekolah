<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit;
}
require_once '../../config/koneksi.php';

// ========== PROSES TAMBAH DATA ==========
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'tambah') {
    $nis = $_POST['nis'];
    $nama_siswa = $_POST['nama_siswa'];
    $kelas = $_POST['kelas'];
    $jurusan = $_POST['jurusan'];
    $sid = $_POST['sid'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $username_ujian = $_POST['username_ujian'];
    $password_ujian = $_POST['password_ujian'];
    
    // Upload foto
    $foto_siswa = null;
    if (isset($_FILES['foto_siswa']) && $_FILES['foto_siswa']['error'] == 0) {
        $target_dir = "../../uploads/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
        $foto_siswa = time() . "_" . basename($_FILES['foto_siswa']['name']);
        move_uploaded_file($_FILES['foto_siswa']['tmp_name'], $target_dir . $foto_siswa);
    }
    
    $stmt = $pdo->prepare("INSERT INTO tb_kartu_ujian (nis, nama_siswa, kelas, jurusan, sid, tempat_lahir, tanggal_lahir, username_ujian, password_ujian, foto_siswa) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$nis, $nama_siswa, $kelas, $jurusan, $sid, $tempat_lahir, $tanggal_lahir, $username_ujian, $password_ujian, $foto_siswa]);
    
    $_SESSION['success'] = "Kartu ujian berhasil ditambahkan";
    header("Location: kartu_ujian.php");
    exit;
}

// ========== PROSES EDIT DATA ==========
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'edit') {
    $id = $_POST['id_kartu'];
    $nis = $_POST['nis'];
    $nama_siswa = $_POST['nama_siswa'];
    $kelas = $_POST['kelas'];
    $jurusan = $_POST['jurusan'];
    $sid = $_POST['sid'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $username_ujian = $_POST['username_ujian'];
    $password_ujian = $_POST['password_ujian'];
    
    // Ambil foto lama
    $stmt = $pdo->prepare("SELECT foto_siswa FROM tb_kartu_ujian WHERE id_kartu = ?");
    $stmt->execute([$id]);
    $foto_lama = $stmt->fetchColumn();
    $foto_siswa = $foto_lama;
    
    // Upload foto baru jika ada
    if (isset($_FILES['foto_siswa']) && $_FILES['foto_siswa']['error'] == 0) {
        if ($foto_lama && file_exists("../../uploads/" . $foto_lama)) {
            unlink("../../uploads/" . $foto_lama);
        }
        $foto_siswa = time() . "_" . basename($_FILES['foto_siswa']['name']);
        move_uploaded_file($_FILES['foto_siswa']['tmp_name'], "../../uploads/" . $foto_siswa);
    }
    
    $stmt = $pdo->prepare("UPDATE tb_kartu_ujian SET nis=?, nama_siswa=?, kelas=?, jurusan=?, sid=?, tempat_lahir=?, tanggal_lahir=?, username_ujian=?, password_ujian=?, foto_siswa=? WHERE id_kartu=?");
    $stmt->execute([$nis, $nama_siswa, $kelas, $jurusan, $sid, $tempat_lahir, $tanggal_lahir, $username_ujian, $password_ujian, $foto_siswa, $id]);
    
    $_SESSION['success'] = "Kartu ujian berhasil diupdate";
    header("Location: kartu_ujian.php");
    exit;
}

// ========== PROSES HAPUS DATA ==========
if (isset($_GET['hapus_id'])) {
    $id = $_GET['hapus_id'];
    // Ambil foto dulu untuk dihapus
    $stmt = $pdo->prepare("SELECT foto_siswa FROM tb_kartu_ujian WHERE id_kartu = ?");
    $stmt->execute([$id]);
    $foto = $stmt->fetchColumn();
    if ($foto && file_exists("../../uploads/" . $foto)) {
        unlink("../../uploads/" . $foto);
    }
    $stmt = $pdo->prepare("DELETE FROM tb_kartu_ujian WHERE id_kartu = ?");
    $stmt->execute([$id]);
    $_SESSION['success'] = "Data kartu ujian berhasil dihapus";
    header("Location: kartu_ujian.php");
    exit;
}

// ========== AMBIL DATA UNTUK EDIT (AJAX) ==========
if (isset($_GET['get_data'])) {
    $id = $_GET['get_data'];
    $stmt = $pdo->prepare("SELECT * FROM tb_kartu_ujian WHERE id_kartu = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($data ?: ['error' => 'Data tidak ditemukan']);
    exit;
}

// ========== FILTER DATA ==========
$search = isset($_GET['search']) ? $_GET['search'] : '';
$kelas_filter = isset($_GET['kelas']) ? $_GET['kelas'] : '';

$query = "SELECT * FROM tb_kartu_ujian WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (nis LIKE ? OR nama_siswa LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($kelas_filter)) {
    if ($kelas_filter == 'XII' || $kelas_filter == 'XI' || $kelas_filter == 'X') {
        $query .= " AND kelas LIKE ?";
        $params[] = "$kelas_filter%";
    } else {
        $query .= " AND kelas = ?";
        $params[] = $kelas_filter;
    }
}

$query .= " ORDER BY kelas, nama_siswa ASC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$kartu_ujian = $stmt->fetchAll();

$kelas_list = $pdo->query("SELECT DISTINCT kelas FROM tb_kartu_ujian ORDER BY kelas")->fetchAll();

$count_all = $pdo->query("SELECT COUNT(*) FROM tb_kartu_ujian")->fetchColumn();
$count_xii = $pdo->query("SELECT COUNT(*) FROM tb_kartu_ujian WHERE kelas LIKE 'XII%'")->fetchColumn();
$count_xi = $pdo->query("SELECT COUNT(*) FROM tb_kartu_ujian WHERE kelas LIKE 'XI%'")->fetchColumn();
$count_x = $pdo->query("SELECT COUNT(*) FROM tb_kartu_ujian WHERE kelas LIKE 'X%' AND kelas NOT LIKE 'XI%' AND kelas NOT LIKE 'XII%'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Ujian - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: #fdf8ed;
            font-family: 'Inter', system-ui, sans-serif;
        }

        .card-kartu {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            width: 100%;
            transition: all 0.3s ease;
            border: 1px solid #e0d5b5;
        }

        .card-kartu:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.12);
        }

        .kartu-header {
            padding: 10px 12px;
            background: white;
            border-bottom: 2px solid #8B6914;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
        }

        .logo-left, .logo-right {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .logo-left { background: linear-gradient(135deg, #8B6914, #DAA520); }
        .logo-right { background: linear-gradient(135deg, #1a3c5e, #2d5a8c); }

        .kop-section {
            flex: 1;
            text-align: center;
        }

        .kop-provinsi {
            font-size: 9px;
            font-weight: 800;
            color: #8B6914;
            text-transform: uppercase;
        }

        .kop-dinas {
            font-size: 8px;
            font-weight: 700;
            color: #1a3c5e;
            text-transform: uppercase;
        }

        .kop-alamat {
            font-size: 6.5px;
            color: #666;
        }

        .kartu-body {
            padding: 10px 12px;
            background: white;
        }

        .landscape-layout {
            display: flex;
            gap: 12px;
            align-items: flex-start;
        }

        .foto-section {
            width: 80px;
            text-align: center;
            flex-shrink: 0;
        }

        .foto-container {
            width: 75px;
            height: 90px;
            background: #f5f5f5;
            border: 1.5px solid #e0d5b5;
            border-radius: 8px;
            overflow: hidden;
            margin: 0 auto 6px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .foto-placeholder {
            text-align: center;
            color: #999;
        }

        .foto-placeholder i { font-size: 30px; }
        .foto-placeholder span { font-size: 8px; }

        .nis-badge {
            background: #8B6914;
            color: white;
            padding: 3px 6px;
            border-radius: 6px;
            font-size: 8px;
            font-weight: 600;
        }

        .data-section { flex: 1; }

        .data-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 6px 10px;
            margin-bottom: 8px;
        }

        .data-item {
            display: flex;
            align-items: baseline;
            font-size: 9px;
            border-bottom: 1px dotted #e0d5b5;
            padding-bottom: 3px;
        }

        .data-label {
            width: 55px;
            font-weight: 700;
            color: #8B6914;
            font-size: 8px;
        }

        .data-value {
            flex: 1;
            color: #333;
            font-size: 9px;
        }

        .data-value.important {
            font-weight: 700;
            color: #1a3c5e;
        }

        .login-section {
            background: #fdf8ed;
            border-radius: 8px;
            padding: 8px 10px;
            margin-top: 6px;
            border-left: 3px solid #8B6914;
        }

        .login-title {
            font-size: 7px;
            font-weight: 700;
            text-transform: uppercase;
            color: #8B6914;
            margin-bottom: 6px;
        }

        .login-items {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .login-item { flex: 1; min-width: 100px; }

        .login-label {
            font-size: 7px;
            font-weight: 700;
            color: #666;
            display: block;
            margin-bottom: 2px;
            text-transform: uppercase;
        }

        .login-value {
            font-size: 9px;
            font-weight: 700;
            font-family: monospace;
            background: #8B6914;
            color: white;
            padding: 3px 8px;
            border-radius: 15px;
            display: inline-block;
        }

        .login-value.username { background: #1a3c5e; }

        .kartu-footer {
            background: #fdf8ed;
            padding: 6px 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 7px;
            border-top: 1px solid #e0d5b5;
            color: #666;
        }

        .ttd-line {
            width: 50px;
            height: 1px;
            background: #333;
            margin: 3px auto;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
            padding: 8px 12px 10px;
            background: white;
            border-top: 1px solid #f0f0f0;
        }

        .btn-action {
            flex: 1;
            padding: 5px 0;
            border-radius: 6px;
            font-size: 9px;
            font-weight: 600;
            text-align: center;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
        }

        .btn-cetak { background: #1a3c5e; color: white; }
        .btn-edit { background: #e67e22; color: white; }
        .btn-hapus { background: #dc2626; color: white; }
        .btn-action:hover { opacity: 0.85; transform: translateY(-1px); }

        .filter-section {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            margin-bottom: 30px;
            border: 1px solid #e0d5b5;
        }

        .btn-primary {
            background: #8B6914;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border: none;
            cursor: pointer;
        }

        .btn-primary:hover { background: #DAA520; }
        .btn-orange { background: #e67e22; }
        .btn-purple { background: #8e44ad; }

        .back-button {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            font-weight: 600;
        }

        .back-button:hover { background: rgba(255,255,255,0.3); }

        .top-header {
            background: #8B6914;
            padding: 15px 30px;
            position: sticky;
            top: 0;
            z-index: 40;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .kartu-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        @media (max-width: 1024px) { .kartu-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 640px) { .kartu-grid { grid-template-columns: 1fr; } }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .modal.active { display: flex; }
        .modal-content {
            background: white;
            border-radius: 16px;
            max-width: 650px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }
        .foto-preview {
            width: 80px;
            height: 100px;
            object-fit: cover;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
    </style>
</head>

<body>
    <div class="min-h-screen">
        <header class="top-header">
            <div class="flex items-center gap-6">
                <a href="dashboard.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Dashboard
                </a>
                <div class="text-white/70 text-sm">
                    <i class="fas fa-home"></i> / Akademik / <span class="text-white font-semibold">Kartu Ujian</span>
                </div>
            </div>
            <div class="flex gap-3">
                <button onclick="bukaModalTambah()" class="btn-primary btn-purple">
                    <i class="fas fa-plus-circle"></i> Tambah Kartu
                </button>
                <button onclick="cetakSemuaKartu()" class="btn-primary btn-orange">
                    <i class="fas fa-print"></i> Cetak Semua
                </button>
            </div>
        </header>

        <main class="p-8">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded">
                    <i class="fas fa-check-circle mr-2"></i> <?= $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>

            <div class="filter-section">
                <h2 class="filter-title">
                    <i class="fas fa-filter mr-2"></i> Filter Data Kartu Ujian
                </h2>
                <div class="flex gap-4 flex-wrap">
                    <div class="flex-1 min-w-[200px]">
                        <input type="text" id="searchInput" placeholder="Cari NIS atau Nama Siswa..." value="<?= htmlspecialchars($search) ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                    </div>
                    <select id="kelasFilter" class="px-4 py-2 border border-gray-300 rounded-lg min-w-[200px]">
                        <option value="" <?= empty($kelas_filter) ? 'selected' : '' ?>>Semua Kelas (<?= $count_all ?>)</option>
                        <option value="XII" <?= $kelas_filter == 'XII' ? 'selected' : '' ?>>Kelas XII (<?= $count_xii ?>)</option>
                        <option value="XI" <?= $kelas_filter == 'XI' ? 'selected' : '' ?>>Kelas XI (<?= $count_xi ?>)</option>
                        <option value="X" <?= $kelas_filter == 'X' ? 'selected' : '' ?>>Kelas X (<?= $count_x ?>)</option>
                        <option disabled>──────────</option>
                        <?php foreach ($kelas_list as $k): ?>
                            <option value="<?= $k['kelas'] ?>" <?= $kelas_filter == $k['kelas'] ? 'selected' : '' ?>><?= $k['kelas'] ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button onclick="filterData()" class="btn-primary"><i class="fas fa-search"></i> Cari</button>
                    <button onclick="resetFilter()" class="px-4 py-2 border border-gray-300 rounded-lg"><i class="fas fa-undo"></i> Reset</button>
                </div>
            </div>

            <div class="kartu-grid">
                <?php foreach ($kartu_ujian as $kartu): ?>
                <div class="card-kartu">
                    <div class="kartu-header">
                        <div class="logo-left"><i class="fas fa-landmark"></i></div>
                        <div class="kop-section">
                            <div class="kop-provinsi">PEMERINTAH PROVINSI LAMPUNG</div>
                            <div class="kop-dinas">DINAS PENDIDIKAN DAN KEBUDAYAAN</div>
                            <div class="kop-alamat">Jl. Imam Bonjol 52, Kemiling 35153</div>
                        </div>
                        <div class="logo-right"><i class="fas fa-graduation-cap"></i></div>
                    </div>
                    
                    <div class="kartu-body">
                        <div class="landscape-layout">
                            <div class="foto-section">
                                <div class="foto-container">
                                    <?php if (!empty($kartu['foto_siswa']) && file_exists("../../uploads/" . $kartu['foto_siswa'])): ?>
                                        <img src="../../uploads/<?= $kartu['foto_siswa'] ?>" style="width:100%; height:100%; object-fit:cover;">
                                    <?php else: ?>
                                        <div class="foto-placeholder">
                                            <i class="fas fa-user-graduate"></i>
                                            <span>No Photo</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="nis-badge">NIS: <?= htmlspecialchars($kartu['nis']) ?></div>
                            </div>
                            
                            <div class="data-section">
                                <div class="data-grid">
                                    <div class="data-item"><span class="data-label">Nama</span><span class="data-value important"><?= htmlspecialchars($kartu['nama_siswa']) ?></span></div>
                                    <div class="data-item"><span class="data-label">Kelas</span><span class="data-value"><?= htmlspecialchars($kartu['kelas']) ?></span></div>
                                    <div class="data-item"><span class="data-label">Jurusan</span><span class="data-value"><?= htmlspecialchars($kartu['jurusan'] ?? '-') ?></span></div>
                                    <div class="data-item"><span class="data-label">SID</span><span class="data-value important"><?= htmlspecialchars($kartu['sid'] ?? '-') ?></span></div>
                                    <div class="data-item"><span class="data-label">Tempat Lahir</span><span class="data-value"><?= htmlspecialchars($kartu['tempat_lahir'] ?? '-') ?></span></div>
                                    <div class="data-item"><span class="data-label">Tgl Lahir</span><span class="data-value"><?= isset($kartu['tanggal_lahir']) && $kartu['tanggal_lahir'] ? date('d/m/Y', strtotime($kartu['tanggal_lahir'])) : '-' ?></span></div>
                                </div>
                                
                                <div class="login-section">
                                    <div class="login-title"><i class="fas fa-key mr-1"></i> Login Akun Ujian</div>
                                    <div class="login-items">
                                        <div class="login-item"><span class="login-label">USERNAME</span><span class="login-value username"><?= htmlspecialchars($kartu['username_ujian'] ?? $kartu['nis']) ?></span></div>
                                        <div class="login-item"><span class="login-label">PASSWORD</span><span class="login-value"><?= htmlspecialchars($kartu['password_ujian'] ?? '123456') ?></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="kartu-footer">
                        <div>Bandar Lampung</div>
                        <div class="ttd-area"><div class="ttd-line"></div><span>Kepala Sekolah</span></div>
                        <div>NIP: 19841121...</div>
                    </div>
                    
                    <div class="action-buttons">
                        <button onclick="cetakKartu(<?= $kartu['id_kartu'] ?>)" class="btn-action btn-cetak"><i class="fas fa-print"></i> Cetak</button>
                        <button onclick="bukaModalEdit(<?= $kartu['id_kartu'] ?>)" class="btn-action btn-edit"><i class="fas fa-edit"></i> Edit</button>
                        <button onclick="hapusKartu(<?= $kartu['id_kartu'] ?>)" class="btn-action btn-hapus"><i class="fas fa-trash"></i> Hapus</button>
                    </div>
                </div>
                <?php endforeach; ?>

                <?php if (empty($kartu_ujian)): ?>
                <div class="col-span-full text-center py-16">
                    <div class="bg-white rounded-xl p-12 shadow-lg max-w-2xl mx-auto">
                        <i class="fas fa-id-card text-6xl text-gray-300 mb-4"></i>
                        <p class="text-gray-500 text-xl mb-6">Belum ada data kartu ujian</p>
                        <button onclick="bukaModalTambah()" class="btn-primary btn-purple">
                            <i class="fas fa-plus-circle"></i> Tambah Kartu
                        </button>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="mt-6 text-right text-sm text-gray-500">
                <i class="fas fa-id-card mr-1"></i> Total <?= count($kartu_ujian) ?> kartu ujian
            </div>
        </main>
    </div>

    <!-- MODAL TAMBAH -->
    <div id="modalTambah" class="modal">
        <div class="modal-content">
            <div class="bg-[#8e44ad] text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h3 class="text-lg font-bold"><i class="fas fa-plus-circle mr-2"></i> Tambah Kartu Ujian</h3>
                <button onclick="tutupModalTambah()" class="text-white hover:text-gray-200 text-2xl">&times;</button>
            </div>
            <form method="POST" enctype="multipart/form-data" class="p-6" id="formTambah">
                <input type="hidden" name="action" value="tambah">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-bold mb-1">NIS <span class="text-red-500">*</span></label>
                        <input type="text" name="nis" required class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Nama Siswa <span class="text-red-500">*</span></label>
                        <input type="text" name="nama_siswa" required class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Kelas</label>
                        <input type="text" name="kelas" class="w-full border border-gray-300 rounded-lg p-2" placeholder="Contoh: XII RPL 1">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Jurusan</label>
                        <input type="text" name="jurusan" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">SID/NISN</label>
                        <input type="text" name="sid" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Username Ujian</label>
                        <input type="text" name="username_ujian" class="w-full border border-gray-300 rounded-lg p-2" placeholder="Kosongkan = pakai NIS">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Password Ujian</label>
                        <input type="text" name="password_ujian" class="w-full border border-gray-300 rounded-lg p-2" value="123456">
                    </div>
                    <div class="col-span-2">
                        <label class="block text-sm font-bold mb-1">Foto Siswa</label>
                        <input type="file" name="foto_siswa" accept="image/*" class="w-full border border-gray-300 rounded-lg p-1">
                    </div>
                </div>
                <div class="flex gap-3 justify-end mt-6">
                    <button type="button" onclick="tutupModalTambah()" class="px-4 py-2 border border-gray-300 rounded-lg">Batal</button>
                    <button type="submit" class="px-4 py-2 bg-[#8e44ad] text-white rounded-lg"><i class="fas fa-save"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL EDIT -->
    <div id="modalEdit" class="modal">
        <div class="modal-content">
            <div class="bg-[#e67e22] text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h3 class="text-lg font-bold"><i class="fas fa-edit mr-2"></i> Edit Kartu Ujian</h3>
                <button onclick="tutupModalEdit()" class="text-white hover:text-gray-200 text-2xl">&times;</button>
            </div>
            <form method="POST" enctype="multipart/form-data" class="p-6" id="formEdit">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id_kartu" id="edit_id">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-bold mb-1">NIS</label>
                        <input type="text" name="nis" id="edit_nis" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Nama Siswa</label>
                        <input type="text" name="nama_siswa" id="edit_nama_siswa" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Kelas</label>
                        <input type="text" name="kelas" id="edit_kelas" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Jurusan</label>
                        <input type="text" name="jurusan" id="edit_jurusan" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">SID/NISN</label>
                        <input type="text" name="sid" id="edit_sid" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" id="edit_tempat_lahir" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" id="edit_tanggal_lahir" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Username Ujian</label>
                        <input type="text" name="username_ujian" id="edit_username_ujian" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold mb-1">Password Ujian</label>
                        <input type="text" name="password_ujian" id="edit_password_ujian" class="w-full border border-gray-300 rounded-lg p-2">
                    </div>
                    <div class="col-span-2">
                        <div id="edit_foto_preview" class="mb-2"></div>
                        <label class="block text-sm font-bold mb-1">Ganti Foto</label>
                        <input type="file" name="foto_siswa" accept="image/*" class="w-full border border-gray-300 rounded-lg p-1">
                    </div>
                </div>
                <div class="flex gap-3 justify-end mt-6">
                    <button type="button" onclick="tutupModalEdit()" class="px-4 py-2 border border-gray-300 rounded-lg">Batal</button>
                    <button type="submit" class="px-4 py-2 bg-[#e67e22] text-white rounded-lg"><i class="fas fa-save"></i> Update</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Filter functions
        function filterData() {
            let search = document.getElementById('searchInput').value;
            let kelas = document.getElementById('kelasFilter').value;
            window.location.href = `kartu_ujian.php?search=${encodeURIComponent(search)}&kelas=${encodeURIComponent(kelas)}`;
        }
        
        function resetFilter() {
            window.location.href = 'kartu_ujian.php';
        }
        
        // Print functions
        function cetakKartu(id) { 
            window.open(`cetak_kartu.php?id=${id}`, '_blank'); 
        }
        
        function cetakSemuaKartu() {
            let kelas = document.getElementById('kelasFilter').value;
            let search = document.getElementById('searchInput').value;
            window.open(`cetak_kartu_all.php?kelas=${encodeURIComponent(kelas)}&search=${encodeURIComponent(search)}`, '_blank');
        }
        
        // Delete function
        function hapusKartu(id) {
            Swal.fire({
                title: 'Hapus Kartu?',
                text: 'Data tidak dapat dikembalikan!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc2626',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `kartu_ujian.php?hapus_id=${id}`;
                }
            });
        }
        
        // Modal Tambah
        function bukaModalTambah() {
            document.getElementById('modalTambah').classList.add('active');
        }
        
        function tutupModalTambah() {
            document.getElementById('modalTambah').classList.remove('active');
            document.getElementById('formTambah').reset();
        }
        
        // Modal Edit
        function bukaModalEdit(id) {
            fetch(`kartu_ujian.php?get_data=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (!data.error) {
                        document.getElementById('edit_id').value = data.id_kartu;
                        document.getElementById('edit_nis').value = data.nis;
                        document.getElementById('edit_nama_siswa').value = data.nama_siswa;
                        document.getElementById('edit_kelas').value = data.kelas;
                        document.getElementById('edit_jurusan').value = data.jurusan || '';
                        document.getElementById('edit_sid').value = data.sid || '';
                        document.getElementById('edit_tempat_lahir').value = data.tempat_lahir || '';
                        document.getElementById('edit_tanggal_lahir').value = data.tanggal_lahir || '';
                        document.getElementById('edit_username_ujian').value = data.username_ujian || '';
                        document.getElementById('edit_password_ujian').value = data.password_ujian || '';
                        
                        if (data.foto_siswa) {
                            document.getElementById('edit_foto_preview').innerHTML = `<img src="../../uploads/${data.foto_siswa}" class="foto-preview"><p class="text-xs text-gray-500 mt-1">Foto saat ini</p>`;
                        } else {
                            document.getElementById('edit_foto_preview').innerHTML = '<span class="text-gray-500 text-sm">Tidak ada foto</span>';
                        }
                        
                        document.getElementById('modalEdit').classList.add('active');
                    } else {
                        Swal.fire('Error', 'Gagal mengambil data', 'error');
                    }
                })
                .catch(() => Swal.fire('Error', 'Terjadi kesalahan', 'error'));
        }
        
        function tutupModalEdit() {
            document.getElementById('modalEdit').classList.remove('active');
            document.getElementById('formEdit').reset();
            document.getElementById('edit_foto_preview').innerHTML = '';
        }
        
        // Form submit handlers
        document.getElementById('formTambah')?.addEventListener('submit', function(e) {
            e.preventDefault();
            let formData = new FormData(this);
            Swal.fire({ title: 'Menyimpan...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
            fetch('kartu_ujian.php', { method: 'POST', body: formData })
                .then(response => response.text())
                .then(() => {
                    Swal.fire({ icon: 'success', title: 'Berhasil!' }).then(() => location.reload());
                })
                .catch(() => Swal.fire({ icon: 'error', title: 'Gagal!', text: 'Terjadi kesalahan' }));
        });
        
        document.getElementById('formEdit')?.addEventListener('submit', function(e) {
            e.preventDefault();
            let formData = new FormData(this);
            Swal.fire({ title: 'Menyimpan...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
            fetch('kartu_ujian.php', { method: 'POST', body: formData })
                .then(response => response.text())
                .then(() => {
                    Swal.fire({ icon: 'success', title: 'Berhasil!' }).then(() => location.reload());
                })
                .catch(() => Swal.fire({ icon: 'error', title: 'Gagal!', text: 'Terjadi kesalahan' }));
        });
        
        // Enter key search
        document.getElementById('searchInput').addEventListener('keypress', function(e) { 
            if (e.key === 'Enter') filterData(); 
        });
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>

</html>