<?php
// =============================================
// FILE: pages/admin/perbaikan_nilai.php
// =============================================

session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit;
}

require_once '../../config/koneksi.php';

$conn = new mysqli("localhost", "root", "", "db_ujian_sekolah");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// =============================================
// FILTER PARAMETER
// =============================================
$kelas_id    = isset($_GET['kelas_id']) ? (int)$_GET['kelas_id'] : 0;
$mapel_id    = isset($_GET['mapel_id']) ? (int)$_GET['mapel_id'] : 0;
$ujian_id    = isset($_GET['ujian_id']) ? (int)$_GET['ujian_id'] : 0;
$siswa_id    = isset($_GET['siswa_id']) ? (int)$_GET['siswa_id'] : 0;
$export      = isset($_GET['export']) ? $_GET['export'] : '';
$action      = isset($_GET['action']) ? $_GET['action'] : '';
$delete_id   = isset($_GET['delete_id']) ? (int)$_GET['delete_id'] : 0;

// =============================================
// AMBIL DATA UNTUK FILTER
// =============================================

// Ambil daftar kelas (tb_kelas)
$kelas_list = $conn->query("
    SELECT id_kelas AS id, nama_kelas, tingkat 
    FROM tb_kelas 
    ORDER BY FIELD(tingkat, 'X', 'XI', 'XII'), nama_kelas
");

// Ambil daftar mata pelajaran (tb_mapel)
$mapel_list = $conn->query("
    SELECT id_mapel AS id, nama_mapel, kode_mapel 
    FROM tb_mapel 
    ORDER BY nama_mapel
");

// Ambil daftar ujian berdasarkan filter
$ujian_list = null;
if ($mapel_id > 0) {
    $ujian_list = $conn->query("
        SELECT DISTINCT 
            u.id_ujian AS id, 
            u.judul_ujian AS nama_ujian, 
            u.tanggal_ujian,
            u.jam_mulai,
            u.jam_selesai,
            u.durasi_menit AS durasi,
            k.nama_kelas, 
            k.tingkat, 
            mp.nama_mapel
        FROM tb_ujian u
        JOIN tb_ujian_kelas uk ON u.id_ujian = uk.id_ujian
        JOIN tb_kelas k ON uk.id_kelas = k.id_kelas
        JOIN tb_mapel mp ON u.id_mapel = mp.id_mapel
        WHERE u.id_mapel = $mapel_id
        " . ($kelas_id > 0 ? "AND k.id_kelas = $kelas_id" : "") . "
        ORDER BY FIELD(k.tingkat, 'X', 'XI', 'XII'), k.nama_kelas, u.tanggal_ujian DESC
    ");
}

// =============================================
// AMBIL DATA NILAI SISWA DARI TABEL hasil_ujian
// =============================================
$nilai_siswa = null;
$detail_ujian = null;
$statistik = null;
$all_nilai_data = [];

if ($ujian_id > 0) {
    // Detail ujian
    $detail_query = "
        SELECT 
            u.id_ujian,
            u.judul_ujian,
            u.tanggal_ujian,
            u.jam_mulai,
            u.jam_selesai,
            u.durasi_menit,
            u.status_ujian,
            u.anti_tab,
            u.acak_soal,
            k.nama_kelas, 
            k.tingkat, 
            mp.nama_mapel, 
            mp.kode_mapel,
            g.nama_lengkap AS nama_guru
        FROM tb_ujian u
        JOIN tb_ujian_kelas uk ON u.id_ujian = uk.id_ujian
        JOIN tb_kelas k ON uk.id_kelas = k.id_kelas
        JOIN tb_mapel mp ON u.id_mapel = mp.id_mapel
        LEFT JOIN tb_users g ON u.id_guru = g.id_user
        WHERE u.id_ujian = $ujian_id
        LIMIT 1
    ";
    $detail_result = $conn->query($detail_query);
    
    if ($detail_result && $detail_result->num_rows > 0) {
        $detail_ujian = $detail_result->fetch_assoc();
        
        // Data nilai siswa dari tabel hasil_ujian dengan deteksi kecurangan
        $nilai_siswa = $conn->query("
            SELECT 
                h.id,
                h.siswa_id,
                h.ujian_id,
                h.nilai,
                h.waktu_mulai,
                h.waktu_selesai,
                h.status,
                h.jawaban,
                s.nis,
                s.nama_lengkap AS nama_siswa,
                s.jenis_kelamin,
                COALESCE(t.tab_switch_count, 0) AS tab_switch_count,
                COALESCE(t.last_switch_time, '') AS last_switch_time
            FROM hasil_ujian h
            JOIN tb_users s ON h.siswa_id = s.id_user
            LEFT JOIN (
                SELECT siswa_id, ujian_id, COUNT(*) AS tab_switch_count, MAX(switch_time) AS last_switch_time
                FROM tb_tab_switch_log
                GROUP BY siswa_id, ujian_id
            ) t ON t.siswa_id = h.siswa_id AND t.ujian_id = h.ujian_id
            WHERE h.ujian_id = $ujian_id
            ORDER BY h.nilai DESC, s.nama_lengkap ASC
        ");
        
        // Simpan semua data untuk export
        if ($nilai_siswa) {
            while($row = $nilai_siswa->fetch_assoc()) {
                $all_nilai_data[] = $row;
            }
            // Reset pointer
            $nilai_siswa = $conn->query("
                SELECT 
                    h.id,
                    h.siswa_id,
                    h.ujian_id,
                    h.nilai,
                    h.waktu_mulai,
                    h.waktu_selesai,
                    h.status,
                    h.jawaban,
                    s.nis,
                    s.nama_lengkap AS nama_siswa,
                    s.jenis_kelamin,
                    COALESCE(t.tab_switch_count, 0) AS tab_switch_count,
                    COALESCE(t.last_switch_time, '') AS last_switch_time
                FROM hasil_ujian h
                JOIN tb_users s ON h.siswa_id = s.id_user
                LEFT JOIN (
                    SELECT siswa_id, ujian_id, COUNT(*) AS tab_switch_count, MAX(switch_time) AS last_switch_time
                    FROM tb_tab_switch_log
                    GROUP BY siswa_id, ujian_id
                ) t ON t.siswa_id = h.siswa_id AND t.ujian_id = h.ujian_id
                WHERE h.ujian_id = $ujian_id
                ORDER BY h.nilai DESC, s.nama_lengkap ASC
            ");
        }
        
        // Statistik nilai
        $stat_result = $conn->query("
            SELECT 
                COUNT(*) AS total_siswa,
                AVG(nilai) AS rata_rata,
                MAX(nilai) AS nilai_tertinggi,
                MIN(nilai) AS nilai_terendah,
                SUM(CASE WHEN nilai >= 75 THEN 1 ELSE 0 END) AS siswa_lulus,
                SUM(CASE WHEN nilai < 75 THEN 1 ELSE 0 END) AS siswa_tidak_lulus,
                SUM(COALESCE(t.tab_switch_count, 0)) AS total_tab_switch
            FROM hasil_ujian h
            LEFT JOIN (
                SELECT siswa_id, ujian_id, COUNT(*) AS tab_switch_count
                FROM tb_tab_switch_log
                GROUP BY siswa_id, ujian_id
            ) t ON t.siswa_id = h.siswa_id AND t.ujian_id = h.ujian_id
            WHERE h.ujian_id = $ujian_id
        ");
        
        if ($stat_result) {
            $statistik = $stat_result->fetch_assoc();
        }
        
        // Ambil total soal untuk ujian ini
        $total_soal_query = $conn->query("
            SELECT COUNT(*) AS total 
            FROM tb_soal 
            WHERE id_ujian = $ujian_id
        ");
        $total_soal = $total_soal_query->fetch_assoc()['total'] ?? 0;
    }
}

// =============================================
// CRUD OPERATIONS
// =============================================

// Hapus nilai
if ($action === 'delete' && $delete_id > 0) {
    $conn->query("DELETE FROM hasil_ujian WHERE id = $delete_id");
    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Data nilai berhasil dihapus!'];
    header("Location: perbaikan_nilai.php?ujian_id=$ujian_id" . 
           ($kelas_id > 0 ? "&kelas_id=$kelas_id" : "") .
           ($mapel_id > 0 ? "&mapel_id=$mapel_id" : ""));
    exit;
}

// Simpan/Update nilai
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_nilai'])) {
    $ujian_id_post = (int)$_POST['ujian_id'];
    $siswa_id_post = (int)$_POST['siswa_id'];
    $nilai_baru = (float)$_POST['nilai'];
    $catatan = trim($_POST['catatan'] ?? '');
    
    if ($nilai_baru < 0 || $nilai_baru > 100) {
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Nilai harus antara 0-100!'];
    } else {
        $cek = $conn->query("
            SELECT id FROM hasil_ujian 
            WHERE ujian_id = $ujian_id_post AND siswa_id = $siswa_id_post
        ");
        
        if ($cek && $cek->num_rows > 0) {
            $update = $conn->prepare("
                UPDATE hasil_ujian 
                SET nilai = ?, catatan_guru = ?, status = 'selesai'
                WHERE ujian_id = ? AND siswa_id = ?
            ");
            $update->bind_param("dsii", $nilai_baru, $catatan, $ujian_id_post, $siswa_id_post);
        } else {
            $update = $conn->prepare("
                INSERT INTO hasil_ujian (ujian_id, siswa_id, nilai, catatan_guru, status, waktu_mulai, waktu_selesai)
                VALUES (?, ?, ?, ?, 'selesai', NOW(), NOW())
            ");
            $update->bind_param("iids", $ujian_id_post, $siswa_id_post, $nilai_baru, $catatan);
        }
        
        if ($update->execute()) {
            $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Nilai berhasil diperbarui!'];
        } else {
            $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Gagal memperbarui nilai: ' . $conn->error];
        }
    }
    
    header("Location: perbaikan_nilai.php?ujian_id=$ujian_id_post" . 
           ($kelas_id > 0 ? "&kelas_id=$kelas_id" : "") .
           ($mapel_id > 0 ? "&mapel_id=$mapel_id" : ""));
    exit;
}

// Tambah nilai baru
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_nilai'])) {
    $ujian_id_post = (int)$_POST['ujian_id'];
    $siswa_id_post = (int)$_POST['siswa_id'];
    $nilai_baru = (float)$_POST['nilai'];
    
    if ($nilai_baru < 0 || $nilai_baru > 100) {
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Nilai harus antara 0-100!'];
    } else {
        // Jumlah kolom (6) dan jumlah values (6) sekarang sudah sama
        $insert = $conn->prepare("
            INSERT INTO hasil_ujian (ujian_id, siswa_id, nilai, status, waktu_mulai, waktu_selesai)
            VALUES (?, ?, ?, 'selesai', NOW(), NOW())
        ");
        
        // Menghapus 's' (string) dan variabel catatan, menyisakan 'iid' (integer, integer, double)
        $insert->bind_param("iid", $ujian_id_post, $siswa_id_post, $nilai_baru);
        
        if ($insert->execute()) {
            $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Nilai berhasil ditambahkan!'];
        } else {
            $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Gagal menambahkan nilai!'];
        }
    }
    
    header("Location: perbaikan_nilai.php?ujian_id=$ujian_id_post" . 
           ($kelas_id > 0 ? "&kelas_id=$kelas_id" : "") .
           ($mapel_id > 0 ? "&mapel_id=$mapel_id" : ""));
    exit;
}

// =============================================
// EXPORT EXCEL
// =============================================
if ($export === 'excel' && $ujian_id > 0 && !empty($all_nilai_data)) {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Nilai_Ujian_" . date('Y-m-d') . ".xls");
    
    echo "<html><head><meta charset='UTF-8'></head><body>";
    echo "<h2>Laporan Nilai Ujian</h2>";
    echo "<h3>" . htmlspecialchars($detail_ujian['judul_ujian']) . "</h3>";
    echo "<p>Kelas: " . htmlspecialchars($detail_ujian['nama_kelas']) . " | Mata Pelajaran: " . htmlspecialchars($detail_ujian['nama_mapel']) . "</p>";
    echo "<p>Tanggal: " . date('d/m/Y', strtotime($detail_ujian['tanggal_ujian'])) . "</p>";
    echo "<hr>";
    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr style='background:#f0f0f0;'>";
    echo "<th>No</th>";
    echo "<th>NIS</th>";
    echo "<th>Nama Siswa</th>";
    echo "<th>Jenis Kelamin</th>";
    echo "<th>Nilai</th>";
    echo "<th>Status</th>";
    echo "<th>Tab Switch</th>";
    echo "<th>Waktu Mulai</th>";
    echo "<th>Waktu Selesai</th>";
    echo "</tr>";
    
    $no = 1;
    foreach($all_nilai_data as $row) {
        $tab_switch_danger = $row['tab_switch_count'] > 3 ? '<span style="color:red;">⚠️ ' . $row['tab_switch_count'] . '</span>' : $row['tab_switch_count'];
        echo "<tr>";
        echo "<td>" . $no++ . "</td>";
        echo "<td>" . $row['nis'] . "</td>";
        echo "<td>" . $row['nama_siswa'] . "</td>";
        echo "<td>" . ($row['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan') . "</td>";
        echo "<td align='center'>" . ($row['nilai'] ?? '-') . "</td>";
        echo "<td align='center'>" . ($row['status'] == 'selesai' ? 'Selesai' : 'Sedang') . "</td>";
        echo "<td align='center'>" . $tab_switch_danger . "</td>";
        echo "<td>" . ($row['waktu_mulai'] ? date('d/m/Y H:i', strtotime($row['waktu_mulai'])) : '-') . "</td>";
        echo "<td>" . ($row['waktu_selesai'] ? date('d/m/Y H:i', strtotime($row['waktu_selesai'])) : '-') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "<p><small>Dicetak pada: " . date('d/m/Y H:i:s') . "</small></p>";
    echo "</body></html>";
    exit;
}

// Ambil total soal
$total_soal = 0;
if ($ujian_id > 0) {
    $soal_count = $conn->query("SELECT COUNT(*) AS total FROM tb_soal WHERE id_ujian = $ujian_id");
    if ($soal_count) {
        $total_soal = $soal_count->fetch_assoc()['total'];
    }
}

// Ambil daftar siswa untuk dropdown tambah nilai
$siswa_list = [];
if ($ujian_id > 0) {
    $siswa_query = $conn->query("
        SELECT s.id_user, s.nis, s.nama_lengkap
        FROM tb_users s
        WHERE s.role = 'siswa'
        AND s.id_user NOT IN (
            SELECT siswa_id FROM hasil_ujian WHERE ujian_id = $ujian_id
        )
        ORDER BY s.nama_lengkap
    ");
    if ($siswa_query) {
        while($row = $siswa_query->fetch_assoc()) {
            $siswa_list[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Perbaikan Nilai Ujian</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-1: #2B3A67;
            --primary-2: #496A81;
            --secondary-1: #66999B;
            --secondary-2: #B3AF8F;
            --accent-1: #FFC482;
            --accent-2: #DDB7AB;
            --neutral-1: #F8F4E9;
            --neutral-2: #E8E1D3;
            --dark: #2E3B4E;
            --success: #77BFA3;
            --warning: #FFB347;
            --danger: #E58C7C;
        }
        
        body {
            background: var(--neutral-1);
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }
        
        .card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
        }
        
        .btn-primary {
            background: var(--primary-1);
            color: white;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            background: var(--primary-2);
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: var(--secondary-2);
            color: var(--dark);
            transition: all 0.3s ease;
        }
        
        .btn-secondary:hover {
            background: var(--secondary-1);
            color: white;
            transform: translateY(-2px);
        }
        
        .btn-success {
            background: var(--success);
            color: white;
            transition: all 0.3s ease;
        }
        
        .btn-success:hover {
            background: #5BA088;
            transform: translateY(-2px);
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
            transition: all 0.3s ease;
        }
        
        .btn-danger:hover {
            background: #C97769;
            transform: translateY(-2px);
        }
        
        .stat-card {
            background: linear-gradient(135deg, var(--primary-1) 0%, var(--primary-2) 100%);
            border-radius: 16px;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .table-header {
            background: var(--neutral-2);
            color: var(--dark);
        }
        
        .badge-success {
            background: var(--success);
            color: white;
        }
        
        .badge-warning {
            background: var(--warning);
            color: white;
        }
        
        .badge-sedang {
            background: var(--accent-1);
            color: var(--dark);
        }
        
        .badge-danger {
            background: var(--danger);
            color: white;
        }
        
        .filter-select, .filter-input {
            border: 2px solid var(--neutral-2);
            border-radius: 12px;
            transition: all 0.3s ease;
        }
        
        .filter-select:focus, .filter-input:focus {
            border-color: var(--primary-2);
            outline: none;
            box-shadow: 0 0 0 3px rgba(73, 106, 129, 0.1);
        }
        
        .ujian-card {
            background: white;
            border-radius: 16px;
            border: 2px solid transparent;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .ujian-card:hover {
            transform: translateY(-4px);
            border-color: var(--accent-1);
        }
        
        .ujian-card.active {
            border-color: var(--primary-1);
            background: linear-gradient(135deg, rgba(43, 58, 103, 0.05) 0%, rgba(73, 106, 129, 0.05) 100%);
        }
        
        .modal-content {
            border-radius: 24px;
        }
        
        .gradient-text {
            background: linear-gradient(135deg, var(--primary-1) 0%, var(--secondary-1) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .nilai-cell {
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .nilai-cell:hover {
            transform: scale(1.05);
        }
        
        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 0.5rem;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1);
            min-width: 200px;
            z-index: 50;
            opacity: 0;
            visibility: hidden;
            transition: all 0.2s ease;
        }
        
        .dropdown-menu.show {
            opacity: 1;
            visibility: visible;
        }
        
        .tab-switch-warning {
            background: linear-gradient(135deg, #FFF3E0 0%, #FFE0B2 100%);
            border-left: 4px solid var(--warning);
        }
        
        .tab-switch-danger {
            background: linear-gradient(135deg, #FFEBEE 0%, #FFCDD2 100%);
            border-left: 4px solid var(--danger);
        }
        
        @media print {
            .no-print, .btn-primary, .btn-secondary, .btn-success, .btn-danger, 
            .filter-select, .filter-input, .ujian-card, .card .flex.gap-2, 
            #filterForm .flex.items-end, .stat-card, .nilai-cell:hover,
            .no-print, .dropdown-menu {
                display: none !important;
            }
            body {
                background: white;
                padding: 0;
                margin: 0;
            }
            .card {
                box-shadow: none;
                border: 1px solid #ddd;
                break-inside: avoid;
            }
            .table-header {
                background: #f0f0f0;
            }
            table {
                width: 100%;
                border-collapse: collapse;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 8px;
            }
            @page {
                size: landscape;
                margin: 1cm;
            }
        }
    </style>
</head>
<body>

<div class="min-h-screen py-8 px-4 md:px-8">
    <div class="max-w-7xl mx-auto">
        
        <!-- HEADER -->
        <div class="text-center mb-10">
            <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white shadow-lg mb-4">
                <i class="fas fa-edit text-3xl" style="color: var(--primary-1);"></i>
            </div>
            <h1 class="text-4xl font-bold gradient-text mb-2">
                Perbaikan Nilai Ujian
            </h1>
            <p class="text-gray-500">Edit dan perbaiki nilai siswa berdasarkan kelas dan mata pelajaran</p>
        </div>

        <!-- FLASH MESSAGE -->
        <?php if (isset($_SESSION['flash'])): ?>
            <div class="mb-6 p-4 rounded-xl <?= $_SESSION['flash']['type'] === 'success' ? 'bg-green-100 text-green-700 border-l-4 border-green-500' : 'bg-red-100 text-red-700 border-l-4 border-red-500' ?>">
                <i class="fas <?= $_SESSION['flash']['type'] === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle' ?> mr-2"></i>
                <?= htmlspecialchars($_SESSION['flash']['msg']) ?>
                <?php unset($_SESSION['flash']); ?>
            </div>
        <?php endif; ?>

        <!-- FILTER SECTION -->
        <div class="card p-6 mb-8 no-print">
            <h2 class="text-lg font-semibold mb-4" style="color: var(--primary-1);">
                <i class="fas fa-filter mr-2"></i> Filter Data Nilai
            </h2>
            
            <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4" id="filterForm">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">📚 Kelas</label>
                    <select name="kelas_id" class="filter-select w-full px-4 py-2.5" id="kelasSelect">
                        <option value="">Semua Kelas</option>
                        <?php if ($kelas_list && $kelas_list->num_rows > 0): ?>
                            <?php $kelas_list->data_seek(0); ?>
                            <?php while($k = $kelas_list->fetch_assoc()): ?>
                                <option value="<?= $k['id'] ?>" <?= $kelas_id == $k['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($k['nama_kelas']) ?> (<?= $k['tingkat'] ?>)
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">📖 Mata Pelajaran</label>
                    <select name="mapel_id" class="filter-select w-full px-4 py-2.5" id="mapelSelect">
                        <option value="">Pilih Mata Pelajaran</option>
                        <?php if ($mapel_list && $mapel_list->num_rows > 0): ?>
                            <?php $mapel_list->data_seek(0); ?>
                            <?php while($m = $mapel_list->fetch_assoc()): ?>
                                <option value="<?= $m['id'] ?>" <?= $mapel_id == $m['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($m['nama_mapel']) ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>
                
                <div class="flex items-end gap-2">
                    <button type="submit" class="btn-primary px-6 py-2.5 rounded-xl flex items-center gap-2 font-semibold">
                        <i class="fas fa-search"></i> Tampilkan
                    </button>
                    <a href="perbaikan_nilai.php" class="btn-secondary px-6 py-2.5 rounded-xl flex items-center gap-2 font-semibold">
                        <i class="fas fa-sync-alt"></i> Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- DAFTAR UJIAN -->
        <?php if ($mapel_id > 0): ?>
            <div class="mb-8 no-print">
                <h2 class="text-xl font-bold mb-4" style="color: var(--primary-1);">
                    <i class="fas fa-calendar-alt mr-2" style="color: var(--accent-1);"></i> Daftar Ujian
                    <?php if ($ujian_list && $ujian_list->num_rows > 0): ?>
                        <span class="text-sm font-normal text-gray-500 ml-2">(<?= $ujian_list->num_rows ?> ujian)</span>
                    <?php endif; ?>
                </h2>
                
                <?php if ($ujian_list && $ujian_list->num_rows > 0): ?>
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                        <?php while($ujian = $ujian_list->fetch_assoc()): ?>
                            <a href="?ujian_id=<?= $ujian['id'] ?>&kelas_id=<?= $kelas_id ?>&mapel_id=<?= $mapel_id ?>" 
                               class="ujian-card <?= $ujian_id == $ujian['id'] ? 'active' : '' ?> p-5 block">
                                <div class="flex justify-between items-start mb-3">
                                    <h3 class="font-bold text-lg" style="color: var(--primary-1);">
                                        <?= htmlspecialchars($ujian['nama_ujian']) ?>
                                    </h3>
                                    <?php if ($ujian_id == $ujian['id']): ?>
                                        <span class="px-2 py-1 rounded-full text-xs font-semibold" style="background: var(--primary-1); color: white;">
                                            <i class="fas fa-check mr-1"></i> Dipilih
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-sm text-gray-600 space-y-2">
                                    <p><i class="fas fa-chalkboard mr-2" style="color: var(--secondary-1);"></i> <?= htmlspecialchars($ujian['nama_kelas']) ?></p>
                                    <p><i class="fas fa-book mr-2" style="color: var(--secondary-1);"></i> <?= htmlspecialchars($ujian['nama_mapel']) ?></p>
                                    <p><i class="far fa-calendar mr-2" style="color: var(--secondary-1);"></i> <?= date('d/m/Y', strtotime($ujian['tanggal_ujian'])) ?></p>
                                    <p><i class="fas fa-clock mr-2" style="color: var(--secondary-1);"></i> <?= date('H:i', strtotime($ujian['jam_mulai'])) ?> - <?= date('H:i', strtotime($ujian['jam_selesai'])) ?></p>
                                    <p><i class="fas fa-hourglass-half mr-2" style="color: var(--secondary-1);"></i> <?= $ujian['durasi'] ?> menit</p>
                                </div>
                            </a>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="card p-12 text-center">
                        <i class="fas fa-info-circle text-5xl mb-4" style="color: var(--warning);"></i>
                        <p class="text-gray-600">Belum ada ujian untuk mata pelajaran ini dengan filter yang dipilih.</p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- TABEL NILAI SISWA -->
        <?php if ($ujian_id > 0 && $detail_ujian): ?>
            
            <!-- INFO UJIAN & EXPORT BUTTONS -->
            <div class="card p-6 mb-8">
                <div class="flex flex-wrap justify-between items-start gap-4">
                    <div>
                        <div class="flex items-center gap-2 mb-2">
                            <div class="w-1 h-8 rounded-full" style="background: var(--primary-1);"></div>
                            <h2 class="text-2xl font-bold" style="color: var(--primary-1);">
                                <?= htmlspecialchars($detail_ujian['judul_ujian']) ?>
                            </h2>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mt-4">
                            <div class="flex items-center gap-2 text-gray-600">
                                <i class="fas fa-school" style="color: var(--secondary-1);"></i>
                                <span>Kelas <?= htmlspecialchars($detail_ujian['tingkat'] ?? '') ?> - <?= htmlspecialchars($detail_ujian['nama_kelas'] ?? '') ?></span>
                            </div>
                            <div class="flex items-center gap-2 text-gray-600">
                                <i class="fas fa-book" style="color: var(--secondary-1);"></i>
                                <span><?= htmlspecialchars($detail_ujian['nama_mapel'] ?? '') ?></span>
                            </div>
                            <div class="flex items-center gap-2 text-gray-600">
                                <i class="fas fa-user" style="color: var(--secondary-1);"></i>
                                <span>Guru: <?= htmlspecialchars($detail_ujian['nama_guru'] ?? 'Administrator') ?></span>
                            </div>
                            <div class="flex items-center gap-2 text-gray-600">
                                <i class="fas fa-calendar-alt" style="color: var(--secondary-1);"></i>
                                <span><?= date('d/m/Y', strtotime($detail_ujian['tanggal_ujian'])) ?> | <?= date('H:i', strtotime($detail_ujian['jam_mulai'])) ?> WIB</span>
                            </div>
                            <div class="flex items-center gap-2 text-gray-600">
                                <i class="fas fa-shield-alt" style="color: var(--warning);"></i>
                                <span>Anti Tab: <?= $detail_ujian['anti_tab'] == '1' ? '<span class="text-green-600">Aktif</span>' : '<span class="text-gray-400">Nonaktif</span>' ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- EXPORT BUTTONS -->
                    <div class="flex gap-2 no-print flex-wrap">
                        <button onclick="openTambahModal()" class="btn-success px-5 py-2.5 rounded-xl flex items-center gap-2 font-semibold transition">
                            <i class="fas fa-plus"></i> Tambah Nilai
                        </button>
                        <a href="?export=excel&ujian_id=<?= $ujian_id ?>&kelas_id=<?= $kelas_id ?>&mapel_id=<?= $mapel_id ?>" 
                           class="btn-primary px-5 py-2.5 rounded-xl flex items-center gap-2 font-semibold transition">
                            <i class="fas fa-file-excel"></i> Excel
                        </a>
                        <button onclick="window.print()" 
                                class="btn-danger px-5 py-2.5 rounded-xl flex items-center gap-2 font-semibold transition">
                            <i class="fas fa-print"></i> Print
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- STATISTIK KARTU -->
            <?php if ($statistik && $statistik['total_siswa'] > 0): ?>
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-4 mb-8 no-print">
                    <div class="stat-card p-4 text-white">
                        <p class="text-sm opacity-90">Total Peserta</p>
                        <p class="text-2xl font-bold"><?= $statistik['total_siswa'] ?? 0 ?></p>
                    </div>
                    <div class="stat-card p-4 text-white" style="background: linear-gradient(135deg, var(--success) 0%, #5BA088 100%);">
                        <p class="text-sm opacity-90">Rata-rata</p>
                        <p class="text-2xl font-bold"><?= number_format($statistik['rata_rata'] ?? 0, 1) ?></p>
                    </div>
                    <div class="stat-card p-4 text-white" style="background: linear-gradient(135deg, var(--warning) 0%, #E8A040 100%);">
                        <p class="text-sm opacity-90">Tertinggi</p>
                        <p class="text-2xl font-bold"><?= $statistik['nilai_tertinggi'] ?? 0 ?></p>
                    </div>
                    <div class="stat-card p-4 text-white" style="background: linear-gradient(135deg, var(--danger) 0%, #C97769 100%);">
                        <p class="text-sm opacity-90">Terendah</p>
                        <p class="text-2xl font-bold"><?= $statistik['nilai_terendah'] ?? 0 ?></p>
                    </div>
                    <div class="stat-card p-4 text-white" style="background: linear-gradient(135deg, var(--primary-2) 0%, #3D5A6E 100%);">
                        <p class="text-sm opacity-90">Lulus</p>
                        <p class="text-2xl font-bold"><?= $statistik['siswa_lulus'] ?? 0 ?></p>
                    </div>
                    <div class="stat-card p-4 text-white" style="background: linear-gradient(135deg, #8B6B4D 0%, #6B5040 100%);">
                        <p class="text-sm opacity-90">Tidak Lulus</p>
                        <p class="text-2xl font-bold"><?= $statistik['siswa_tidak_lulus'] ?? 0 ?></p>
                    </div>
                    <div class="stat-card p-4 text-white" style="background: linear-gradient(135deg, #E8A040 0%, #D38A2A 100%);">
                        <p class="text-sm opacity-90">Tab Switch</p>
                        <p class="text-2xl font-bold"><?= $statistik['total_tab_switch'] ?? 0 ?></p>
                        <p class="text-xs opacity-75 mt-1">kali</p>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- TABEL NILAI SISWA -->
            <div class="card overflow-hidden">
                <div class="px-6 py-4 flex justify-between items-center" style="background: var(--neutral-2);">
                    <h3 class="text-lg font-semibold" style="color: var(--dark);">
                        <i class="fas fa-users mr-2" style="color: var(--primary-1);"></i> Daftar Nilai Siswa
                    </h3>
                    <div class="text-sm text-gray-500">
                        <i class="fas fa-mouse-pointer mr-1"></i> Klik nilai untuk edit | <i class="fas fa-trash mr-1 text-red-500"></i> Hapus
                    </div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="table-header">
                            <tr class="text-left text-sm">
                                <th class="px-6 py-4">No</th>
                                <th class="px-6 py-4">NIS</th>
                                <th class="px-6 py-4">Nama Siswa</th>
                                <th class="px-6 py-4">JK</th>
                                <th class="px-6 py-4">Nilai</th>
                                <th class="px-6 py-4">Status</th>
                                <th class="px-6 py-4">Tab Switch</th>
                                <th class="px-6 py-4">Waktu</th>
                                <th class="px-6 py-4">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($nilai_siswa && $nilai_siswa->num_rows > 0): ?>
                                <?php 
                                $no = 1;
                                while($r = $nilai_siswa->fetch_assoc()): 
                                    $tab_switch_class = '';
                                    if ($r['tab_switch_count'] > 5) {
                                        $tab_switch_class = 'tab-switch-danger';
                                    } elseif ($r['tab_switch_count'] > 2) {
                                        $tab_switch_class = 'tab-switch-warning';
                                    }
                                ?>
                                    <tr class="border-t border-gray-100 hover:bg-gray-50 transition <?= $tab_switch_class ?>">
                                        <td class="px-6 py-4"><?= $no++ ?></td>
                                        <td class="px-6 py-4 font-mono text-sm"><?= htmlspecialchars($r['nis'] ?? '-') ?></td>
                                        <td class="px-6 py-4 font-medium" style="color: var(--primary-1);"><?= htmlspecialchars($r['nama_siswa'] ?? '-') ?></td>
                                        <td class="px-6 py-4"><?= ($r['jenis_kelamin'] ?? '') == 'L' ? 'Laki-laki' : 'Perempuan' ?></td>
                                        <td class="px-6 py-4 text-center">
                                            <div onclick="openEditModal(<?= $r['siswa_id'] ?>, '<?= htmlspecialchars($r['nama_siswa']) ?>', <?= $r['nilai'] ?? 0 ?>, '<?= htmlspecialchars($r['catatan_guru'] ?? '') ?>')" 
                                                 class="nilai-cell inline-block px-4 py-2 rounded-xl font-bold text-lg transition <?= ($r['nilai'] ?? 0) >= 75 ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-600 hover:bg-red-200' ?>">
                                                <?= $r['nilai'] ?? '-' ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php if (($r['status'] ?? '') == 'selesai'): ?>
                                                <span class="badge-success px-3 py-1 rounded-full text-xs font-semibold inline-flex items-center gap-1">
                                                    <i class="fas fa-check-circle"></i> Selesai
                                                </span>
                                            <?php else: ?>
                                                <span class="badge-sedang px-3 py-1 rounded-full text-xs font-semibold inline-flex items-center gap-1">
                                                    <i class="fas fa-spinner fa-pulse"></i> Sedang
                                                </span>
                                            <?php endif; ?>
                                         </td>
                                        <td class="px-6 py-4 text-center">
                                            <?php if ($r['tab_switch_count'] > 0): ?>
                                                <div class="flex flex-col items-center">
                                                    <span class="font-bold <?= $r['tab_switch_count'] > 5 ? 'text-red-600' : ($r['tab_switch_count'] > 2 ? 'text-orange-500' : 'text-gray-600') ?>">
                                                        <?= $r['tab_switch_count'] ?>x
                                                    </span>
                                                    <?php if ($r['tab_switch_count'] > 3): ?>
                                                        <span class="text-xs text-red-500">⚠️ Curang</span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-gray-400 text-sm">-</span>
                                            <?php endif; ?>
                                         </td>
                                        <td class="px-6 py-4 text-sm">
                                            <?= $r['waktu_selesai'] ? date('d/m/Y H:i', strtotime($r['waktu_selesai'])) : '-' ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="flex gap-2">
                                                <button onclick="openEditModal(<?= $r['siswa_id'] ?>, '<?= htmlspecialchars($r['nama_siswa']) ?>', <?= $r['nilai'] ?? 0 ?>, '<?= htmlspecialchars($r['catatan_guru'] ?? '') ?>')" 
                                                        class="px-3 py-1.5 rounded-lg text-sm font-semibold transition flex items-center gap-1" 
                                                        style="background: var(--neutral-2); color: var(--primary-1);">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <a href="?action=delete&delete_id=<?= $r['id'] ?>&ujian_id=<?= $ujian_id ?>&kelas_id=<?= $kelas_id ?>&mapel_id=<?= $mapel_id ?>" 
                                                   onclick="return confirm('Yakin ingin menghapus nilai <?= htmlspecialchars($r['nama_siswa']) ?>?')"
                                                   class="px-3 py-1.5 rounded-lg text-sm font-semibold transition flex items-center gap-1 bg-red-100 text-red-600 hover:bg-red-200">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                         </td>
                                     </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="px-6 py-12 text-center text-gray-400">
                                        <i class="fas fa-inbox text-4xl mb-2 block"></i>
                                        Belum ada siswa yang mengerjakan ujian ini
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        <?php elseif ($ujian_id > 0 && !$detail_ujian): ?>
            <div class="card p-12 text-center">
                <i class="fas fa-exclamation-triangle text-5xl mb-4" style="color: var(--danger);"></i>
                <p class="text-gray-600">Ujian tidak ditemukan!</p>
            </div>
        <?php endif; ?>

    </div>
</div>

<!-- MODAL EDIT NILAI -->
<div id="editModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 transform transition-all modal-content">
        <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
            <h3 class="text-xl font-semibold" style="color: var(--primary-1);">
                <i class="fas fa-edit mr-2"></i> Edit Nilai Siswa
            </h3>
            <button onclick="closeEditModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        
        <form method="POST" class="p-6">
            <input type="hidden" name="ujian_id" value="<?= $ujian_id ?>">
            <input type="hidden" name="siswa_id" id="edit_siswa_id">
            
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Nama Siswa</label>
                <p id="edit_siswa_nama" class="text-gray-800 font-semibold bg-gray-50 px-4 py-2.5 rounded-xl"></p>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Nilai (0-100)</label>
                <input type="number" name="nilai" id="edit_nilai" min="0" max="100" step="0.5" required
                       class="filter-input w-full px-4 py-2.5 rounded-xl">
            </div>
            
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">Catatan (Opsional)</label>
                <textarea name="catatan" id="edit_catatan" rows="3" 
                          class="filter-input w-full px-4 py-2.5 rounded-xl resize-none"
                          placeholder="Tambahkan catatan untuk siswa..."></textarea>
            </div>
            
            <div class="flex gap-3">
                <button type="submit" name="update_nilai" class="btn-primary px-6 py-2.5 rounded-xl flex-1 font-semibold">
                    <i class="fas fa-save mr-2"></i> Simpan Perubahan
                </button>
                <button type="button" onclick="closeEditModal()" class="btn-secondary px-6 py-2.5 rounded-xl font-semibold">
                    Batal
                </button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL TAMBAH NILAI -->
<div id="tambahModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 transform transition-all modal-content">
        <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
            <h3 class="text-xl font-semibold" style="color: var(--primary-1);">
                <i class="fas fa-plus mr-2"></i> Tambah Nilai Siswa
            </h3>
            <button onclick="closeTambahModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        
        <form method="POST" class="p-6">
            <input type="hidden" name="ujian_id" value="<?= $ujian_id ?>">
            
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Pilih Siswa</label>
                <select name="siswa_id" required class="filter-select w-full px-4 py-2.5">
                    <option value="">-- Pilih Siswa --</option>
                    <?php foreach($siswa_list as $siswa): ?>
                        <option value="<?= $siswa['id_user'] ?>">
                            <?= htmlspecialchars($siswa['nis']) ?> - <?= htmlspecialchars($siswa['nama_lengkap']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($siswa_list)): ?>
                    <p class="text-xs text-gray-400 mt-1">Semua siswa sudah memiliki nilai</p>
                <?php endif; ?>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Nilai (0-100)</label>
                <input type="number" name="nilai" min="0" max="100" step="0.5" required
                       class="filter-input w-full px-4 py-2.5 rounded-xl">
            </div>
            
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">Catatan (Opsional)</label>
                <textarea name="catatan" rows="3" 
                          class="filter-input w-full px-4 py-2.5 rounded-xl resize-none"
                          placeholder="Tambahkan catatan untuk siswa..."></textarea>
            </div>
            
            <div class="flex gap-3">
                <button type="submit" name="tambah_nilai" class="btn-success px-6 py-2.5 rounded-xl flex-1 font-semibold">
                    <i class="fas fa-save mr-2"></i> Tambah Nilai
                </button>
                <button type="button" onclick="closeTambahModal()" class="btn-secondary px-6 py-2.5 rounded-xl font-semibold">
                    Batal
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(siswaId, siswaNama, nilai, catatan) {
    document.getElementById('edit_siswa_id').value = siswaId;
    document.getElementById('edit_siswa_nama').innerText = siswaNama;
    document.getElementById('edit_nilai').value = nilai;
    document.getElementById('edit_catatan').value = catatan || '';
    document.getElementById('editModal').classList.remove('hidden');
    document.getElementById('editModal').classList.add('flex');
}

function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
    document.getElementById('editModal').classList.remove('flex');
}

function openTambahModal() {
    document.getElementById('tambahModal').classList.remove('hidden');
    document.getElementById('tambahModal').classList.add('flex');
}

function closeTambahModal() {
    document.getElementById('tambahModal').classList.add('hidden');
    document.getElementById('tambahModal').classList.remove('flex');
}

// Tutup modal klik di luar
document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) closeEditModal();
});
document.getElementById('tambahModal').addEventListener('click', function(e) {
    if (e.target === this) closeTambahModal();
});

// Auto submit filter ketika mapel berubah
document.getElementById('mapelSelect').addEventListener('change', function() {
    document.getElementById('filterForm').submit();
});
</script>

</body>
</html>