<?php
session_start();

// Cek login
if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'siswa') {
    header("Location: ../../index.php");
    exit;
}

date_default_timezone_set('Asia/Jakarta');

// Koneksi database
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'db_ujian_sekolah';

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Ambil data siswa dari tb_users
$id_siswa = $_SESSION['id_user'];
$query_siswa = "SELECT * FROM tb_users WHERE id_user = '$id_siswa' AND role = 'siswa'";
$result_siswa = mysqli_query($conn, $query_siswa);
$siswa = mysqli_fetch_assoc($result_siswa);

$nama = $siswa['nama_lengkap'];
$nis = $siswa['nis'];
$id_kelas = $siswa['id_kelas'];

// Ambil nama kelas
$query_kelas = "SELECT nama_kelas FROM tb_kelas WHERE id_kelas = '$id_kelas'";
$result_kelas = mysqli_query($conn, $query_kelas);
$kelas_data = mysqli_fetch_assoc($result_kelas);
$kelas = $kelas_data['nama_kelas'] ?? '-';

/* ===============================
   DATA DASHBOARD DARI DATABASE
=================================*/

// Total ujian untuk kelas siswa
$query_total = "SELECT COUNT(DISTINCT u.id_ujian) as total 
                FROM tb_ujian u 
                JOIN tb_ujian_kelas uk ON u.id_ujian = uk.id_ujian 
                WHERE uk.id_kelas = '$id_kelas' 
                AND u.status_ujian = 'aktif'";
$result_total = mysqli_query($conn, $query_total);
$total_ujian = mysqli_fetch_assoc($result_total)['total'] ?? 0;

// Ujian yang sudah dikerjakan (selesai)
$query_selesai = "SELECT COUNT(DISTINCT id_ujian) as selesai 
                  FROM tb_nilai 
                  WHERE id_siswa = '$id_siswa' 
                  AND status_pengerjaan = 'selesai'";
$result_selesai = mysqli_query($conn, $query_selesai);
$selesai_ujian = mysqli_fetch_assoc($result_selesai)['selesai'] ?? 0;

// Ujian yang belum dikerjakan
$belum_ujian = $total_ujian - $selesai_ujian;

// Ujian hari ini
$tanggal_hari_ini = date('Y-m-d');
$query_hari_ini = "SELECT COUNT(*) as hari_ini 
                   FROM tb_ujian u
                   JOIN tb_ujian_kelas uk ON u.id_ujian = uk.id_ujian
                   WHERE uk.id_kelas = '$id_kelas' 
                   AND u.tanggal_ujian = '$tanggal_hari_ini'
                   AND u.status_ujian = 'aktif'";
$result_hari_ini = mysqli_query($conn, $query_hari_ini);
$jadwal_hari = mysqli_fetch_assoc($result_hari_ini)['hari_ini'] ?? 0;

// Ambil jadwal ujian terdekat
$query_jadwal = "SELECT u.*, m.nama_mapel
                 FROM tb_ujian u
                 JOIN tb_ujian_kelas uk ON u.id_ujian = uk.id_ujian
                 JOIN tb_mapel m ON u.id_mapel = m.id_mapel
                 WHERE uk.id_kelas = '$id_kelas' 
                 AND u.status_ujian = 'aktif'
                 AND u.tanggal_ujian >= '$tanggal_hari_ini'
                 ORDER BY u.tanggal_ujian ASC, u.jam_mulai ASC
                 LIMIT 5";
$result_jadwal = mysqli_query($conn, $query_jadwal);
$jadwal_ujian = [];
while ($row = mysqli_fetch_assoc($result_jadwal)) {
    $jadwal_ujian[] = $row;
}

// Ambil data kartu ujian
$query_kartu = "SELECT * FROM tb_kartu_ujian WHERE nis = '$nis'";
$result_kartu = mysqli_query($conn, $query_kartu);
$kartu = mysqli_fetch_assoc($result_kartu);

// Ambil semua tanggal ujian untuk kalender
$query_tanggal = "SELECT DISTINCT u.tanggal_ujian as tanggal 
                  FROM tb_ujian u
                  JOIN tb_ujian_kelas uk ON u.id_ujian = uk.id_ujian
                  WHERE uk.id_kelas = '$id_kelas'
                  AND u.status_ujian = 'aktif'";
$result_tanggal = mysqli_query($conn, $query_tanggal);
$tanggal_ujian_list = [];
while ($row = mysqli_fetch_assoc($result_tanggal)) {
    $tanggal_ujian_list[] = $row['tanggal'];
}

$logo_path = '/cbt_sekolah/assets/img/soal/logo_sekolah.png';

// Cek apakah file logo ada
// Pakai __DIR__ agar path selalu relatif dari lokasi file ini
$logo_full_path = __DIR__ . '/../../assets/img/logo_sekolah.png';

if (file_exists($logo_full_path)) {
    $logo_path = '/Aplikasi%20CBT%20Sekolah/cbt_sekolah/assets/img/logo_sekolah.png';
} else {
    $logo_path = 'https://placehold.co/55x55/2B3A67/white?text=SMK';
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard CBT - <?= htmlspecialchars($nama) ?></title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --primary-1: #2B3A67;
    --primary-2: #496A81;
    --secondary-1: #66999B;
    --secondary-2: #B3AF8F;
    --accent-1: #FFC482;
    --accent-2: #DDB7AB;
    --neutral-1: #F8F4E9;
    --neutral-2: #E8E1D3;
    --dark: #2E3B4E;
    --success: #77BFA3;
    --warning: #FFB347;
    --danger: #E58C7C;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    background: linear-gradient(135deg, var(--neutral-1) 0%, var(--neutral-2) 100%);
    display: flex;
    min-height: 100vh;
}

/* SIDEBAR */
.sidebar {
    width: 280px;
    background: linear-gradient(135deg, var(--primary-1) 0%, var(--primary-2) 100%);
    color: white;
    padding: 25px 20px;
    position: fixed;
    height: 100vh;
    top: 0;
    left: 0;
    overflow-y: auto;
    z-index: 100;
    box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
}

.sidebar::-webkit-scrollbar {
    width: 5px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
}

.logo {
    text-align: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 2px solid rgba(255, 255, 255, 0.2);
}

.logo h2 {
    font-size: 24px;
    font-weight: 700;
    background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.logo h4 {
    font-size: 14px;
    margin-top: 5px;
    opacity: 0.9;
}

.logo p {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.7);
}

.user-profile {
    text-align: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 2px solid rgba(255, 255, 255, 0.2);
}

.user-profile h5 {
    font-size: 16px;
    margin-bottom: 5px;
    font-weight: 600;
}

.user-profile p {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.8);
}

.sidebar a {
    display: flex;
    align-items: center;
    gap: 12px;
    text-decoration: none;
    color: rgba(255, 255, 255, 0.8);
    padding: 12px 15px;
    border-radius: 12px;
    margin-bottom: 8px;
    transition: all 0.3s ease;
    font-size: 14px;
    font-weight: 500;
}

.sidebar a:hover,
.sidebar a.active {
    background: rgba(255, 255, 255, 0.15);
    color: white;
    transform: translateX(5px);
}

.sidebar a i {
    width: 22px;
    text-align: center;
    font-size: 16px;
}

.sidebar a.text-danger:hover {
    background: var(--danger);
    color: white;
}

/* MAIN */
.main {
    margin-left: 280px;
    width: calc(100% - 280px);
    padding: 25px 35px;
    min-height: 100vh;
}

/* TOPBAR */
.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
    gap: 15px;
}

.topbar-left {
    display: flex;
    align-items: center;
    gap: 20px;
}

.school-logo {
    width: 55px;
    height: 55px;
    object-fit: contain;
    background: white;
    border-radius: 12px;
    padding: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.topbar h1 {
    font-size: 28px;
    font-weight: 700;
    background: linear-gradient(135deg, var(--primary-1), var(--primary-2));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.time-box {
    background: white;
    padding: 12px 24px;
    border-radius: 30px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    font-size: 14px;
    font-weight: 600;
    text-align: right;
    color: var(--primary-1);
}

/* WELCOME */
.welcome {
    background: linear-gradient(135deg, var(--primary-1) 0%, var(--secondary-1) 100%);
    color: white;
    padding: 30px 35px;
    border-radius: 20px;
    margin-bottom: 30px;
    box-shadow: 0 10px 30px rgba(43, 58, 103, 0.3);
    position: relative;
    overflow: hidden;
}

.welcome::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 300px;
    height: 300px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

.welcome h2 {
    font-size: 26px;
    margin-bottom: 10px;
    font-weight: 700;
}

.welcome p {
    font-size: 14px;
    opacity: 0.95;
}

/* STATISTIK */
.stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 25px;
    margin-bottom: 35px;
}

.card {
    background: white;
    border-radius: 20px;
    padding: 22px;
    display: flex;
    align-items: center;
    gap: 18px;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(43, 58, 103, 0.15);
}

.icon {
    width: 60px;
    height: 60px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
}

.icon.blue {
    background: linear-gradient(135deg, var(--primary-1), var(--primary-2));
}
.icon.orange {
    background: linear-gradient(135deg, #FF8C42, var(--warning));
}
.icon.green {
    background: linear-gradient(135deg, var(--success), #5BA08A);
}
.icon.purple {
    background: linear-gradient(135deg, var(--secondary-1), var(--secondary-2));
}

.card h3 {
    font-size: 32px;
    color: var(--dark);
    font-weight: 700;
    line-height: 1.2;
}

.card p {
    font-size: 13px;
    color: #64748b;
    font-weight: 500;
}

/* GRID */
.grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
}

.box,
.calendar {
    background: white;
    border-radius: 20px;
    padding: 25px;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
}

.box:hover,
.calendar:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 35px rgba(43, 58, 103, 0.1);
}

.box h3,
.calendar h3 {
    margin-bottom: 20px;
    color: var(--primary-1);
    font-size: 18px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 10px;
}

.box h3 i,
.calendar h3 i {
    color: var(--secondary-1);
}

/* Jadwal styles */
.jadwal-list {
    list-style: none;
    padding: 0;
}

.jadwal-list li {
    padding: 14px 0;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: all 0.2s ease;
}

.jadwal-list li:hover {
    background: var(--neutral-1);
    padding-left: 10px;
    border-radius: 8px;
}

.jadwal-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.jadwal-mapel {
    font-weight: 700;
    color: var(--dark);
    font-size: 14px;
}

.jadwal-tanggal {
    font-size: 12px;
    color: #64748b;
}

.jadwal-waktu {
    font-size: 12px;
    color: var(--primary-2);
    font-weight: 600;
}

.jadwal-status {
    background: linear-gradient(135deg, var(--success), #5BA08A);
    color: white;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

/* CALENDAR */
.calendar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.calendar-header button {
    border: none;
    background: linear-gradient(135deg, var(--primary-1), var(--primary-2));
    color: white;
    width: 34px;
    height: 34px;
    border-radius: 10px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.2s ease;
}

.calendar-header button:hover {
    transform: scale(1.05);
    box-shadow: 0 2px 8px rgba(43, 58, 103, 0.3);
}

.calendar-header h3 {
    font-size: 16px;
    margin: 0;
}

.calendar-days,
.calendar-dates {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    text-align: center;
    gap: 8px;
}

.calendar-days div {
    font-size: 12px;
    font-weight: 700;
    color: var(--primary-2);
    padding: 8px 0;
}

.calendar-dates div {
    padding: 10px 0;
    border-radius: 10px;
    font-size: 13px;
    cursor: pointer;
    transition: all 0.2s ease;
    font-weight: 500;
}

.calendar-dates div:hover:not(.empty) {
    background: var(--neutral-2);
    transform: scale(1.05);
}

.today {
    background: linear-gradient(135deg, var(--success), #5BA08A) !important;
    color: white;
    font-weight: 700;
}

.has-ujian {
    background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
    color: var(--dark);
    font-weight: 600;
    position: relative;
}

.empty {
    cursor: default;
}

/* FOOTER */
.footer {
    margin-top: 40px;
    text-align: center;
    color: #94a3b8;
    font-size: 12px;
    padding: 20px;
    border-top: 1px solid var(--neutral-2);
}

/* RESPONSIVE */
@media (max-width: 1024px) {
    .grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-280px);
        transition: 0.3s;
    }

    .sidebar.open {
        transform: translateX(0);
    }

    .main {
        margin-left: 0;
        width: 100%;
        padding: 20px;
    }

    .stats {
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
    }

    .topbar {
        flex-direction: column;
        align-items: flex-start;
    }

    .topbar-left {
        width: 100%;
        justify-content: space-between;
    }

    .welcome h2 {
        font-size: 20px;
    }

    .card h3 {
        font-size: 24px;
    }

    .menu-toggle {
        display: block;
        position: fixed;
        top: 20px;
        left: 20px;
        z-index: 1001;
        background: linear-gradient(135deg, var(--primary-1), var(--primary-2));
        color: white;
        width: 42px;
        height: 42px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
}

@media (min-width: 769px) {
    .menu-toggle {
        display: none;
    }
}

@media (max-width: 480px) {
    .stats {
        grid-template-columns: 1fr;
    }

    .topbar-left {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>
</head>
<body>

<!-- Menu Toggle untuk Mobile -->
<div class="menu-toggle" onclick="toggleSidebar()">
    <i class="fas fa-bars"></i>
</div>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <h2>CBT </h2>
        <h3>(Computer Based Test)</h3>
        <h4>SMK N 8 BANDAR LAMPUNG</h4>
        <p>Sistem Ujian Online</p>
    </div>

    <div class="user-profile">
        <h5><?= htmlspecialchars($nama) ?></h5>
        <p>NIS: <?= htmlspecialchars($nis) ?></p>
    </div>

    <a href="dashboard.php" class="active">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </a>
    <a href="tatatertib.php">
        <i class="fas fa-gavel"></i> Tata Tertib
    </a>
    <a href="kartu_ujian.php">
        <i class="fas fa-id-card"></i> Kartu Ujian
    </a>
    <a href="absensi.php">
        <i class="fas fa-check-circle"></i> Absensi
    </a>
    <a href="ujian.php">
        <i class="fas fa-pen"></i> Ujian
    </a>
    <a href="javascript:void(0)" onclick="confirmLogout()" style="color: var(--danger);">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
</div>

<!-- MAIN -->
<div class="main">
    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <img src="<?= $logo_path ?>" 
                 alt="Logo SMK N 8 Bandar Lampung" 
                 class="school-logo">
            <h1>Dashboard Siswa</h1>
        </div>
        <div class="time-box" id="jam"></div>
    </div>

    <!-- WELCOME -->
    <div class="welcome">
        <h2>Selamat Datang, <?= htmlspecialchars($nama) ?> 👋</h2>
        <p>Kelas: <b><?= htmlspecialchars($kelas) ?></b> | NIS: <?= htmlspecialchars($nis) ?></p>
    </div>

    <!-- STATISTIK -->
    <div class="stats">
        <div class="card">
            <div class="icon blue">
                <i class="fas fa-book"></i>
            </div>
            <div>
                <h3><?= $total_ujian ?></h3>
                <p>Total Ujian</p>
            </div>
        </div>

        <div class="card">
            <div class="icon orange">
                <i class="fas fa-clock"></i>
            </div>
            <div>
                <h3><?= $belum_ujian ?></h3>
                <p>Belum Dikerjakan</p>
            </div>
        </div>

        <div class="card">
            <div class="icon green">
                <i class="fas fa-check-double"></i>
            </div>
            <div>
                <h3><?= $selesai_ujian ?></h3>
                <p>Selesai</p>
            </div>
        </div>

        <div class="card">
            <div class="icon purple">
                <i class="fas fa-calendar-day"></i>
            </div>
            <div>
                <h3><?= $jadwal_hari ?></h3>
                <p>Ujian Hari Ini</p>
            </div>
        </div>
    </div>

    <!-- GRID -->
    <div class="grid">
        <!-- JADWAL UJIAN TERDEKAT -->
        <div class="box">
            <h3><i class="fas fa-calendar-alt"></i> Jadwal Ujian Terdekat</h3>
            <?php if (count($jadwal_ujian) > 0): ?>
                <ul class="jadwal-list">
                    <?php foreach ($jadwal_ujian as $jadwal): ?>
                        <li>
                            <div class="jadwal-info">
                                <span class="jadwal-mapel"><?= htmlspecialchars($jadwal['nama_mapel']) ?></span>
                                <span class="jadwal-tanggal">
                                    <?= date('d/m/Y', strtotime($jadwal['tanggal_ujian'])) ?>
                                </span>
                                <span class="jadwal-waktu">
                                    <?= date('H:i', strtotime($jadwal['jam_mulai'])) ?> - 
                                    <?= date('H:i', strtotime($jadwal['jam_selesai'])) ?>
                                </span>
                            </div>
                            <?php if ($jadwal['tanggal_ujian'] == $tanggal_hari_ini): ?>
                                <span class="jadwal-status">Hari Ini</span>
                            <?php else: ?>
                                <span class="jadwal-status" style="background: linear-gradient(135deg, #64748b, #475569);"><?= $jadwal['durasi_menit'] ?? '90' ?> Menit</span>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p style="color:#64748b; text-align:center; padding:20px;">Tidak ada jadwal ujian.</p>
            <?php endif; ?>
        </div>

        <!-- KALENDER -->
        <div class="calendar">
            <div class="calendar-header">
                <button onclick="prevMonth()">&#10094;</button>
                <h3 id="monthYear"></h3>
                <button onclick="nextMonth()">&#10095;</button>
            </div>
            <div class="calendar-days">
                <div>Min</div>
                <div>Sen</div>
                <div>Sel</div>
                <div>Rab</div>
                <div>Kam</div>
                <div>Jum</div>
                <div>Sab</div>
            </div>
            <div class="calendar-dates" id="calendarDates"></div>
        </div>
    </div>

    <div class="footer">
        &copy; <?= date('Y') ?> CIDIKNA_SMKN8BNDARLAMPUNG
    </div>
</div>

<script>
// Fungsi toggle sidebar untuk mobile
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

// Konfirmasi logout
function confirmLogout() {
    if (confirm('Apakah Anda yakin ingin keluar dari sistem?')) {
        window.location.href = '../../logout.php';
    }
}

// Jam digital
function updateClock() {
    let now = new Date();
    let jam = now.getHours().toString().padStart(2, '0');
    let menit = now.getMinutes().toString().padStart(2, '0');
    let detik = now.getSeconds().toString().padStart(2, '0');

    document.getElementById("jam").innerHTML = jam + ":" + menit + ":" + detik + " WIB";
}

setInterval(updateClock, 1000);
updateClock();

// Kalender
let currentDate = new Date();
let jadwalUjian = <?= json_encode($tanggal_ujian_list) ?>;

function renderCalendar(date) {
    const monthYear = document.getElementById("monthYear");
    const calendarDates = document.getElementById("calendarDates");

    const year = date.getFullYear();
    const month = date.getMonth();

    const firstDay = new Date(year, month, 1).getDay();
    const lastDate = new Date(year, month + 1, 0).getDate();

    const months = ["JANUARI", "FEBRUARI", "MARET", "APRIL", "MEI", "JUNI", "JULI", "AGUSTUS", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DESEMBER"];

    monthYear.innerHTML = months[month] + " " + year;
    calendarDates.innerHTML = "";

    for (let i = 0; i < firstDay; i++) {
        calendarDates.innerHTML += "<div class='empty'></div>";
    }

    let today = new Date();
    let todayDate = today.getDate();
    let todayMonth = today.getMonth();
    let todayYear = today.getFullYear();

    for (let i = 1; i <= lastDate; i++) {
        let isToday = (i === todayDate && month === todayMonth && year === todayYear);
        let dateStr = year + "-" + String(month + 1).padStart(2, '0') + "-" + String(i).padStart(2, '0');
        let hasUjian = jadwalUjian.includes(dateStr);

        let classes = [];
        if (isToday) classes.push('today');
        if (hasUjian && !isToday) classes.push('has-ujian');

        calendarDates.innerHTML += `<div class="${classes.join(' ')}">${i}</div>`;
    }
}

function prevMonth() {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar(currentDate);
}

function nextMonth() {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar(currentDate);
}

renderCalendar(currentDate);

// Close sidebar saat klik di luar (mobile)
document.addEventListener('click', function(event) {
    const sidebar = document.getElementById('sidebar');
    const menuToggle = document.querySelector('.menu-toggle');

    if (window.innerWidth <= 768) {
        if (!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
            sidebar.classList.remove('open');
        }
    }
});
</script>

</body>
</html>