<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../../index.php"); exit;
}
require_once '../../config/koneksi.php';

$id_guru = $_SESSION['id_user'];

// Ambil data hasil ujian siswa yang mengikuti ujian milik guru ini
$query = "
    SELECT h.*, u.nama_lengkap, k.nama_kelas, uj.nama_ujian
    FROM tb_hasil_ujian h
    JOIN tb_users u ON h.id_user = u.id_user
    JOIN tb_kelas k ON u.id_kelas = k.id_kelas
    JOIN ujian uj ON h.id_ujian = uj.id
    WHERE uj.guru_id = ?
    ORDER BY h.waktu_selesai DESC
";
$stmt = $pdo->prepare($query);
$stmt->execute([$id_guru]);
$daftar_nilai = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Daftar Nilai Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-50 p-8">
    <div class="max-w-6xl mx-auto">
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-slate-800">Daftar Nilai Ujian</h1>
            <p class="text-slate-500">Pantau hasil pengerjaan siswa secara real-time</p>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 border-b">
                    <tr>
                        <th class="p-4 font-bold text-slate-700">Siswa</th>
                        <th class="p-4 font-bold text-slate-700">Ujian</th>
                        <th class="p-4 font-bold text-slate-700 text-center">Benar</th>
                        <th class="p-4 font-bold text-slate-700 text-center">Salah</th>
                        <th class="p-4 font-bold text-slate-700 text-center">Nilai</th>
                        <th class="p-4 font-bold text-slate-700">Waktu Selesai</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php if (count($daftar_nilai) > 0): ?>
                        <?php foreach ($daftar_nilai as $n): ?>
                            <tr class="hover:bg-slate-50 transition">
                                <td class="p-4">
                                    <div class="font-bold text-slate-800"><?= htmlspecialchars($n['nama_lengkap']) ?></div>
                                    <div class="text-xs text-blue-500 font-semibold"><?= htmlspecialchars($n['nama_kelas']) ?></div>
                                </td>
                                <td class="p-4 text-sm font-medium"><?= htmlspecialchars($n['nama_ujian']) ?></td>
                                <td class="p-4 text-center text-green-600 font-bold"><?= $n['jml_benar'] ?></td>
                                <td class="p-4 text-center text-red-500 font-bold"><?= $n['jml_salah'] ?></td>
                                <td class="p-4 text-center">
                                    <span class="px-3 py-1 rounded-full text-sm font-black <?= $n['nilai'] >= 75 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                                        <?= round($n['nilai'], 0) ?>
                                    </span>
                                </td>
                                <td class="p-4 text-xs text-slate-400">
                                    <?= date('d/m/Y H:i', strtotime($n['waktu_selesai'])) ?> WIB
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="p-10 text-center text-slate-400">Belum ada siswa yang menyelesaikan ujian.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>