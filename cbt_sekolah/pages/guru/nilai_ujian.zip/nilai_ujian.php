<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../../index.php"); exit;
}

$conn = new mysqli("localhost", "root", "", "db_ujian_sekolah");
if ($conn->connect_error) die("Koneksi gagal: " . $conn->connect_error);
$conn->set_charset("utf8");

$guru_id   = $_SESSION['id_user'] ?? 0;
$nama_guru = $_SESSION['nama_lengkap'] ?? $_SESSION['nama'] ?? 'Guru';
$ujian_id  = isset($_GET['ujian_id']) ? (int)$_GET['ujian_id'] : 0;
$siswa_id  = isset($_GET['siswa_id']) ? (int)$_GET['siswa_id'] : 0;

// List ujian milik guru
$ujian_list = $conn->query("SELECT id, nama_ujian FROM ujian WHERE guru_id=$guru_id ORDER BY created_at DESC");

// ── SIMPAN NILAI ESSAY (input manual guru) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan_nilai'])) {
    $u_id       = (int)$_POST['ujian_id'];
    $s_id       = (int)$_POST['siswa_id'];
    $nilai_essay = (float)$_POST['nilai_essay'];

    if ($nilai_essay < 0 || $nilai_essay > 100) {
        $_SESSION['flash'] = ['type'=>'danger','msg'=>'Nilai essay harus antara 0 - 100.'];
    } else {
        $cek = $conn->query("SELECT id_nilai FROM tb_nilai WHERE id_ujian=$u_id AND id_siswa=$s_id");
        if ($cek && $cek->num_rows > 0) {
            $conn->query("UPDATE tb_nilai SET nilai_essay=$nilai_essay WHERE id_ujian=$u_id AND id_siswa=$s_id");
        }
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Nilai essay berhasil disimpan.'];
    }
    header("Location: nilai_ujian.php?ujian_id=$u_id"); exit;
}

// ── LOAD DATA NILAI ──
$nilai_siswa  = null;
$detail_ujian = null;
$summary      = ['total'=>0,'selesai'=>0,'belum'=>0,'rata'=>0];

if ($ujian_id > 0) {
    $q = $conn->query("SELECT * FROM ujian WHERE id=$ujian_id AND guru_id=$guru_id");
    if ($q && $q->num_rows > 0) {
        $detail_ujian = $q->fetch_assoc();
        $nama_kelas   = $conn->real_escape_string($detail_ujian['kelas'] ?? '');

        if ($nama_kelas) {
            $nilai_siswa = $conn->query("
                SELECT
                    u.id_user           AS id,
                    u.nama_lengkap      AS nama,
                    u.nis,
                    k.nama_kelas        AS kelas,
                    n.status_pengerjaan,
                    n.jml_benar,
                    n.jml_salah,
                    n.nilai_pg,
                    n.nilai_essay,
                    n.total_nilai,
                    n.waktu_mulai,
                    n.waktu_selesai
                FROM tb_users u
                LEFT JOIN tb_kelas k ON k.id_kelas = u.id_kelas
                LEFT JOIN tb_nilai n ON n.id_siswa  = u.id_user
                                    AND n.id_ujian  = $ujian_id
                WHERE u.role = 'siswa'
                  AND k.nama_kelas = '$nama_kelas'
                ORDER BY u.nama_lengkap ASC
            ");
        } else {
            $nilai_siswa = $conn->query("
                SELECT
                    u.id_user           AS id,
                    u.nama_lengkap      AS nama,
                    u.nis,
                    k.nama_kelas        AS kelas,
                    n.status_pengerjaan,
                    n.jml_benar,
                    n.jml_salah,
                    n.nilai_pg,
                    n.nilai_essay,
                    n.total_nilai,
                    n.waktu_mulai,
                    n.waktu_selesai
                FROM tb_nilai n
                JOIN tb_users u ON u.id_user = n.id_siswa
                LEFT JOIN tb_kelas k ON k.id_kelas = u.id_kelas
                WHERE n.id_ujian = $ujian_id
                ORDER BY u.nama_lengkap ASC
            ");
        }

        // Hitung summary
        if ($nilai_siswa) {
            $all_rows = $nilai_siswa->fetch_all(MYSQLI_ASSOC);
            $nilai_siswa = null; // akan kita loop dari $all_rows

            $total_nilai_sum = 0;
            $count_selesai   = 0;
            foreach ($all_rows as $r) {
                $summary['total']++;
                if ($r['status_pengerjaan'] === 'selesai') {
                    $summary['selesai']++;
                    if ($r['total_nilai'] !== null) {
                        $total_nilai_sum += $r['total_nilai'];
                        $count_selesai++;
                    }
                } else {
                    $summary['belum']++;
                }
            }
            $summary['rata'] = $count_selesai > 0 ? round($total_nilai_sum / $count_selesai, 1) : 0;
        }
    }
}

// ── DETAIL SISWA untuk form input essay ──
$detail_siswa = null;
if ($ujian_id && $siswa_id) {
    $q = $conn->query("
        SELECT u.id_user AS id, u.nama_lengkap AS nama, u.nis,
               n.nilai_essay, n.total_nilai, n.jml_benar, n.jml_salah, n.status_pengerjaan
        FROM tb_users u
        LEFT JOIN tb_nilai n ON n.id_siswa = u.id_user AND n.id_ujian = $ujian_id
        WHERE u.id_user = $siswa_id LIMIT 1
    ");
    if ($q && $q->num_rows > 0) $detail_siswa = $q->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Nilai Ujian – CBT Sekolah</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
        * { font-family:'Inter',sans-serif; }
        .gradient-bg { background:linear-gradient(135deg,#0A192F 0%,#1E3A5F 30%,#F4A261 60%,#90BE6D 100%); background-size:200% 200%; animation:gm 10s ease infinite; }
        @keyframes gm { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        .btn-gradient { background:linear-gradient(135deg,#0A192F,#1E3A5F,#F4A261,#90BE6D); background-size:300% 300%; animation:bg 5s ease infinite; }
        @keyframes bg { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        tr:hover td { background:#f9fafb; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">

<header class="gradient-bg shadow-lg py-4 px-6 flex justify-between items-center sticky top-0 z-40">
    <div class="flex items-center space-x-3">
        <a href="dashboard.php" class="text-white/70 hover:text-white mr-1"><i class="fas fa-arrow-left"></i></a>
        <i class="fas fa-star text-white text-xl"></i>
        <div>
            <h1 class="text-xl font-bold text-white">Nilai Ujian</h1>
            <p class="text-white/60 text-xs">Rekap nilai dan input nilai essay</p>
        </div>
    </div>
    <div class="flex items-center gap-3">
        <a href="dashboard.php" class="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-xl text-sm font-semibold transition border border-white/30">
            <i class="fas fa-home mr-1"></i> Dashboard
        </a>
        <div class="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center border-2 border-white/50">
            <span class="text-white font-bold"><?= strtoupper(substr($nama_guru,0,1)) ?></span>
        </div>
    </div>
</header>

<main class="p-6 max-w-7xl mx-auto">

    <?php if (isset($_SESSION['flash'])): ?>
    <div class="mb-4 p-4 rounded-xl <?= $_SESSION['flash']['type']==='success'?'bg-green-100 text-green-800':'bg-red-100 text-red-800' ?>">
        <i class="fas fa-<?= $_SESSION['flash']['type']==='success'?'check':'exclamation' ?>-circle mr-2"></i>
        <?= htmlspecialchars($_SESSION['flash']['msg']) ?>
    </div>
    <?php unset($_SESSION['flash']); endif; ?>

    <!-- Pilih Ujian -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 mb-6">
        <form method="GET">
            <label class="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-wide">Pilih Ujian</label>
            <select name="ujian_id" onchange="this.form.submit()"
                    class="w-full py-2.5 px-3 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#0A192F] outline-none">
                <option value="">-- Pilih Ujian --</option>
                <?php while ($u = $ujian_list->fetch_assoc()): ?>
                <option value="<?= $u['id'] ?>" <?= $ujian_id==$u['id']?'selected':'' ?>>
                    <?= htmlspecialchars($u['nama_ujian']) ?>
                </option>
                <?php endwhile; ?>
            </select>
        </form>
    </div>

    <?php if ($detail_ujian && !empty($all_rows)): ?>

    <!-- Summary cards -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <?php $cards = [
            ['label'=>'Total Siswa',  'val'=>$summary['total'],   'icon'=>'fa-users',       'color'=>'from-[#0A192F] to-[#1E3A5F]'],
            ['label'=>'Sudah Ujian',  'val'=>$summary['selesai'], 'icon'=>'fa-check-circle','color'=>'from-green-400 to-green-500'],
            ['label'=>'Belum Ujian',  'val'=>$summary['belum'],   'icon'=>'fa-hourglass',   'color'=>'from-yellow-400 to-yellow-500'],
            ['label'=>'Rata-rata',    'val'=>$summary['rata'],    'icon'=>'fa-chart-line',  'color'=>'from-[#F4A261] to-orange-400'],
        ];
        foreach ($cards as $c): ?>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl bg-gradient-to-br <?= $c['color'] ?> flex items-center justify-center flex-shrink-0">
                <i class="fas <?= $c['icon'] ?> text-white text-lg"></i>
            </div>
            <div>
                <div class="text-2xl font-black text-gray-800"><?= $c['val'] ?></div>
                <div class="text-xs text-gray-500 font-medium"><?= $c['label'] ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php endif; ?>

    <!-- Form input nilai essay -->
    <?php if ($detail_siswa): ?>
    <div class="bg-white rounded-2xl shadow-sm border-2 border-[#0A192F] p-6 mb-6 max-w-xl">
        <h2 class="text-lg font-bold text-gray-800 mb-1 flex items-center gap-2">
            <i class="fas fa-edit text-[#F4A261]"></i>
            Input Nilai Essay
        </h2>
        <p class="text-sm text-gray-500 mb-4"><?= htmlspecialchars($detail_siswa['nama']) ?></p>

        <!-- Info otomatis -->
        <div class="bg-gray-50 rounded-xl p-4 mb-4 grid grid-cols-3 gap-3 text-center text-sm">
            <div>
                <div class="font-bold text-green-600 text-lg"><?= $detail_siswa['jml_benar'] ?? '-' ?></div>
                <div class="text-gray-500 text-xs">Benar</div>
            </div>
            <div>
                <div class="font-bold text-red-500 text-lg"><?= $detail_siswa['jml_salah'] ?? '-' ?></div>
                <div class="text-gray-500 text-xs">Salah</div>
            </div>
            <div>
                <div class="font-bold text-[#0A192F] text-lg"><?= $detail_siswa['nilai_pg'] ?? '-' ?></div>
                <div class="text-gray-500 text-xs">Nilai PG</div>
            </div>
        </div>

        <form method="POST">
            <input type="hidden" name="ujian_id" value="<?= $ujian_id ?>">
            <input type="hidden" name="siswa_id" value="<?= $siswa_id ?>">
            <div class="mb-4">
                <label class="block text-sm font-semibold text-gray-700 mb-2">Nilai Essay (0 – 100)</label>
                <input type="number" name="nilai_essay" min="0" max="100" step="0.5" required
                       value="<?= htmlspecialchars($detail_siswa['nilai_essay'] ?? '') ?>"
                       class="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#0A192F] outline-none">
            </div>
            <div class="flex gap-3">
                <button type="submit" name="simpan_nilai" class="btn-gradient text-white px-6 py-2.5 rounded-xl font-semibold text-sm flex items-center gap-2">
                    <i class="fas fa-save"></i> Simpan
                </button>
                <a href="nilai_ujian.php?ujian_id=<?= $ujian_id ?>" class="px-6 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-600 hover:bg-gray-50">Batal</a>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <!-- Tabel nilai -->
    <?php if ($detail_ujian && !empty($all_rows)): ?>
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center gap-3">
            <i class="fas fa-table text-[#0A192F]"></i>
            <h3 class="font-bold text-gray-800"><?= htmlspecialchars($detail_ujian['nama_ujian']) ?></h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wide">
                    <tr>
                        <th class="px-4 py-3 text-left">No</th>
                        <th class="px-4 py-3 text-left">NIS</th>
                        <th class="px-4 py-3 text-left">Nama Siswa</th>
                        <th class="px-4 py-3 text-left">Kelas</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Benar</th>
                        <th class="px-4 py-3 text-center">Salah</th>
                        <th class="px-4 py-3 text-center">Nilai PG</th>
                        <th class="px-4 py-3 text-center">Nilai Essay</th>
                        <th class="px-4 py-3 text-center">Total</th>
                        <th class="px-4 py-3 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                <?php $no=1; foreach ($all_rows as $r): ?>
                <tr>
                    <td class="px-4 py-3 text-gray-400"><?= $no++ ?></td>
                    <td class="px-4 py-3 text-gray-600"><?= htmlspecialchars($r['nis']??'-') ?></td>
                    <td class="px-4 py-3 font-semibold text-gray-800"><?= htmlspecialchars($r['nama']) ?></td>
                    <td class="px-4 py-3 text-gray-600"><?= htmlspecialchars($r['kelas']??'-') ?></td>
                    <td class="px-4 py-3">
                        <?php if ($r['status_pengerjaan']==='selesai'): ?>
                        <span class="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-bold">Selesai</span>
                        <?php else: ?>
                        <span class="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs font-bold">Belum</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3 text-center font-semibold text-green-600"><?= $r['jml_benar'] ?? '-' ?></td>
                    <td class="px-4 py-3 text-center font-semibold text-red-500"><?= $r['jml_salah'] ?? '-' ?></td>
                    <td class="px-4 py-3 text-center"><?= $r['nilai_pg'] ?? '-' ?></td>
                    <td class="px-4 py-3 text-center"><?= $r['nilai_essay'] ?? '-' ?></td>
                    <td class="px-4 py-3 text-center">
                        <?php if ($r['total_nilai'] !== null): ?>
                        <span class="font-bold text-base <?= $r['total_nilai']>=75?'text-green-600':'text-red-500' ?>">
                            <?= $r['total_nilai'] ?>
                        </span>
                        <?php else: ?>
                        <span class="text-gray-400">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3">
                        <?php if ($r['status_pengerjaan']==='selesai'): ?>
                        <a href="nilai_ujian.php?ujian_id=<?= $ujian_id ?>&siswa_id=<?= $r['id'] ?>"
                           class="bg-blue-50 hover:bg-blue-100 text-blue-700 px-3 py-1.5 rounded-lg text-xs font-semibold transition">
                            ✏️ Essay
                        </a>
                        <?php else: ?>
                        <span class="text-gray-400 text-xs">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php elseif ($ujian_id && $detail_ujian && empty($all_rows)): ?>
    <div class="bg-white rounded-2xl py-16 text-center border border-gray-100">
        <i class="fas fa-users text-gray-300 text-5xl mb-4"></i>
        <p class="text-gray-500">Belum ada siswa yang mengerjakan ujian ini.</p>
    </div>

    <?php elseif (!$ujian_id): ?>
    <div class="bg-white rounded-2xl py-16 text-center border border-gray-100">
        <i class="fas fa-star text-gray-300 text-5xl mb-4"></i>
        <p class="text-gray-500">Pilih ujian untuk melihat data nilai.</p>
    </div>
    <?php endif; ?>

</main>
</body>
</html>