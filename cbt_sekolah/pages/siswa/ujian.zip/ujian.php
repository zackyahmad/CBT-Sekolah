<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'siswa') {
    header("Location: ../../index.php"); exit;
}
require_once '../../config/koneksi.php';

$id_user = $_SESSION['id_user'];
// Ambil ID Kelas siswa dari session atau database
$stmt_user = $pdo->prepare("SELECT id_kelas, nama_lengkap FROM tb_users WHERE id_user = ?");
$stmt_user->execute([$id_user]);
$user = $stmt_user->fetch();
$id_kelas_siswa = $user['id_kelas'];
$nama_siswa = $user['nama_lengkap'];

// QUERY FINAL: Filter berdasarkan id_kelas di tb_ujian_kelas
$stmt = $pdo->prepare("
    SELECT u.*, m.nama_mapel, h.id_hasil as sudah_kerjakan,
    (SELECT COUNT(*) FROM tb_ujian_soal WHERE id_ujian = u.id_ujian) as jumlah_soal
    FROM tb_ujian u 
    JOIN tb_ujian_kelas uk ON u.id_ujian = uk.id_ujian
    LEFT JOIN tb_mapel m ON u.id_mapel = m.id_mapel
    LEFT JOIN tb_hasil_ujian h ON h.id_ujian = u.id_ujian AND h.id_user = ?
    WHERE uk.id_kelas = ? AND LOWER(u.status_ujian) = 'aktif'
    ORDER BY u.tanggal_ujian DESC
");
$stmt->execute([$id_user, $id_kelas_siswa]);
$daftar_ujian = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Ujian - Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-50 min-h-screen">
<div class="max-w-5xl mx-auto p-8">
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-3xl font-bold text-slate-800">Daftar Ujian</h1>
            <p class="text-slate-500">Ujian yang tersedia untuk kelas Anda</p>
        </div>
        <div class="flex items-center gap-4">
            <p class="font-bold text-blue-600"><?= htmlspecialchars($nama_siswa) ?></p>
            <a href="dashboard.php" class="bg-slate-100 text-slate-500 w-10 h-10 rounded-full flex items-center justify-center">
                <i class="fas fa-home"></i>
            </a>
            <a href="../../logout.php" onclick="return confirm('Yakin keluar?')"
               class="bg-red-50 text-red-500 hover:bg-red-500 hover:text-white w-10 h-10 rounded-full flex items-center justify-center transition">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>

    <?php if (isset($_SESSION['flash'])): ?>
    <div class="mb-6 p-4 rounded-xl <?= $_SESSION['flash']['type']==='success'?'bg-green-100 text-green-800':'bg-red-100 text-red-800' ?>">
        <?= htmlspecialchars($_SESSION['flash']['msg']) ?>
    </div>
    <?php unset($_SESSION['flash']); endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php if (count($daftar_ujian) > 0): ?>
        <?php foreach ($daftar_ujian as $u): ?>
        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex flex-col hover:shadow-md transition">
            <div class="flex justify-between items-start mb-4">
                <div class="bg-blue-100 text-blue-600 w-12 h-12 rounded-xl flex items-center justify-center text-xl">
                    <i class="fas fa-file-signature"></i>
                </div>
                <span class="text-[10px] font-bold uppercase px-2 py-1 bg-slate-100 text-slate-500 rounded">
                    <?= $u['jumlah_soal'] ?> Soal
                </span>
            </div>
            <h3 class="font-bold text-lg text-slate-800 mb-1"><?= htmlspecialchars($u['judul_ujian']) ?></h3>
            <div class="text-xs text-slate-500 space-y-1 mb-4 flex-1">
                <p><i class="fas fa-book mr-1.5 text-gray-400"></i> <?= htmlspecialchars($u['nama_mapel'] ?? '-') ?></p>
                <p><i class="far fa-clock mr-1 text-gray-400"></i> <?= $u['durasi_menit'] ?> Menit</p>
                <p><i class="far fa-calendar-alt mr-1.5 text-gray-400"></i>
                    <?= date('d M Y', strtotime($u['tanggal_ujian'])) ?>
                    · <?= substr($u['jam_mulai'],0,5) ?> – <?= substr($u['jam_selesai'],0,5) ?>
                </p>
            </div>
            <div class="border-t border-slate-100 pt-4 mt-auto">
                <?php if ($u['sudah_kerjakan']): ?>
                <div class="bg-green-100 text-green-700 font-bold py-3 rounded-xl text-center border border-green-200">
                    <i class="fas fa-check-circle mr-1"></i> Telah Dikerjakan
                </div>
                <?php if ($u['tampil_nilai'] == '1' && $u['nilai_saya'] !== null): ?>
                <p class="text-center text-sm mt-2 text-gray-500">
                    Nilai: <span class="font-bold text-blue-600"><?= round($u['nilai_saya']) ?></span>
                </p>
                <?php endif; ?>
                <?php elseif ($u['jumlah_soal'] > 0): ?>
                <a href="kerjakan_ujian.php?id_ujian=<?= $u['id_ujian'] ?>"
                   class="block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition">
                    Kerjakan Sekarang
                </a>
                <?php else: ?>
                <button disabled class="block w-full text-center bg-slate-100 text-slate-400 font-bold py-3 rounded-xl cursor-not-allowed">
                    Soal Belum Disiapkan
                </button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <?php else: ?>
        <div class="col-span-full py-20 text-center bg-white rounded-3xl border-2 border-dashed border-slate-200">
            <div class="text-6xl mb-4">📅</div>
            <h3 class="text-xl font-bold text-slate-700">Belum Ada Ujian Aktif</h3>
            <p class="text-slate-500 mt-2">Belum ada ujian yang aktif untuk kelas Anda.</p>
        </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>