<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../../index.php");
    exit;
}

require_once '../../config/koneksi.php';

// =============================================
// KONEKSI MYSQLI
// =============================================
$conn = new mysqli("localhost", "root", "", "db_ujian_sekolah");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$guru_id = $_SESSION['id_user'] ?? $_SESSION['user_id'];

// =============================================
// FUNCTION FORMAT TANGGAL
// =============================================
function formatTanggal($tanggal)
{
    if (!$tanggal) return '-';

    return date('d M Y H:i', strtotime($tanggal));
}

// =============================================
// HAPUS UJIAN
// =============================================
if (isset($_GET['hapus']) && is_numeric($_GET['hapus'])) {

    $id = (int)$_GET['hapus'];

    $cek = $conn->query("
        SELECT id
        FROM ujian
        WHERE id = $id
        AND guru_id = $guru_id
    ");

    if ($cek && $cek->num_rows > 0) {

        $conn->query("
            DELETE FROM ujian
            WHERE id = $id
        ");

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Ujian berhasil dihapus.'
        ];
    }

    header("Location: setting_ujian.php");
    exit();
}

// =============================================
// PAGINATION
// =============================================
$per_page = 10;

$page = max(1, (int)($_GET['page'] ?? 1));

$offset = ($page - 1) * $per_page;

// =============================================
// TOTAL DATA
// =============================================
$total = 0;

$total_q = $conn->query("
    SELECT COUNT(*) AS c
    FROM ujian
    WHERE guru_id = $guru_id
");

if ($total_q) {
    $total = $total_q->fetch_assoc()['c'];
}

$total_page = ceil($total / $per_page);

// =============================================
// LIST UJIAN
// =============================================
$ujian_list = $conn->query("
    SELECT
        u.*,
        COUNT(DISTINCT h.siswa_id) AS peserta
    FROM ujian u
    LEFT JOIN hasil_ujian h
        ON h.ujian_id = u.id
    WHERE u.guru_id = $guru_id
    GROUP BY u.id
    ORDER BY u.id DESC
    LIMIT $per_page OFFSET $offset
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rencana Ujian</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        body{
            background:#f5f7fb;
        }
    </style>
</head>

<body>

<div class="min-h-screen flex">

    <!-- SIDEBAR -->
    <?php
    if (file_exists('../../layouts/sidebar_guru.php')) {
        include '../../layouts/sidebar_guru.php';
    }
    ?>

    <!-- CONTENT -->
    <div class="flex-1 p-8">

        <!-- HEADER -->
        <div class="flex items-center justify-between mb-8">

            <div>
                <h1 class="text-3xl font-bold text-slate-800">
                    Rencana Ujian
                </h1>

                <p class="text-slate-500 mt-1">
                    Kelola semua ujian Anda
                </p>
            </div>

            <a href="tambah_ujian.php"
               class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-xl font-semibold transition">
                ➕ Buat Ujian
            </a>

        </div>

        <!-- FLASH -->
        <?php if (isset($_SESSION['flash'])): ?>

            <div class="mb-6">

                <div class="<?= $_SESSION['flash']['type'] === 'success'
                    ? 'bg-green-100 text-green-700'
                    : 'bg-red-100 text-red-700'
                ?> px-4 py-3 rounded-xl">

                    <?= htmlspecialchars($_SESSION['flash']['msg']) ?>

                </div>

            </div>

            <?php unset($_SESSION['flash']); ?>

        <?php endif; ?>

        <!-- CARD -->
        <div class="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">

            <!-- CARD HEADER -->
            <div class="px-6 py-5 border-b border-slate-100 flex items-center justify-between">

                <h2 class="text-xl font-bold text-slate-800">
                    📅 Daftar Ujian
                </h2>

                <span class="bg-slate-100 text-slate-700 text-sm px-3 py-1 rounded-full font-semibold">
                    <?= $total ?> Ujian
                </span>

            </div>

            <!-- TABLE -->
            <?php if ($ujian_list && $ujian_list->num_rows > 0): ?>

                <div class="overflow-x-auto">

                    <table class="w-full">

                        <thead class="bg-slate-50">

                            <tr class="text-left text-sm text-slate-500">

                                <th class="px-6 py-4">No</th>
                                <th class="px-6 py-4">Nama Ujian</th>
                                <th class="px-6 py-4">Mapel</th>
                                <th class="px-6 py-4">Kelas</th>
                                <th class="px-6 py-4">Mulai</th>
                                <th class="px-6 py-4">Selesai</th>
                                <th class="px-6 py-4">Durasi</th>
                                <th class="px-6 py-4">Peserta</th>
                                <th class="px-6 py-4">Status</th>
                                <th class="px-6 py-4">Aksi</th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php
                        $no = $offset + 1;

                        while ($u = $ujian_list->fetch_assoc()):
                        ?>

                            <tr class="border-t border-slate-100 hover:bg-slate-50 transition">

                                <td class="px-6 py-4">
                                    <?= $no++ ?>
                                </td>

                                <td class="px-6 py-4 font-semibold text-slate-800">
                                    <?= htmlspecialchars($u['nama_ujian']) ?>
                                </td>

                                <td class="px-6 py-4">
                                    <?= htmlspecialchars($u['mata_pelajaran'] ?? '-') ?>
                                </td>

                                <td class="px-6 py-4">
                                    <?= htmlspecialchars($u['kelas'] ?? '-') ?>
                                </td>

                                <td class="px-6 py-4">
                                    <?= formatTanggal($u['tanggal_mulai']) ?>
                                </td>

                                <td class="px-6 py-4">
                                    <?= formatTanggal($u['tanggal_selesai']) ?>
                                </td>

                                <td class="px-6 py-4">
                                    <?= $u['durasi'] ?? '-' ?> menit
                                </td>

                                <td class="px-6 py-4">
                                    <?= $u['peserta'] ?>
                                </td>

                                <td class="px-6 py-4">

                                    <?php
                                    $status = $u['status'] ?? 'draft';

                                    $warna =
                                        $status === 'aktif'
                                        ? 'bg-green-100 text-green-700'
                                        : (
                                            $status === 'selesai'
                                            ? 'bg-slate-200 text-slate-700'
                                            : 'bg-yellow-100 text-yellow-700'
                                        );
                                    ?>

                                    <span class="<?= $warna ?> px-3 py-1 rounded-full text-xs font-semibold">
                                        <?= ucfirst($status) ?>
                                    </span>

                                </td>

                                <td class="px-6 py-4">

                                    <div class="flex gap-2">

                                        <a href="edit_ujian.php?id=<?= $u['id'] ?>"
                                           class="bg-blue-100 hover:bg-blue-200 text-blue-700 px-3 py-2 rounded-lg text-sm font-medium transition">
                                            ✏️ Edit
                                        </a>

                                        <a href="?hapus=<?= $u['id'] ?>"
                                           onclick="return confirm('Hapus ujian ini?')"
                                           class="bg-red-100 hover:bg-red-200 text-red-700 px-3 py-2 rounded-lg text-sm font-medium transition">
                                            🗑 Hapus
                                        </a>

                                    </div>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                        </tbody>

                    </table>

                </div>

                <!-- PAGINATION -->
                <?php if ($total_page > 1): ?>

                    <div class="p-6 flex gap-2 justify-center border-t border-slate-100">

                        <?php for ($i = 1; $i <= $total_page; $i++): ?>

                            <a href="?page=<?= $i ?>"
                               class="<?= $i === $page
                                    ? 'bg-blue-600 text-white'
                                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                               ?> w-10 h-10 rounded-xl flex items-center justify-center font-semibold transition">

                                <?= $i ?>

                            </a>

                        <?php endfor; ?>

                    </div>

                <?php endif; ?>

            <?php else: ?>

                <!-- EMPTY -->
                <div class="py-20 text-center">

                    <div class="text-6xl mb-4">
                        📅
                    </div>

                    <h3 class="text-xl font-bold text-slate-700 mb-2">
                        Belum ada ujian
                    </h3>

                    <p class="text-slate-500 mb-6">
                        Mulai buat ujian pertama Anda
                    </p>

                    <a href="tambah_ujian.php"
                       class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-semibold transition">

                        ➕ Buat Ujian

                    </a>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

</body>
</html>