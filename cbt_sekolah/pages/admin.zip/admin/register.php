<?php
session_start();
// Cek sesi admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit;
}
require_once '../../config/koneksi.php';

// Proses Update Status User (Aktif/Nonaktif)
if (isset($_POST['update_status'])) {
    $id_user = $_POST['id_user'];
    $status = $_POST['status'];
    try {
        $stmt = $pdo->prepare("UPDATE tb_users SET status = ? WHERE id_user = ?");
        $stmt->execute([$status, $id_user]);
        $_SESSION['success'] = "Status user berhasil diupdate!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Gagal mengupdate status: " . $e->getMessage();
    }
    header("Location: register.php");
    exit;
}

// Proses Tambah User Manual
if (isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $role = $_POST['role'];
    $nis = !empty($_POST['nis']) ? trim($_POST['nis']) : null;
    $nisn = !empty($_POST['nisn']) ? trim($_POST['nisn']) : null;
    $id_kelas = !empty($_POST['id_kelas']) ? $_POST['id_kelas'] : null;
    $jenis_kelamin = !empty($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : null;
    $tempat_lahir = !empty($_POST['tempat_lahir']) ? trim($_POST['tempat_lahir']) : null;
    $tanggal_lahir = !empty($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : null;
    $agama = !empty($_POST['agama']) ? trim($_POST['agama']) : null;
    $alamat = !empty($_POST['alamat']) ? trim($_POST['alamat']) : null;
    $status = 'aktif';
    
    try {
        $check = $pdo->prepare("SELECT COUNT(*) FROM tb_users WHERE username = ?");
        $check->execute([$username]);
        if ($check->fetchColumn() > 0) {
            $_SESSION['error'] = "Username '{$username}' sudah terdaftar!";
        } else {
            $sql = "INSERT INTO tb_users (username, password, nama_lengkap, role, nis, nisn, id_kelas, jenis_kelamin, tempat_lahir, tanggal_lahir, agama, alamat, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$username, $password, $nama_lengkap, $role, $nis, $nisn, $id_kelas, $jenis_kelamin, $tempat_lahir, $tanggal_lahir, $agama, $alamat, $status]);
            $_SESSION['success'] = "User '{$nama_lengkap}' berhasil ditambahkan!";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Gagal menambahkan user: " . $e->getMessage();
    }
    header("Location: register.php");
    exit;
}

// Proses Import CSV
if (isset($_POST['import_users'])) {
    if (isset($_FILES['file_import']) && $_FILES['file_import']['error'] == 0) {
        $fileName = $_FILES['file_import']['tmp_name'];
        
        try {
            $file = fopen($fileName, 'r');
            $headers = fgetcsv($file);
            
            $successCount = 0;
            $errorCount = 0;
            $errors = [];
            
            while (($row = fgetcsv($file)) !== false) {
                if (count($row) < 4) continue;
                
                $username = trim($row[0]);
                $password_plain = trim($row[1]);
                $password = password_hash($password_plain, PASSWORD_DEFAULT);
                $nama_lengkap = trim($row[2]);
                $role = trim($row[3]);
                $nis = !empty(trim($row[4])) ? trim($row[4]) : null;
                $nisn = !empty(trim($row[5])) ? trim($row[5]) : null;
                $id_kelas = !empty(trim($row[6])) ? trim($row[6]) : null;
                $jenis_kelamin = !empty(trim($row[7])) ? trim($row[7]) : null;
                $tempat_lahir = !empty(trim($row[8])) ? trim($row[8]) : null;
                $tanggal_lahir = !empty(trim($row[9])) ? trim($row[9]) : null;
                $agama = !empty(trim($row[10])) ? trim($row[10]) : null;
                $alamat = !empty(trim($row[11])) ? trim($row[11]) : null;
                $status = 'aktif';
                
                if (!in_array($role, ['admin', 'guru', 'siswa', 'pengawas'])) {
                    if ($role == 'superuser') $role = 'admin';
                    else {
                        $errorCount++;
                        $errors[] = "Role '{$role}' tidak valid";
                        continue;
                    }
                }
                
                $check = $pdo->prepare("SELECT COUNT(*) FROM tb_users WHERE username = ?");
                $check->execute([$username]);
                if ($check->fetchColumn() > 0) {
                    $errorCount++;
                    $errors[] = "Username '{$username}' sudah terdaftar";
                    continue;
                }
                
                $sql = "INSERT INTO tb_users (username, password, nama_lengkap, role, nis, nisn, id_kelas, jenis_kelamin, tempat_lahir, tanggal_lahir, agama, alamat, status) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$username, $password, $nama_lengkap, $role, $nis, $nisn, $id_kelas, $jenis_kelamin, $tempat_lahir, $tanggal_lahir, $agama, $alamat, $status]);
                $successCount++;
            }
            fclose($file);
            
            $_SESSION['success'] = "Import selesai! Berhasil: {$successCount} user";
            if ($errorCount > 0) {
                $_SESSION['warning'] = "Gagal: {$errorCount} user";
            }
        } catch (Exception $e) {
            $_SESSION['error'] = "Gagal mengimport file: " . $e->getMessage();
        }
    } else {
        $_SESSION['error'] = "Silakan pilih file CSV terlebih dahulu!";
    }
    header("Location: register.php");
    exit;
}

// Proses Hapus User
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    try {
        if ($id == $_SESSION['id_user']) {
            $_SESSION['error'] = "Tidak dapat menghapus akun sendiri!";
        } else {
            $stmt = $pdo->prepare("DELETE FROM tb_users WHERE id_user = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = "User berhasil dihapus!";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Gagal menghapus user: " . $e->getMessage();
    }
    header("Location: register.php");
    exit;
}

// Proses Edit User
if (isset($_POST['edit_user'])) {
    $id_user = $_POST['id_user'];
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $role = $_POST['role'];
    $nis = !empty($_POST['nis']) ? trim($_POST['nis']) : null;
    $nisn = !empty($_POST['nisn']) ? trim($_POST['nisn']) : null;
    $id_kelas = !empty($_POST['id_kelas']) ? $_POST['id_kelas'] : null;
    $jenis_kelamin = !empty($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : null;
    $tempat_lahir = !empty($_POST['tempat_lahir']) ? trim($_POST['tempat_lahir']) : null;
    $tanggal_lahir = !empty($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : null;
    $agama = !empty($_POST['agama']) ? trim($_POST['agama']) : null;
    $alamat = !empty($_POST['alamat']) ? trim($_POST['alamat']) : null;
    
    try {
        $sql = "UPDATE tb_users SET nama_lengkap = ?, role = ?, nis = ?, nisn = ?, id_kelas = ?, jenis_kelamin = ?, tempat_lahir = ?, tanggal_lahir = ?, agama = ?, alamat = ? WHERE id_user = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nama_lengkap, $role, $nis, $nisn, $id_kelas, $jenis_kelamin, $tempat_lahir, $tanggal_lahir, $agama, $alamat, $id_user]);
        
        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE tb_users SET password = ? WHERE id_user = ?");
            $stmt->execute([$password, $id_user]);
        }
        
        $_SESSION['success'] = "User '{$nama_lengkap}' berhasil diupdate!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Gagal mengupdate user: " . $e->getMessage();
    }
    header("Location: register.php");
    exit;
}

// Reset Password
if (isset($_GET['reset_password'])) {
    $id = $_GET['reset_password'];
    $default_password = password_hash('123456', PASSWORD_DEFAULT);
    try {
        $stmt = $pdo->prepare("UPDATE tb_users SET password = ? WHERE id_user = ?");
        $stmt->execute([$default_password, $id]);
        $_SESSION['success'] = "Password berhasil direset menjadi: 123456";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Gagal mereset password: " . $e->getMessage();
    }
    header("Location: register.php");
    exit;
}

// Ambil data user dengan filter
$search = $_GET['search'] ?? '';
$role_filter = $_GET['role_filter'] ?? '';
$status_filter = $_GET['status_filter'] ?? '';

$query = "SELECT u.*, k.nama_kelas 
          FROM tb_users u 
          LEFT JOIN tb_kelas k ON u.id_kelas = k.id_kelas 
          WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (u.username LIKE ? OR u.nama_lengkap LIKE ? OR u.nis LIKE ? OR u.nisn LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($role_filter)) {
    $query .= " AND u.role = ?";
    $params[] = $role_filter;
}

if (!empty($status_filter)) {
    $query .= " AND u.status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY u.id_user DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll();

// Ambil data kelas untuk dropdown
$kelas_list = [];
try {
    $kelas_list = $pdo->query("SELECT * FROM tb_kelas ORDER BY nama_kelas ASC")->fetchAll();
} catch (PDOException $e) {
    $kelas_list = [];
}

// Data statistik
$total_siswa = $pdo->query("SELECT COUNT(*) FROM tb_users WHERE role = 'siswa'")->fetchColumn();
$total_guru = $pdo->query("SELECT COUNT(*) FROM tb_users WHERE role = 'guru'")->fetchColumn();
$total_admin = $pdo->query("SELECT COUNT(*) FROM tb_users WHERE role = 'admin'")->fetchColumn();
$total_pengawas = $pdo->query("SELECT COUNT(*) FROM tb_users WHERE role = 'pengawas'")->fetchColumn();
$total_active = $pdo->query("SELECT COUNT(*) FROM tb_users WHERE status = 'aktif'")->fetchColumn();
$total_inactive = $pdo->query("SELECT COUNT(*) FROM tb_users WHERE status = 'nonaktif'")->fetchColumn();
$total_all = $total_siswa + $total_guru + $total_admin + $total_pengawas;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register User - Admin | SMK N 8 Bandar Lampung</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary: #4A6FA5;
            --primary-light: #6B8DB5;
            --primary-dark: #3D5A80;
            --secondary: #98C1D9;
            --secondary-light: #B8D4E8;
            --accent: #EE6C4D;
            --accent-light: #F29B7A;
            --bg-main: #F0F4F8;
            --bg-card: #FFFFFF;
            --text-primary: #2C3E50;
            --text-secondary: #6C7A8A;
            --border: #E2E8F0;
            --success: #48BB78;
            --danger: #F56565;
            --warning: #ED8936;
            --info: #4299E1;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, var(--bg-main) 0%, #E8EEF5 100%);
            font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
        }

        /* Header Styles */
        .app-header {
            background: var(--bg-card);
            box-shadow: 0 1px 3px rgba(0,0,0,0.05), 0 1px 2px rgba(0,0,0,0.03);
            border-bottom: 1px solid var(--border);
            position: sticky;
            top: 0;
            z-index: 50;
        }

        /* Card Styles */
        .stat-card {
            background: var(--bg-card);
            border-radius: 20px;
            transition: all 0.3s ease;
            border: 1px solid var(--border);
            box-shadow: 0 1px 2px rgba(0,0,0,0.02);
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.08), 0 8px 10px -6px rgba(0,0,0,0.02);
            border-color: var(--secondary);
        }

        /* Button Styles */
        .btn-primary {
            background: var(--primary);
            transition: all 0.3s ease;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(74, 111, 165, 0.25);
        }

        .btn-secondary {
            background: var(--secondary);
            transition: all 0.3s ease;
        }
        .btn-secondary:hover {
            background: var(--secondary-light);
            transform: translateY(-1px);
        }

        /* Table Styles */
        .table-container {
            overflow-x: auto;
            border-radius: 16px;
            background: var(--bg-card);
            border: 1px solid var(--border);
            box-shadow: 0 1px 2px rgba(0,0,0,0.02);
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            background: #F8FAFC;
            color: var(--text-primary);
            padding: 14px 12px;
            font-size: 0.7rem;
            font-weight: 700;
            text-align: left;
            white-space: nowrap;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            border-bottom: 1px solid var(--border);
        }

        .data-table td {
            padding: 12px;
            font-size: 0.8rem;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
            color: var(--text-primary);
        }

        .data-table tr:hover {
            background: #F8FAFC;
        }

        /* Modal Styles */
        .modal-overlay {
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
        }

        /* Badge Styles */
        .badge-role {
            padding: 4px 12px;
            border-radius: 50px;
            font-size: 0.7rem;
            font-weight: 600;
            display: inline-block;
        }
        .badge-siswa { background: #EBF8FF; color: #2B6CB0; }
        .badge-guru { background: #E6FFFA; color: #276749; }
        .badge-admin { background: #FEFCBF; color: #975A16; }
        .badge-pengawas { background: #FAF5FF; color: #6B46C1; }
        .badge-aktif { background: #E6FFFA; color: #276749; }
        .badge-nonaktif { background: #FFF5F5; color: #C53030; }
        
        /* Form Styles */
        .form-input {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            outline: none;
            transition: all 0.3s;
            font-size: 0.85rem;
            background: var(--bg-card);
        }
        .form-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(74, 111, 165, 0.1);
        }
        
        .form-label {
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 6px;
            display: block;
            letter-spacing: 0.3px;
        }
        
        .filter-input {
            padding: 8px 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            outline: none;
            font-size: 0.8rem;
            background: var(--bg-card);
        }
        .filter-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(74, 111, 165, 0.1);
        }
        
        .action-btn {
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 10px;
        }
        .action-btn:hover {
            transform: scale(1.05);
            background: #F1F5F9;
        }
        
        /* Toggle Switch */
        .switch {
            position: relative;
            display: inline-block;
            width: 46px;
            height: 22px;
        }
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #CBD5E0;
            transition: 0.3s;
            border-radius: 22px;
        }
        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 2px;
            bottom: 2px;
            background-color: white;
            transition: 0.3s;
            border-radius: 50%;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        input:checked + .slider {
            background-color: var(--success);
        }
        input:checked + .slider:before {
            transform: translateX(24px);
        }
        input:disabled + .slider {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Dashboard Link */
        .dashboard-link {
            transition: all 0.3s ease;
            background: var(--primary);
        }
        .dashboard-link:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(74, 111, 165, 0.3);
        }
    </style>
</head>
<body>

<!-- HEADER NAVIGATION -->
<header class="app-header">
    <div class="px-6 py-4 flex justify-between items-center">
        <div class="flex items-center gap-4">
            <div class="flex items-center gap-3">
                <img src="../../assets/img/logo_sekolah.png" alt="Logo" class="h-12 w-12 rounded-xl shadow-sm border border-gray-100">
                <div>
                    <h1 class="text-xl font-bold" style="color: var(--primary);">Register User</h1>
                    <p class="text-xs" style="color: var(--text-secondary);">Kelola akun pengguna sistem</p>
                </div>
            </div>
        </div>
        <div class="flex items-center gap-4">
            <div class="text-right">
                <p class="text-sm font-semibold" style="color: var(--text-primary);"><?= $_SESSION['nama'] ?? 'Admin' ?></p>
                <p class="text-xs" style="color: var(--text-secondary);">Administrator</p>
            </div>
            <a href="dashboard.php" class="dashboard-link flex items-center gap-2 text-white px-4 py-2 rounded-xl text-sm font-medium">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
        </div>
    </div>
</header>

<!-- MAIN CONTENT -->
<main class="p-6 max-w-[1600px] mx-auto">
    <!-- Alert Messages -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="bg-green-50 border-l-4 border-green-500 text-green-700 p-4 rounded-xl mb-6 flex items-center justify-between">
            <div><i class="fas fa-check-circle mr-2"></i> <?= $_SESSION['success'] ?></div>
            <button onclick="this.parentElement.remove()" class="text-green-700"><i class="fas fa-times"></i></button>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 rounded-xl mb-6 flex items-center justify-between">
            <div><i class="fas fa-exclamation-circle mr-2"></i> <?= $_SESSION['error'] ?></div>
            <button onclick="this.parentElement.remove()" class="text-red-700"><i class="fas fa-times"></i></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['warning'])): ?>
        <div class="bg-yellow-50 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-xl mb-6 flex items-center justify-between">
            <div><i class="fas fa-exclamation-triangle mr-2"></i> <?= $_SESSION['warning'] ?></div>
            <button onclick="this.parentElement.remove()" class="text-yellow-700"><i class="fas fa-times"></i></button>
        </div>
        <?php unset($_SESSION['warning']); ?>
    <?php endif; ?>

    <!-- Statistik Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        <div class="stat-card p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-medium text-gray-400 uppercase tracking-wide">Total User</p>
                    <p class="text-2xl font-bold mt-1" style="color: var(--primary);"><?= $total_all ?></p>
                </div>
                <div class="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                    <i class="fas fa-users text-blue-500 text-lg"></i>
                </div>
            </div>
        </div>
        <div class="stat-card p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-medium text-gray-400 uppercase tracking-wide">Siswa</p>
                    <p class="text-2xl font-bold mt-1" style="color: var(--primary);"><?= $total_siswa ?></p>
                </div>
                <div class="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                    <i class="fas fa-user-graduate text-blue-500 text-lg"></i>
                </div>
            </div>
        </div>
        <div class="stat-card p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-medium text-gray-400 uppercase tracking-wide">Guru</p>
                    <p class="text-2xl font-bold mt-1" style="color: var(--primary);"><?= $total_guru ?></p>
                </div>
                <div class="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center">
                    <i class="fas fa-chalkboard-user text-green-500 text-lg"></i>
                </div>
            </div>
        </div>
        <div class="stat-card p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-medium text-gray-400 uppercase tracking-wide">Pengawas</p>
                    <p class="text-2xl font-bold mt-1" style="color: var(--primary);"><?= $total_pengawas ?></p>
                </div>
                <div class="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center">
                    <i class="fas fa-user-shield text-purple-500 text-lg"></i>
                </div>
            </div>
        </div>
        <div class="stat-card p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-medium text-gray-400 uppercase tracking-wide">Aktif</p>
                    <p class="text-2xl font-bold text-green-600"><?= $total_active ?></p>
                </div>
                <div class="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center">
                    <i class="fas fa-check-circle text-green-500 text-lg"></i>
                </div>
            </div>
        </div>
        <div class="stat-card p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-medium text-gray-400 uppercase tracking-wide">Nonaktif</p>
                    <p class="text-2xl font-bold text-red-600"><?= $total_inactive ?></p>
                </div>
                <div class="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
                    <i class="fas fa-ban text-red-500 text-lg"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Tombol Aksi & Filter -->
    <div class="flex flex-wrap justify-between items-center gap-4 mb-6">
        <div class="flex gap-3 flex-wrap">
            <button onclick="openAddModal()" class="btn-primary text-white px-5 py-2.5 rounded-xl font-medium flex items-center gap-2 text-sm">
                <i class="fas fa-plus"></i> Tambah User
            </button>
            <button onclick="openImportModal()" class="bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-xl font-medium flex items-center gap-2 text-sm transition shadow-sm">
                <i class="fas fa-file-import"></i> Import CSV
            </button>
            <a href="#" onclick="downloadTemplate()" class="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2.5 rounded-xl font-medium flex items-center gap-2 text-sm transition shadow-sm">
                <i class="fas fa-download"></i> Template CSV
            </a>
        </div>
        
        <form method="GET" class="flex gap-3 flex-wrap items-center">
            <input type="text" name="search" placeholder="Cari nama, username, NIS..." value="<?= htmlspecialchars($search) ?>" class="filter-input w-64">
            <select name="role_filter" class="filter-input" onchange="this.form.submit()">
                <option value="">Semua Role</option>
                <option value="admin" <?= $role_filter == 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="guru" <?= $role_filter == 'guru' ? 'selected' : '' ?>>Guru</option>
                <option value="siswa" <?= $role_filter == 'siswa' ? 'selected' : '' ?>>Siswa</option>
                <option value="pengawas" <?= $role_filter == 'pengawas' ? 'selected' : '' ?>>Pengawas</option>
            </select>
            <select name="status_filter" class="filter-input" onchange="this.form.submit()">
                <option value="">Semua Status</option>
                <option value="aktif" <?= $status_filter == 'aktif' ? 'selected' : '' ?>>Aktif</option>
                <option value="nonaktif" <?= $status_filter == 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
            </select>
            <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl transition text-sm shadow-sm">
                <i class="fas fa-search"></i> Cari
            </button>
            <?php if ($search || $role_filter || $status_filter): ?>
                <a href="register.php" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl transition text-sm shadow-sm">
                    <i class="fas fa-times"></i> Reset
                </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Tabel Data User -->
    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Nama Lengkap</th>
                    <th>Role</th>
                    <th>NIS/NISN</th>
                    <th>Kelas</th>
                    <th>No HP</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($users) > 0): ?>
                    <?php $no = 1; foreach ($users as $user): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td class="font-medium"><?= htmlspecialchars($user['username']) ?></td>
                            <td><?= htmlspecialchars($user['nama_lengkap']) ?></td>
                            <td>
                                <span class="badge-role 
                                    <?= $user['role'] == 'siswa' ? 'badge-siswa' : '' ?>
                                    <?= $user['role'] == 'guru' ? 'badge-guru' : '' ?>
                                    <?= $user['role'] == 'admin' ? 'badge-admin' : '' ?>
                                    <?= $user['role'] == 'pengawas' ? 'badge-pengawas' : '' ?>">
                                    <?= ucfirst($user['role']) ?>
                                </span>
                            </td>
                            <td>
                                <?php 
                                if ($user['role'] == 'siswa') echo htmlspecialchars($user['nis'] ?? '-');
                                else echo htmlspecialchars($user['nisn'] ?? '-');
                                ?>
                            </td>
                            <td><?= htmlspecialchars($user['nama_kelas'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($user['no_hp'] ?? '-') ?></td>
                            <td>
                                <form method="POST" class="inline-block" onsubmit="return confirm('Ubah status user ini?')">
                                    <input type="hidden" name="id_user" value="<?= $user['id_user'] ?>">
                                    <input type="hidden" name="status" value="<?= $user['status'] == 'aktif' ? 'nonaktif' : 'aktif' ?>">
                                    <button type="submit" name="update_status" class="switch">
                                        <input type="checkbox" <?= $user['status'] == 'aktif' ? 'checked' : '' ?> <?= $user['id_user'] == $_SESSION['id_user'] ? 'disabled' : '' ?>>
                                        <span class="slider"></span>
                                    </button>
                                </form>
                             </td>
                            <td>
                                <div class="flex gap-1">
                                    <button onclick="openEditModal(<?= htmlspecialchars(json_encode($user)) ?>)" class="action-btn text-blue-600 hover:bg-blue-50" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if ($user['id_user'] != $_SESSION['id_user']): ?>
                                        <button onclick="confirmDelete(<?= $user['id_user'] ?>, '<?= htmlspecialchars($user['nama_lengkap']) ?>')" class="action-btn text-red-600 hover:bg-red-50" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    <?php endif; ?>
                                    <button onclick="confirmResetPassword(<?= $user['id_user'] ?>, '<?= htmlspecialchars($user['nama_lengkap']) ?>')" class="action-btn text-yellow-600 hover:bg-yellow-50" title="Reset Password">
                                        <i class="fas fa-key"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center py-12 text-gray-400">
                            <i class="fas fa-users fa-3x mb-3 block"></i>
                            Belum ada data user
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Info Footer -->
    <div class="mt-4 text-center text-xs text-gray-400">
        <i class="fas fa-info-circle"></i> Total data: <?= count($users) ?> user
    </div>
</main>

<!-- MODAL TAMBAH USER -->
<div id="addModal" class="fixed inset-0 modal-overlay hidden items-center justify-center z-50 p-4">
    <div class="bg-white w-full max-w-2xl rounded-2xl shadow-xl max-h-[90vh] overflow-y-auto">
        <div class="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
            <h2 class="text-xl font-bold" style="color: var(--primary);">
                <i class="fas fa-user-plus mr-2"></i> Tambah User Baru
            </h2>
            <button onclick="closeAddModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <form method="POST" class="p-6">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="form-label">Username *</label>
                    <input type="text" name="username" class="form-input" required>
                </div>
                <div>
                    <label class="form-label">Password *</label>
                    <input type="password" name="password" class="form-input" required>
                </div>
                <div class="col-span-2">
                    <label class="form-label">Nama Lengkap *</label>
                    <input type="text" name="nama_lengkap" class="form-input" required>
                </div>
                <div>
                    <label class="form-label">Role *</label>
                    <select name="role" id="roleSelect" class="form-input" required onchange="toggleFields()">
                        <option value="">Pilih Role</option>
                        <option value="admin">Admin</option>
                        <option value="guru">Guru</option>
                        <option value="siswa">Siswa</option>
                        <option value="pengawas">Pengawas</option>
                    </select>
                </div>
                <div id="nisField" class="hidden">
                    <label class="form-label">NIS</label>
                    <input type="text" name="nis" class="form-input" placeholder="Nomor Induk Siswa">
                </div>
                <div id="nisnField" class="hidden">
                    <label class="form-label">NISN</label>
                    <input type="text" name="nisn" class="form-input" placeholder="Nomor Induk Siswa Nasional">
                </div>
                <div id="kelasField" class="hidden">
                    <label class="form-label">Kelas</label>
                    <select name="id_kelas" class="form-input">
                        <option value="">Pilih Kelas</option>
                        <?php foreach ($kelas_list as $kelas): ?>
                            <option value="<?= $kelas['id_kelas'] ?>"><?= htmlspecialchars($kelas['nama_kelas']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="form-label">Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="form-input">
                        <option value="">Pilih</option>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                <div>
                    <label class="form-label">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" class="form-input">
                </div>
                <div>
                    <label class="form-label">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-input">
                </div>
                <div>
                    <label class="form-label">Agama</label>
                    <select name="agama" class="form-input">
                        <option value="">Pilih</option>
                        <option value="Islam">Islam</option>
                        <option value="Kristen">Kristen</option>
                        <option value="Katolik">Katolik</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Buddha">Buddha</option>
                        <option value="Konghucu">Konghucu</option>
                    </select>
                </div>
                <div>
                    <label class="form-label">No HP</label>
                    <input type="text" name="no_hp" class="form-input" placeholder="08xxxxxxxxxx">
                </div>
                <div class="col-span-2">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-input" rows="2" placeholder="Alamat lengkap"></textarea>
                </div>
            </div>
            <div class="flex justify-end gap-3 mt-6 pt-4 border-t">
                <button type="button" onclick="closeAddModal()" class="px-4 py-2 border rounded-xl hover:bg-gray-50">Batal</button>
                <button type="submit" name="add_user" class="btn-primary text-white px-6 py-2 rounded-xl">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL EDIT USER -->
<div id="editModal" class="fixed inset-0 modal-overlay hidden items-center justify-center z-50 p-4">
    <div class="bg-white w-full max-w-2xl rounded-2xl shadow-xl max-h-[90vh] overflow-y-auto">
        <div class="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
            <h2 class="text-xl font-bold" style="color: var(--primary);">
                <i class="fas fa-user-edit mr-2"></i> Edit User
            </h2>
            <button onclick="closeEditModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <form method="POST" class="p-6">
            <input type="hidden" name="id_user" id="edit_id_user">
            <div class="grid grid-cols-2 gap-4">
                <div class="col-span-2">
                    <label class="form-label">Nama Lengkap *</label>
                    <input type="text" name="nama_lengkap" id="edit_nama_lengkap" class="form-input" required>
                </div>
                <div>
                    <label class="form-label">Password Baru (kosongkan jika tidak diubah)</label>
                    <input type="password" name="password" class="form-input" placeholder="Password baru">
                </div>
                <div>
                    <label class="form-label">Role *</label>
                    <select name="role" id="edit_role" class="form-input" required onchange="toggleEditFields()">
                        <option value="admin">Admin</option>
                        <option value="guru">Guru</option>
                        <option value="siswa">Siswa</option>
                        <option value="pengawas">Pengawas</option>
                    </select>
                </div>
                <div id="edit_nisField" class="hidden">
                    <label class="form-label">NIS</label>
                    <input type="text" name="nis" id="edit_nis" class="form-input">
                </div>
                <div id="edit_nisnField" class="hidden">
                    <label class="form-label">NISN</label>
                    <input type="text" name="nisn" id="edit_nisn" class="form-input">
                </div>
                <div id="edit_kelasField" class="hidden">
                    <label class="form-label">Kelas</label>
                    <select name="id_kelas" id="edit_id_kelas" class="form-input">
                        <option value="">Pilih Kelas</option>
                        <?php foreach ($kelas_list as $kelas): ?>
                            <option value="<?= $kelas['id_kelas'] ?>"><?= htmlspecialchars($kelas['nama_kelas']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="form-label">Jenis Kelamin</label>
                    <select name="jenis_kelamin" id="edit_jenis_kelamin" class="form-input">
                        <option value="">Pilih</option>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                <div>
                    <label class="form-label">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" id="edit_tempat_lahir" class="form-input">
                </div>
                <div>
                    <label class="form-label">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" id="edit_tanggal_lahir" class="form-input">
                </div>
                <div>
                    <label class="form-label">Agama</label>
                    <select name="agama" id="edit_agama" class="form-input">
                        <option value="">Pilih</option>
                        <option value="Islam">Islam</option>
                        <option value="Kristen">Kristen</option>
                        <option value="Katolik">Katolik</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Buddha">Buddha</option>
                        <option value="Konghucu">Konghucu</option>
                    </select>
                </div>
                <div>
                    <label class="form-label">No HP</label>
                    <input type="text" name="no_hp" id="edit_no_hp" class="form-input">
                </div>
                <div class="col-span-2">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" id="edit_alamat" class="form-input" rows="2"></textarea>
                </div>
            </div>
            <div class="flex justify-end gap-3 mt-6 pt-4 border-t">
                <button type="button" onclick="closeEditModal()" class="px-4 py-2 border rounded-xl hover:bg-gray-50">Batal</button>
                <button type="submit" name="edit_user" class="btn-primary text-white px-6 py-2 rounded-xl">Update</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL IMPORT -->
<div id="importModal" class="fixed inset-0 modal-overlay hidden items-center justify-center z-50 p-4">
    <div class="bg-white w-full max-w-md rounded-2xl shadow-xl">
        <div class="border-b px-6 py-4 flex justify-between items-center">
            <h2 class="text-xl font-bold" style="color: var(--primary);">
                <i class="fas fa-file-import mr-2"></i> Import User
            </h2>
            <button onclick="closeImportModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <form method="POST" enctype="multipart/form-data" class="p-6">
            <div class="mb-4">
                <label class="form-label">File CSV</label>
                <input type="file" name="file_import" accept=".csv" class="form-input" required>
                <p class="text-xs text-gray-400 mt-2">
                    Format: Username, Password, Nama Lengkap, Role, NIS, NISN, ID Kelas, Jenis Kelamin, Tempat Lahir, Tanggal Lahir, Agama, Alamat
                </p>
            </div>
            <div class="flex justify-end gap-3 mt-6 pt-4 border-t">
                <button type="button" onclick="closeImportModal()" class="px-4 py-2 border rounded-xl hover:bg-gray-50">Batal</button>
                <button type="submit" name="import_users" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-xl">Import</button>
            </div>
        </form>
    </div>
</div>

<script>
    // Toggle fields berdasarkan role untuk tambah
    function toggleFields() {
        const role = document.getElementById('roleSelect').value;
        document.getElementById('nisField').classList.add('hidden');
        document.getElementById('nisnField').classList.add('hidden');
        document.getElementById('kelasField').classList.add('hidden');
        
        if (role === 'siswa') {
            document.getElementById('nisField').classList.remove('hidden');
            document.getElementById('nisnField').classList.remove('hidden');
            document.getElementById('kelasField').classList.remove('hidden');
        }
    }

    // Toggle fields untuk edit
    function toggleEditFields() {
        const role = document.getElementById('edit_role').value;
        document.getElementById('edit_nisField').classList.add('hidden');
        document.getElementById('edit_nisnField').classList.add('hidden');
        document.getElementById('edit_kelasField').classList.add('hidden');
        
        if (role === 'siswa') {
            document.getElementById('edit_nisField').classList.remove('hidden');
            document.getElementById('edit_nisnField').classList.remove('hidden');
            document.getElementById('edit_kelasField').classList.remove('hidden');
        }
    }

    // Modal functions
    function openAddModal() {
        document.getElementById('addModal').classList.remove('hidden');
        document.getElementById('addModal').classList.add('flex');
    }
    function closeAddModal() {
        document.getElementById('addModal').classList.add('hidden');
        document.getElementById('addModal').classList.remove('flex');
        document.getElementById('roleSelect').value = '';
        toggleFields();
    }
    
    function openEditModal(user) {
        document.getElementById('edit_id_user').value = user.id_user;
        document.getElementById('edit_nama_lengkap').value = user.nama_lengkap || '';
        document.getElementById('edit_role').value = user.role || 'admin';
        document.getElementById('edit_nis').value = user.nis || '';
        document.getElementById('edit_nisn').value = user.nisn || '';
        document.getElementById('edit_id_kelas').value = user.id_kelas || '';
        document.getElementById('edit_jenis_kelamin').value = user.jenis_kelamin || '';
        document.getElementById('edit_tempat_lahir').value = user.tempat_lahir || '';
        document.getElementById('edit_tanggal_lahir').value = user.tanggal_lahir || '';
        document.getElementById('edit_agama').value = user.agama || '';
        document.getElementById('edit_no_hp').value = user.no_hp || '';
        document.getElementById('edit_alamat').value = user.alamat || '';
        
        toggleEditFields();
        document.getElementById('editModal').classList.remove('hidden');
        document.getElementById('editModal').classList.add('flex');
    }
    function closeEditModal() {
        document.getElementById('editModal').classList.add('hidden');
        document.getElementById('editModal').classList.remove('flex');
    }
    
    function openImportModal() {
        document.getElementById('importModal').classList.remove('hidden');
        document.getElementById('importModal').classList.add('flex');
    }
    function closeImportModal() {
        document.getElementById('importModal').classList.add('hidden');
        document.getElementById('importModal').classList.remove('flex');
    }
    
    // Download Template CSV
    function downloadTemplate() {
        const template = "Username,Password,Nama Lengkap,Role,NIS,NISN,ID Kelas,Jenis Kelamin,Tempat Lahir,Tanggal Lahir,Agama,Alamat\n" +
                        "ahmad123,123456,Ahmad Fauzi,siswa,2025001,1234567890,1,L,Jakarta,2005-01-01,Islam,Jl. Pendidikan No.1\n" +
                        "budi_s,123456,Budi Santoso,guru,,,,,,,,\n" +
                        "citra_d,123456,Citra Dewi,admin,,,,,,,,\n" +
                        "dian_p,123456,Dian Purnama,pengawas,,,,,,,,";
        
        const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.setAttribute('download', 'template_user.csv');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }
    
    // Confirm Delete
    function confirmDelete(id, nama) {
        Swal.fire({
            title: 'Hapus User?',
            text: `Apakah Anda yakin ingin menghapus user "${nama}"?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `?delete=${id}`;
            }
        });
    }
    
    // Confirm Reset Password
    function confirmResetPassword(id, nama) {
        Swal.fire({
            title: 'Reset Password?',
            text: `Reset password untuk user "${nama}" menjadi 123456?`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#f59e0b',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, Reset!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `?reset_password=${id}`;
            }
        });
    }
</script>
</body>
</html>