<?php
session_start();
require_once '../../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_user = $_SESSION['id_user'];
    $id_ujian = (int)$_POST['id_ujian'];
    $jawaban_siswa = $_POST['jawaban'] ?? []; 

    // 1. Ambil kunci jawaban dan jenis soal
    $stmt = $pdo->prepare("SELECT s.id_soal, s.kunci_jawaban, s.jenis_soal FROM tb_ujian_soal us JOIN tb_soal s ON us.id_soal = s.id_soal WHERE us.id_ujian = ?");
    $stmt->execute([$id_ujian]);
    $list_soal = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2. Buat record di tb_hasil_ujian (Nilai awal 0)
    $ins_hasil = $pdo->prepare("INSERT INTO tb_hasil_ujian (id_user, id_ujian, nilai) VALUES (?, ?, 0)");
    $ins_hasil->execute([$id_user, $id_ujian]);
    $id_hasil = $pdo->lastInsertId();

    $benar = 0; $total_pg = 0;
    $ins_jwb = $pdo->prepare("INSERT INTO tb_jawaban (id_hasil, id_user, id_ujian, id_soal, jawaban) VALUES (?, ?, ?, ?, ?)");
    
    foreach ($list_soal as $s) {
        $id_s = $s['id_soal'];
        $jwb = $jawaban_siswa[$id_s] ?? '';
        
        // Simpan setiap jawaban (PG atau Essay) ke tb_jawaban
        $ins_jwb->execute([$id_hasil, $id_user, $id_ujian, $id_s, $jwb]);

        // Hitung otomatis jika soal adalah PG (jenis_soal = 1)
        if ($s['jenis_soal'] == '1') {
            $total_pg++;
            if (strtoupper(trim($jwb)) == strtoupper(trim($s['kunci_jawaban']))) $benar++;
        }
    }

    // 3. Update nilai sementara berdasarkan PG
    $nilai = ($total_pg > 0) ? ($benar / $total_pg) * 100 : 0;
    $pdo->prepare("UPDATE tb_hasil_ujian SET nilai = ? WHERE id_hasil = ?")->execute([$nilai, $id_hasil]);

    header("Location: ujian.php?status=sukses"); exit;
}