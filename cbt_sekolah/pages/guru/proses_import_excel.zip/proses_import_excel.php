<?php
// Menggunakan path absolut agar file otomatis terbaca
include_once dirname(__DIR__, 2) . '/config/koneksi.php'; 
include_once dirname(__DIR__, 2) . '/lib/SimpleXLSX.php'; 

use Shuchkin\SimpleXLSX;

if(isset($_FILES['file_excel']['name']) && isset($_POST['id_ujian']) && isset($_POST['id_mapel'])) { 
    
    // MENANGKAP ID UJIAN & ID MAPEL DARI FORM
    $id_ujian  = $_POST['id_ujian']; 
    $id_mapel  = $_POST['id_mapel']; 
    
    $nama_file = $_FILES['file_excel']['name'];
    $tmp_file  = $_FILES['file_excel']['tmp_name'];
    $error     = $_FILES['file_excel']['error'];

    if($error == 0) {
        $ekstensi = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));

        if($ekstensi == 'xlsx') {
            
            if ( $xlsx = SimpleXLSX::parse($tmp_file) ) {
                $berhasil = 0;
                $gagal = 0;

                // Query PDO
                $query = "INSERT INTO tb_soal (
                            id_ujian, id_mapel, jenis_soal, nilai, materi, 
                            pertanyaan, gambar, opsi_a, opsi_b, 
                            opsi_c, opsi_d, opsi_e, kunci_jawaban, bobot
                         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                $stmt = $pdo->prepare($query);

                foreach ( $xlsx->rows() as $index => $row ) {
                    
                    // Lewati baris pertama (judul/header kolom Excel)
                    if ($index == 0) continue; 

                    // --- MAPPING SESUAI URUTAN EXCEL KAMU ---
                    $jenis_soal    = $row[1]; // Kolom B
                    $bobot         = $row[2]; // Kolom C
                    $materi        = $row[3]; // Kolom D
                    $gambar        = $row[4]; // Kolom E (Hanya teks nama file, misal: gambar1.jpg)
                    $pertanyaan    = $row[6]; // Kolom G
                    
                    // Lanjutan opsi jawaban (Asumsi berurutan setelah Pertanyaan)
                    $opsi_a        = $row[7]; // Kolom H
                    $opsi_b        = $row[8]; // Kolom I
                    $opsi_c        = $row[9]; // Kolom J
                    $opsi_d        = $row[10]; // Kolom K
                    $opsi_e        = $row[11]; // Kolom L
                    $kunci_jawaban = $row[12]; // Kolom M

                    // Jika pertanyaan tidak kosong, masukkan ke database
                    if(!empty($pertanyaan)) {
                        try {
                            // Eksekusi data ke database (Nilai default di-set 0)
                            $simpan = $stmt->execute([
                                $id_ujian, $id_mapel, $jenis_soal, 0, $materi, 
                                $pertanyaan, $gambar, $opsi_a, $opsi_b, 
                                $opsi_c, $opsi_d, $opsi_e, $kunci_jawaban, $bobot
                            ]);
                            
                            if($simpan) {
                                $berhasil++;
                            }
                        } catch (PDOException $e) {
                            $gagal++;
                        }
                    }
                }

                echo "<script>
                        alert('Import Selesai! Data Berhasil Masuk: $berhasil, Gagal: $gagal'); 
                        window.location.href='kelola_soal_ujian.php?id=$id_ujian';
                      </script>";

            } else {
                echo SimpleXLSX::parseError();
            }

        } else {
            echo "<script>
                    alert('Gagal! Format file harus .xlsx'); 
                    window.history.back();
                  </script>";
        }
    } else {
        echo "<script>
                alert('Terjadi kesalahan saat mengunggah file!'); 
                window.history.back();
              </script>";
    }
} else {
    echo "Akses dilarang atau data ujian/mapel dari form tidak lengkap!";
}
?>