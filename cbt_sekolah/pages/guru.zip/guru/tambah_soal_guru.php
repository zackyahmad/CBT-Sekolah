<?php
// =============================================
// FILE: pages/guru/tambah_soal_guru.php
// Form tambah / edit soal — simpan ke tb_soal (tabel admin)
// =============================================
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../../index.php"); exit;
}
require_once '../../config/koneksi.php';

$nama_guru = $_SESSION['nama_lengkap'] ?? $_SESSION['nama'] ?? 'Guru';
$id_mapel  = (int)($_GET['id_mapel'] ?? $_POST['id_mapel'] ?? 0);
$edit_id   = (int)($_GET['edit'] ?? 0);
$is_edit   = false;
$soal      = [];
$errors    = [];

// Ambil info mapel
$stmt = $pdo->prepare("SELECT * FROM tb_mapel WHERE id_mapel = ?");
$stmt->execute([$id_mapel]);
$mapel = $stmt->fetch();
if (!$mapel) { header("Location: bank_soal.php"); exit; }

// Load data soal jika mode edit
if ($edit_id) {
    $stmt = $pdo->prepare("SELECT * FROM tb_soal WHERE id_soal = ? AND id_mapel = ?");
    $stmt->execute([$edit_id, $id_mapel]);
    $soal = $stmt->fetch();
    
    if ($soal) {
        $is_edit = true;
    } else {
        header("Location: soal_list_guru.php?id_mapel=$id_mapel"); exit;
    }
}

// PROSES SIMPAN
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pertanyaan = trim($_POST['pertanyaan'] ?? '');
    $jenis_soal = $_POST['tipe_soal'] ?? 'pg'; // Di form mungkin name-nya tipe_soal, kita mapping ke jenis_soal
    $kunci      = trim($_POST['kunci_jawaban'] ?? '');
    $opsi_a     = trim($_POST['pilihan_a'] ?? '');
    $opsi_b     = trim($_POST['pilihan_b'] ?? '');
    $opsi_c     = trim($_POST['pilihan_c'] ?? '');
    $opsi_d     = trim($_POST['pilihan_d'] ?? '');
    $opsi_e     = trim($_POST['pilihan_e'] ?? '');

    if (!$pertanyaan)          $errors[] = 'Pertanyaan tidak boleh kosong.';
    if (!$opsi_a || !$opsi_b)  $errors[] = 'Minimal 2 pilihan jawaban harus diisi (A dan B).';
    if (!$kunci)               $errors[] = 'Kunci jawaban wajib dipilih.';

    if (empty($errors)) {
        if ($is_edit) {
            // UPDATE: Sesuaikan dengan kolom db (jenis_soal, opsi_a, dll)
            $sql = "UPDATE tb_soal SET 
                    pertanyaan=?, jenis_soal=?, kunci_jawaban=?, 
                    opsi_a=?, opsi_b=?, opsi_c=?, opsi_d=?, opsi_e=? 
                    WHERE id_soal=? AND id_mapel=?";
            $pdo->prepare($sql)->execute([
                $pertanyaan, $jenis_soal, $kunci, 
                $opsi_a, $opsi_b, $opsi_c, $opsi_d, $opsi_e, 
                $edit_id, $id_mapel
            ]);
        } else {
            // INSERT: Sesuaikan dengan kolom db (jenis_soal, opsi_a, dll)
            $sql = "INSERT INTO tb_soal 
                    (id_mapel, pertanyaan, jenis_soal, kunci_jawaban, opsi_a, opsi_b, opsi_c, opsi_d, opsi_e) 
                    VALUES (?,?,?,?,?,?,?,?,?)";
            $pdo->prepare($sql)->execute([
                $id_mapel, $pertanyaan, $jenis_soal, $kunci, 
                $opsi_a, $opsi_b, $opsi_c, $opsi_d, $opsi_e
            ]);
        }

        $_SESSION['flash'] = ['type'=>'success','msg'=> $is_edit?'Soal berhasil diperbarui.':'Soal berhasil ditambahkan.'];
        header("Location: soal_list_guru.php?id_mapel=$id_mapel"); exit;
    }

    // Jika terjadi error validasi, simpan inputan sebelumnya agar tidak hilang
    $soal = [
        'pertanyaan' => $pertanyaan,
        'jenis_soal' => $jenis_soal,
        'kunci_jawaban' => $kunci,
        'opsi_a' => $opsi_a,
        'opsi_b' => $opsi_b,
        'opsi_c' => $opsi_c,
        'opsi_d' => $opsi_d,
        'opsi_e' => $opsi_e
    ];
}

// Susun pilihan untuk ditampilkan di form HTML di bawahnya
$pj = [
    'A' => $soal['opsi_a'] ?? '',
    'B' => $soal['opsi_b'] ?? '',
    'C' => $soal['opsi_c'] ?? '',
    'D' => $soal['opsi_d'] ?? '',
    'E' => $soal['opsi_e'] ?? ''
];

// Pastikan variabel untuk form HTML tetap aman dipanggil
if(!isset($soal['tipe_soal'])) $soal['tipe_soal'] = $soal['jenis_soal'] ?? 'pg';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= $is_edit?'Edit':'Tambah' ?> Soal – <?= htmlspecialchars($mapel['nama_mapel']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
        * { font-family:'Inter',sans-serif; }
        .gradient-bg { background:linear-gradient(135deg,#0A192F 0%,#1E3A5F 30%,#F4A261 60%,#90BE6D 100%); background-size:200% 200%; animation:gm 10s ease infinite; }
        @keyframes gm { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        .btn-gradient { background:linear-gradient(135deg,#0A192F,#1E3A5F,#F4A261,#90BE6D); background-size:300% 300%; animation:bg 5s ease infinite; }
        @keyframes bg { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        input,select,textarea { outline:none; }
        input:focus,select:focus,textarea:focus { ring:2px solid #0A192F; border-color:#0A192F; }
    </style>
</head>
<body class="bg-gray-50">

<header class="gradient-bg shadow-lg py-4 px-6 flex justify-between items-center sticky top-0 z-40">
    <div class="flex items-center space-x-3">
        <a href="soal_list_guru.php?id_mapel=<?= $id_mapel ?>" class="text-white/70 hover:text-white mr-1">
            <i class="fas fa-arrow-left"></i>
        </a>
        <i class="fas fa-<?= $is_edit?'edit':'plus-circle' ?> text-white text-xl"></i>
        <div>
            <h1 class="text-xl font-bold text-white"><?= $is_edit?'Edit':'Tambah' ?> Soal</h1>
            <p class="text-white/60 text-xs"><?= htmlspecialchars($mapel['nama_mapel']) ?></p>
        </div>
    </div>
    <div class="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center border-2 border-white/50">
        <span class="text-white font-bold"><?= strtoupper(substr($nama_guru,0,1)) ?></span>
    </div>
</header>

<main class="p-6 max-w-3xl mx-auto">
    <div class="mb-5">
        <a href="soal_list_guru.php?id_mapel=<?= $id_mapel ?>" class="inline-flex items-center px-4 py-2 bg-white border border-gray-200 rounded-xl text-gray-700 hover:border-[#F4A261] shadow-sm transition group">
            <i class="fas fa-arrow-left mr-2 text-sm group-hover:-translate-x-1 transition-transform"></i>
            <span class="font-medium">Kembali ke Daftar Soal</span>
        </a>
    </div>

    <?php foreach ($errors as $e): ?>
    <div class="mb-4 p-4 rounded-xl bg-red-100 text-red-800 border border-red-200">
        <i class="fas fa-exclamation-circle mr-2"></i><?= htmlspecialchars($e) ?>
    </div>
    <?php endforeach; ?>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 bg-gray-50">
            <h2 class="font-bold text-gray-800 flex items-center gap-2">
                <i class="fas fa-file-alt text-[#0A192F]"></i>
                Form <?= $is_edit?'Edit':'Tambah' ?> Soal
                <span class="bg-orange-100 text-orange-700 text-xs px-2 py-0.5 rounded-full font-semibold">
                    <?= htmlspecialchars($mapel['nama_mapel']) ?>
                </span>
            </h2>
        </div>

        <form method="POST" class="p-6 space-y-5">
            <input type="hidden" name="id_mapel" value="<?= $id_mapel ?>">

            <!-- Pertanyaan -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    Pertanyaan <span class="text-red-500">*</span>
                </label>
                <textarea name="pertanyaan" rows="4" required
                          placeholder="Tulis pertanyaan di sini..."
                          class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#0A192F] focus:border-[#0A192F] transition resize-none"><?= htmlspecialchars($soal['pertanyaan']??'') ?></textarea>
            </div>

            <!-- Tipe & Kesulitan -->
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Tipe Soal</label>
                    <select name="tipe_soal" class="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#0A192F] focus:border-[#0A192F] transition">
                        <option value="pg"    <?= ($soal['tipe_soal']??'pg')==='pg'?'selected':'' ?>>Pilihan Ganda</option>
                        <option value="essay" <?= ($soal['tipe_soal']??'')==='essay'?'selected':'' ?>>Essay</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Tingkat Kesulitan</label>
                    <select name="tingkat_kesulitan" class="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#0A192F] focus:border-[#0A192F] transition">
                        <option value="mudah"  <?= ($soal['tingkat_kesulitan']??'')==='mudah'?'selected':'' ?>>Mudah</option>
                        <option value="sedang" <?= ($soal['tingkat_kesulitan']??'sedang')==='sedang'?'selected':'' ?>>Sedang</option>
                        <option value="sulit"  <?= ($soal['tingkat_kesulitan']??'')==='sulit'?'selected':'' ?>>Sulit</option>
                    </select>
                </div>
            </div>

            <!-- Pilihan Jawaban -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-3">
                    Pilihan Jawaban <span class="text-gray-400 font-normal">(A dan B wajib diisi)</span>
                </label>
                <div class="space-y-3">
                <?php foreach (['A','B','C','D','E'] as $k): ?>
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-full bg-[#0A192F] text-white flex items-center justify-center font-bold text-sm flex-shrink-0">
                        <?= $k ?>
                    </div>
                    <input type="text" name="pilihan_<?= strtolower($k) ?>"
                           value="<?= htmlspecialchars($pj[$k]) ?>"
                           placeholder="Pilihan <?= $k ?><?= in_array($k,['A','B'])?' (wajib)':' (opsional)' ?>"
                           <?= in_array($k,['A','B'])?'required':'' ?>
                           class="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#0A192F] focus:border-[#0A192F] transition">
                </div>
                <?php endforeach; ?>
                </div>
            </div>

            <!-- Kunci Jawaban -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    Kunci Jawaban <span class="text-red-500">*</span>
                </label>
                <select name="kunci_jawaban" required class="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#0A192F] focus:border-[#0A192F] transition">
                    <option value="">-- Pilih kunci jawaban yang benar --</option>
                    <?php foreach (['A','B','C','D','E'] as $k): ?>
                    <option value="<?= $k ?>" <?= ($soal['kunci_jawaban']??'')===$k?'selected':'' ?>>Jawaban <?= $k ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Tombol -->
            <div class="flex gap-3 pt-2">
                <button type="submit" class="btn-gradient text-white px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2">
                    <i class="fas fa-save"></i> <?= $is_edit?'Perbarui Soal':'Simpan Soal' ?>
                </button>
                <a href="soal_list_guru.php?id_mapel=<?= $id_mapel ?>"
                   class="px-6 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-600 hover:bg-gray-50 transition">
                    Batal
                </a>
            </div>
        </form>
    </div>
</main>
</body>
</html>