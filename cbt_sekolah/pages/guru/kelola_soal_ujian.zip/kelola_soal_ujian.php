<?php
// =============================================
// FILE: pages/guru/kelola_soal_ujian.php
// Guru memilih soal dari bank soal untuk ujian tertentu
// Soal difilter berdasarkan id_mapel ujian
// Data disimpan ke tb_ujian_soal
// =============================================
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../../index.php"); exit;
}
require_once '../../config/koneksi.php';

$id_ujian = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$id_guru  = $_SESSION['id_user'];
$nama_guru = $_SESSION['nama_lengkap'] ?? $_SESSION['nama'] ?? 'Guru';

if (!$id_ujian) { header("Location: rencana_ujian.php"); exit; }

// Ambil data ujian dari tb_ujian (tabel admin)
$stmt = $pdo->prepare("
    SELECT u.*, m.nama_mapel,
           GROUP_CONCAT(k.nama_kelas SEPARATOR ', ') AS kelas_list
    FROM tb_ujian u
    LEFT JOIN tb_mapel m ON m.id_mapel = u.id_mapel
    LEFT JOIN tb_ujian_kelas uk ON uk.id_ujian = u.id_ujian
    LEFT JOIN tb_kelas k ON k.id_kelas = uk.id_kelas
    WHERE u.id_ujian = ? AND u.id_guru = ?
    GROUP BY u.id_ujian
");
$stmt->execute([$id_ujian, $id_guru]);
$ujian = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$ujian) {
    header("Location: rencana_ujian.php"); exit;
}

$id_mapel = $ujian['id_mapel'];

// ── PROSES TAMBAH SOAL (checkbox multiple) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_soal'])) {
    $soal_ids = $_POST['soal_ids'] ?? [];
    $ditambah = 0;
    foreach ($soal_ids as $id_soal) {
        $id_soal = (int)$id_soal;
        // Cek duplikat
        $cek = $pdo->prepare("SELECT id_mapping FROM tb_ujian_soal WHERE id_ujian=? AND id_soal=?");
        $cek->execute([$id_ujian, $id_soal]);
        if ($cek->rowCount() === 0) {
            $pdo->prepare("INSERT INTO tb_ujian_soal (id_ujian, id_soal) VALUES (?,?)")
                ->execute([$id_ujian, $id_soal]);
            $ditambah++;
        }
    }
    $_SESSION['flash'] = ['type'=>'success','msg'=>"$ditambah soal berhasil ditambahkan ke ujian."];
    header("Location: kelola_soal_ujian.php?id=$id_ujian"); exit;
}

// ── PROSES HAPUS SOAL DARI UJIAN ──
if (isset($_GET['hapus_soal']) && is_numeric($_GET['hapus_soal'])) {
    $id_soal = (int)$_GET['hapus_soal'];
    $pdo->prepare("DELETE FROM tb_ujian_soal WHERE id_ujian=? AND id_soal=?")
        ->execute([$id_ujian, $id_soal]);
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Soal berhasil dihapus dari ujian.'];
    header("Location: kelola_soal_ujian.php?id=$id_ujian"); exit;
}

// ── PROSES HAPUS SEMUA SOAL ──
if (isset($_GET['hapus_semua'])) {
    $pdo->prepare("DELETE FROM tb_ujian_soal WHERE id_ujian=?")->execute([$id_ujian]);
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Semua soal berhasil dihapus dari ujian.'];
    header("Location: kelola_soal_ujian.php?id=$id_ujian"); exit;
}

// ── Soal yang SUDAH masuk ujian ini ──
$stmt_terpilih = $pdo->prepare("
    SELECT s.*, us.ditambahkan_pada
    FROM tb_ujian_soal us
    JOIN tb_soal s ON s.id_soal = us.id_soal
    WHERE us.id_ujian = ?
    ORDER BY us.ditambahkan_pada ASC
");
$stmt_terpilih->execute([$id_ujian]);
$soal_terpilih = $stmt_terpilih->fetchAll(PDO::FETCH_ASSOC);
$id_terpilih   = array_column($soal_terpilih, 'id_soal');

// ── Bank soal sesuai mapel ujian yang BELUM dipilih ──
$filter_materi = trim($_GET['materi'] ?? '');
$filter_jenis  = $_GET['jenis'] ?? '';

$params_bank = [$id_mapel];
$where_bank  = "WHERE s.id_mapel = ?";
if ($id_terpilih) {
    $ph = implode(',', array_fill(0, count($id_terpilih), '?'));
    $where_bank .= " AND s.id_soal NOT IN ($ph)";
    $params_bank = array_merge($params_bank, $id_terpilih);
}
if ($filter_materi) {
    $where_bank .= " AND s.materi LIKE ?";
    $params_bank[] = "%$filter_materi%";
}
if ($filter_jenis) {
    $where_bank .= " AND s.jenis_soal = ?";
    $params_bank[] = $filter_jenis;
}

$stmt_bank = $pdo->prepare("SELECT * FROM tb_soal s $where_bank ORDER BY s.id_soal DESC");
$stmt_bank->execute($params_bank);
$bank_soal = $stmt_bank->fetchAll(PDO::FETCH_ASSOC);

// Ambil daftar materi untuk filter
$stmt_materi = $pdo->prepare("SELECT DISTINCT materi FROM tb_soal WHERE id_mapel=? AND materi IS NOT NULL AND materi != '' ORDER BY materi");
$stmt_materi->execute([$id_mapel]);
$materi_list = $stmt_materi->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Kelola Soal Ujian – <?= htmlspecialchars($ujian['judul_ujian']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
        * { font-family:'Inter',sans-serif; }
        .gradient-bg { background:linear-gradient(135deg,#0A192F 0%,#1E3A5F 30%,#F4A261 60%,#90BE6D 100%); background-size:200% 200%; animation:gm 10s ease infinite; }
        @keyframes gm { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        .btn-gradient { background:linear-gradient(135deg,#0A192F,#1E3A5F,#F4A261,#90BE6D); background-size:300% 300%; animation:bg 5s ease infinite; }
        @keyframes bg { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        .soal-card { transition:all .2s; }
        .soal-card:hover { transform:translateY(-1px); box-shadow:0 4px 12px rgba(0,0,0,.1); }
        input[type="checkbox"]:checked + label { border-color:#0A192F; background:#EEF2FF; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">

<!-- HEADER -->
<header class="gradient-bg shadow-lg py-4 px-6 flex justify-between items-center sticky top-0 z-40">
    <div class="flex items-center space-x-3">
        <a href="rencana_ujian.php" class="text-white/70 hover:text-white mr-1 transition">
            <i class="fas fa-arrow-left"></i>
        </a>
        <i class="fas fa-book-open text-white text-xl"></i>
        <div>
            <h1 class="text-xl font-bold text-white"><?= htmlspecialchars($ujian['judul_ujian']) ?></h1>
            <p class="text-white/60 text-xs"><?= htmlspecialchars($ujian['nama_mapel']) ?> · <?= htmlspecialchars($ujian['kelas_list'] ?? '-') ?></p>
        </div>
    </div>
    <div class="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center border-2 border-white/50">
        <span class="text-white font-bold"><?= strtoupper(substr($nama_guru,0,1)) ?></span>
    </div>
</header>

<main class="p-6 max-w-7xl mx-auto">

    <?php if (isset($_SESSION['flash'])): ?>
    <div class="mb-4 p-4 rounded-xl <?= $_SESSION['flash']['type']==='success'?'bg-green-100 text-green-800':'bg-red-100 text-red-800' ?>">
        <i class="fas fa-check-circle mr-2"></i><?= htmlspecialchars($_SESSION['flash']['msg']) ?>
    </div>
    <?php unset($_SESSION['flash']); endif; ?>

    <!-- Info ujian -->
    <div class="bg-gradient-to-r from-[#0A192F] to-[#1E3A5F] text-white rounded-2xl p-5 mb-6 flex flex-wrap gap-6 items-center justify-between">
        <div class="flex flex-wrap gap-6">
            <div><div class="text-white/60 text-xs">Tanggal</div><div class="font-bold"><?= date('d M Y', strtotime($ujian['tanggal_ujian'])) ?></div></div>
            <div><div class="text-white/60 text-xs">Waktu</div><div class="font-bold"><?= substr($ujian['jam_mulai'],0,5) ?> – <?= substr($ujian['jam_selesai'],0,5) ?></div></div>
            <div><div class="text-white/60 text-xs">Durasi</div><div class="font-bold"><?= $ujian['durasi_menit'] ?> menit</div></div>
            <div><div class="text-white/60 text-xs">Soal Terpilih</div><div class="font-bold text-[#F4A261]"><?= count($soal_terpilih) ?> soal</div></div>
        </div>
        <?php if (!empty($soal_terpilih)): ?>
        <a href="?id=<?= $id_ujian ?>&hapus_semua=1"
           onclick="return confirm('Hapus semua soal dari ujian ini?')"
           class="bg-red-500/80 hover:bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold transition">
            <i class="fas fa-trash mr-1"></i> Hapus Semua Soal
        </a>
        <?php endif; ?>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- KOLOM KIRI: Soal yang sudah terpilih -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-5 py-4 border-b border-gray-100 flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
                    <i class="fas fa-check text-green-600 text-sm"></i>
                </div>
                <h3 class="font-bold text-gray-800">Soal dalam Ujian</h3>
                <span class="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full font-bold ml-auto">
                    <?= count($soal_terpilih) ?> soal
                </span>
            </div>
            <div class="p-4 space-y-3 max-h-[600px] overflow-y-auto">
                <?php if (!empty($soal_terpilih)): ?>
                <?php $no=1; foreach ($soal_terpilih as $s): ?>
                <div class="soal-card bg-green-50 border border-green-200 rounded-xl p-4">
                    <div class="flex items-start justify-between gap-3">
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-2">
                                <span class="w-6 h-6 rounded-full bg-green-500 text-white text-xs flex items-center justify-center font-bold flex-shrink-0"><?= $no++ ?></span>
                                <span class="bg-purple-100 text-purple-700 text-xs px-2 py-0.5 rounded-full font-semibold">
                                    <?= $s['jenis_soal']==='1'?'PG':'Essay' ?>
                                </span>
                                <?php if ($s['materi']): ?>
                                <span class="bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded-full"><?= htmlspecialchars($s['materi']) ?></span>
                                <?php endif; ?>
                                <span class="text-xs text-gray-400 ml-auto">Bobot: <?= $s['bobot'] ?></span>
                            </div>
                            <p class="text-sm text-gray-800 font-medium line-clamp-2">
                                <?= htmlspecialchars(mb_substr(strip_tags($s['pertanyaan']),0,100)) ?>...
                            </p>
                            <div class="mt-2 grid grid-cols-2 gap-1 text-xs text-gray-500">
                                <span>A: <?= htmlspecialchars(mb_substr($s['opsi_a']??'',0,25)) ?></span>
                                <span>B: <?= htmlspecialchars(mb_substr($s['opsi_b']??'',0,25)) ?></span>
                                <span>C: <?= htmlspecialchars(mb_substr($s['opsi_c']??'',0,25)) ?></span>
                                <span>D: <?= htmlspecialchars(mb_substr($s['opsi_d']??'',0,25)) ?></span>
                            </div>
                            <div class="mt-2 text-xs">
                                Kunci: <span class="font-bold text-green-600"><?= strtoupper($s['kunci_jawaban']) ?></span>
                            </div>
                        </div>
                        <a href="?id=<?= $id_ujian ?>&hapus_soal=<?= $s['id_soal'] ?>"
                           onclick="return confirm('Hapus soal ini dari ujian?')"
                           class="flex-shrink-0 w-7 h-7 bg-red-100 hover:bg-red-500 text-red-500 hover:text-white rounded-lg flex items-center justify-center transition">
                            <i class="fas fa-times text-xs"></i>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <div class="py-10 text-center text-gray-400">
                    <i class="fas fa-inbox text-4xl mb-3 opacity-30 block"></i>
                    <p class="text-sm">Belum ada soal dipilih.</p>
                    <p class="text-xs mt-1">Pilih soal dari bank soal di sebelah kanan.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- KOLOM KANAN: Bank soal tersedia -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-5 py-4 border-b border-gray-100 flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                    <i class="fas fa-database text-blue-600 text-sm"></i>
                </div>
                <h3 class="font-bold text-gray-800">Bank Soal</h3>
                <span class="text-xs text-gray-400"><?= htmlspecialchars($ujian['nama_mapel']) ?></span>
                <span class="bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full font-bold ml-auto">
                    <?= count($bank_soal) ?> soal
                </span>
            </div>

            <!-- Filter -->
            <div class="px-5 py-3 bg-gray-50 border-b border-gray-100">
                <form method="GET" class="flex gap-2 flex-wrap">
                    <input type="hidden" name="id" value="<?= $id_ujian ?>">
                    <?php if (!empty($materi_list)): ?>
                    <select name="materi" onchange="this.form.submit()"
                            class="text-xs border border-gray-200 rounded-lg px-2 py-1.5 outline-none">
                        <option value="">Semua Materi</option>
                        <?php foreach ($materi_list as $m): ?>
                        <option value="<?= htmlspecialchars($m) ?>" <?= $filter_materi===$m?'selected':'' ?>>
                            <?= htmlspecialchars($m) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php endif; ?>
                    <select name="jenis" onchange="this.form.submit()"
                            class="text-xs border border-gray-200 rounded-lg px-2 py-1.5 outline-none">
                        <option value="">Semua Tipe</option>
                        <option value="1" <?= $filter_jenis==='1'?'selected':'' ?>>Pilihan Ganda</option>
                        <option value="2" <?= $filter_jenis==='2'?'selected':'' ?>>Essay</option>
                    </select>
                    <?php if ($filter_materi || $filter_jenis): ?>
                    <a href="?id=<?= $id_ujian ?>" class="text-xs text-gray-500 hover:text-gray-700 px-2 py-1.5 border border-gray-200 rounded-lg">Reset</a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Form tambah soal (checkbox) -->
            <?php if (!empty($bank_soal)): ?>
            <form method="POST">
                <div class="p-4 space-y-3 max-h-[480px] overflow-y-auto">
                    <?php foreach ($bank_soal as $s): ?>
                    <div class="soal-card border border-gray-200 rounded-xl p-4 hover:border-[#0A192F] cursor-pointer"
                         onclick="document.getElementById('cb_<?= $s['id_soal'] ?>').click()">
                        <div class="flex items-start gap-3">
                            <input type="checkbox" name="soal_ids[]" value="<?= $s['id_soal'] ?>"
                                   id="cb_<?= $s['id_soal'] ?>"
                                   class="mt-1 w-4 h-4 accent-[#0A192F] flex-shrink-0"
                                   onclick="event.stopPropagation()">
                            <div class="flex-1 min-w-0">
                                <div class="flex items-center gap-2 mb-1.5 flex-wrap">
                                    <span class="bg-purple-100 text-purple-700 text-xs px-2 py-0.5 rounded-full font-semibold">
                                        <?= $s['jenis_soal']==='1'?'PG':'Essay' ?>
                                    </span>
                                    <?php if ($s['materi']): ?>
                                    <span class="bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded-full">
                                        <?= htmlspecialchars($s['materi']) ?>
                                    </span>
                                    <?php endif; ?>
                                    <span class="text-xs text-[#F4A261] font-semibold ml-auto">Bobot: <?= $s['bobot'] ?></span>
                                </div>
                                <p class="text-sm text-gray-800 font-medium leading-snug">
                                    <?= htmlspecialchars(mb_substr(strip_tags($s['pertanyaan']),0,100)) ?>
                                    <?= mb_strlen(strip_tags($s['pertanyaan']))>100?'...':'' ?>
                                </p>
                                <div class="mt-1.5 flex flex-wrap gap-2 text-xs text-gray-400">
                                    <span>A: <?= htmlspecialchars(mb_substr($s['opsi_a']??'',0,20)) ?></span>
                                    <span>B: <?= htmlspecialchars(mb_substr($s['opsi_b']??'',0,20)) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Tombol tambah -->
                <div class="px-5 py-4 border-t border-gray-100 flex items-center justify-between">
                    <button type="button" onclick="toggleAll()"
                            class="text-xs text-gray-500 hover:text-gray-700 underline">
                        Pilih Semua
                    </button>
                    <button type="submit" name="tambah_soal"
                            class="btn-gradient text-white px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2">
                        <i class="fas fa-plus"></i> Tambahkan ke Ujian
                    </button>
                </div>
            </form>

            <?php else: ?>
            <div class="py-12 text-center text-gray-400">
                <i class="fas fa-folder-open text-4xl mb-3 opacity-30 block"></i>
                <p class="text-sm font-medium">
                    <?= $filter_materi || $filter_jenis ? 'Tidak ada soal sesuai filter.' : 'Semua soal sudah ditambahkan ke ujian ini.' ?>
                </p>
                <?php if ($filter_materi || $filter_jenis): ?>
                <a href="?id=<?= $id_ujian ?>" class="text-xs text-blue-600 mt-2 inline-block">Reset filter</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

    </div>
</main>

<script>
function toggleAll() {
    const checkboxes = document.querySelectorAll('input[name="soal_ids[]"]');
    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
    checkboxes.forEach(cb => cb.checked = !allChecked);
}
</script>
</body>
</html>